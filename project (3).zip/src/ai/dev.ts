import { config } from 'dotenv';
config();

import '@/ai/flows/generate-video-script-flow.ts';
import '@/ai/flows/suggest-thumbnail-concepts-flow.ts';
import '@/ai/flows/get-trending-topics-flow.ts';
import '@/ai/flows/get-trending-niches-flow.ts';
import '@/ai/flows/search-youtube-videos-flow.ts';
import '@/ai/flows/generate-video-flow.ts';
import '@/ai/flows/verify-flutterwave-payment-flow.ts';
import '@/ai/flows/generate-channel-branding-flow.ts';
import '@/ai/flows/generate-channel-image-flow.ts';
import '@/ai/flows/unlock-branding-flow.ts';
import '@/ai/flows/app-navigator-flow.ts';
