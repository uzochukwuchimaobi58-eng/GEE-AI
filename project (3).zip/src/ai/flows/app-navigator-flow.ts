'use server';
/**
 * @fileOverview GEE AI Neural Navigator & Strategic Command Flow.
 * Interprets user messages to provide strategic help, navigation targets, and API-ready master prompts.
 * 
 * Features:
 * - Direct AI integration with Gemini 2.5 Flash.
 * - Strategic pivot logic (answers then converts to video).
 * - Firestore handshake for persistent production history.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { initializeFirebase } from '@/firebase';
import { collection, addDoc, doc, updateDoc } from 'firebase/firestore';

const AppNavigatorInputSchema = z.object({
  message: z.string().describe('The user\'s message or search query.'),
  userId: z.string().optional().describe('UID of the user for history tracking.'),
  history: z.array(z.object({
    role: z.enum(['user', 'model']),
    content: z.string()
  })).optional().describe('Previous messages in the session.'),
});
export type AppNavigatorInput = z.infer<typeof AppNavigatorInputSchema>;

const AppNavigatorOutputSchema = z.object({
  reply: z.string().describe('A helpful response or a generated Master Prompt.'),
  navigationTarget: z.enum(['home', 'script', 'discovery', 'text-to-video', 'image-to-video', 'plans', 'video', 'support', 'blog']).optional().describe('The target section ID to navigate to.'),
});
export type AppNavigatorOutput = z.infer<typeof AppNavigatorOutputSchema>;

// DEFINED AT TOP LEVEL FOR REGISTRY INTEGRITY
const navigatorPrompt = ai.definePrompt({
  name: 'appNavigatorPrompt',
  input: {schema: AppNavigatorInputSchema},
  output: {schema: AppNavigatorOutputSchema},
  prompt: `You are the GEE AI Node Navigator and a Lead Content Strategist.
  
  Your primary goal is to answer ANY questions the user has helpfully, accurately, and strategically. You represent the GEE Group, a world-class AI production house.
  
  STRICT RULES:
  1. CONVERSATION: Be conversational, authoritative, and strategic. 
  2. PIVOT: After answering any question (about money, business, lifestyle, etc.), you must ALWAYS conclude by asking: "Are you ready to turn this into a cinematic video or script using GEE AI's production tools?"
  3. NAVIGATION: If the user indicates they want to create something or visit a section, set the 'navigationTarget' enum.
  4. MASTER PROMPT: When asked for visual ideas, thumbnails, or concepts, generate a highly detailed, cinematic "Master Prompt" preceded by the word "PROMPT:". 
     - ALWAYS include a Master Prompt if the topic is visual.
  
  Studio Sections (navigationTarget):
  - "home": Main dashboard home.
  - "script": Create Videos / Script Studio.
  - "discovery": Select Niche / Trending Topics.
  - "text-to-video": Visual Engine (Text to Video).
  - "image-to-video": Visual Engine (Image to Video).
  - "plans": Subscription Tiers.
  - "video": Project Vault / Archive.
  - "blog": Strategic Insights.
  - "support": Help Center.

  Current User Message: "{{{message}}}"`,
});

export async function appNavigate(input: AppNavigatorInput): Promise<AppNavigatorOutput> {
  return appNavigatorFlow(input);
}

const appNavigatorFlow = ai.defineFlow(
  {
    name: 'appNavigatorFlow',
    inputSchema: AppNavigatorInputSchema,
    outputSchema: AppNavigatorOutputSchema,
  },
  async input => {
    try {
      const {output} = await navigatorPrompt(input);
      
      // PERSISTENCE HANDSHAKE
      if (input.userId && output) {
        try {
          const { firestore } = initializeFirebase();
          const chatRef = collection(firestore, 'users', input.userId, 'chats');
          await addDoc(chatRef, {
            message: input.message,
            reply: output.reply,
            navigationTarget: output.navigationTarget || null,
            timestamp: new Date().toISOString()
          });
        } catch (dbError) {
          console.error('Handshake Error (Firestore):', dbError);
        }
      }

      return output!;
    } catch (e: any) {
      console.error('Navigator Engine Failure:', e.message);
      // Detailed error logging for developers, clean fallback for users
      return {
        reply: "The production node is currently at capacity. However, I am still processing your request. Are you ready to turn your next idea into a video?",
        navigationTarget: 'home'
      };
    }
  }
);
