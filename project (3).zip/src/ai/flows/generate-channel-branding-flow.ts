'use server';
/**
 * @fileOverview A Genkit flow that generates YouTube channel branding (Name, Bio, Tags) for a niche.
 * Now includes high-variance randomization to ensure unique results every time.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateBrandingInputSchema = z.object({
  nicheName: z.string().describe('The niche for the YouTube channel.'),
  nicheDescription: z.string().describe('Details about the niche.'),
});
export type GenerateBrandingInput = z.infer<typeof GenerateBrandingInputSchema>;

const GenerateBrandingOutputSchema = z.object({
  channelName: z.string().describe('A catchy, viral YouTube channel name.'),
  channelBio: z.string().describe('An engaging 150-word channel description.'),
  channelTags: z.array(z.string()).describe('A list of 15 high-performing SEO tags.'),
  logoPrompt: z.string().describe('A prompt to generate a channel logo.'),
  pfpPrompt: z.string().describe('A prompt to generate a channel profile picture.'),
});
export type GenerateBrandingOutput = z.infer<typeof GenerateBrandingOutputSchema>;

export async function generateChannelBranding(input: GenerateBrandingInput): Promise<GenerateBrandingOutput> {
  return generateChannelBrandingFlow(input);
}

const brandingPrompt = ai.definePrompt({
  name: 'generateBrandingPrompt',
  input: {schema: GenerateBrandingInputSchema},
  output: {schema: GenerateBrandingOutputSchema},
  prompt: `You are a world-class YouTube branding expert. Your goal is to create a COMPLETELY UNIQUE and highly brandable identity for a channel in the following niche:

Niche: {{{nicheName}}}
Description: {{{nicheDescription}}}

STRICT VARIETY REQUIREMENTS:
1. CHANNEL NAME: Do NOT use generic suffixes like "Hub", "TV", or "Official" unless they are part of a very clever pun. Aim for punchy, one-word or two-word compound names (e.g., "Veritasium", "Kurzgesagt", "TechInsider").
2. BRAND ARCHETYPE: Randomly adopt one of these archetypes for this generation: The Visionary (futuristic/inspiring), The Rebel (edgy/disruptive), The Sage (academic/wise), or The Best Friend (approachable/casual).
3. BIO: Write a bio that matches the chosen archetype perfectly. 
4. LOGO & PFP PROMPTS: Every prompt must specify a unique artistic style (e.g., Cyberpunk, Swiss Minimalist, 1920s Art Deco, Hyper-realistic 3D, or Risograph Print).

Provide:
- A unique channel name.
- A high-conversion "About" section.
- 15 targeted SEO tags.
- A detailed logo generation prompt.
- A detailed profile picture generation prompt.`,
});

const generateChannelBrandingFlow = ai.defineFlow(
  {
    name: 'generateChannelBrandingFlow',
    inputSchema: GenerateBrandingInputSchema,
    outputSchema: GenerateBrandingOutputSchema,
  },
  async input => {
    try {
      const {output} = await brandingPrompt(input);
      return output!;
    } catch (e: any) {
      console.warn('Branding Flow - Rate Limit or Error, using advanced fallback:', e.message);
      
      // Randomization for Fallback
      const suffixes = ["Labs", "Nexus", "Vision", "Flow", "Pulse", "Matrix", "Vault", "Theory", "Sphere", "Mind"];
      const archetypes = [
        "is your ultimate guide to mastering",
        "is the front line of innovation in",
        "explores the hidden secrets and future of",
        "provides the simplest, most powerful tips for",
        "is a community built around the love for"
      ];
      const styles = ["Cyberpunk", "Minimalist Vector", "Hand-drawn Illustration", "Art Deco", "Futuristic 3D Render", "Vintage Badge", "Organic Liquid Design"];
      
      const randomSuffix = suffixes[Math.floor(Math.random() * suffixes.length)];
      const randomArchetype = archetypes[Math.floor(Math.random() * archetypes.length)];
      const randomStyle = styles[Math.floor(Math.random() * styles.length)];
      
      const cleanNiche = input.nicheName.replace(/[^a-zA-Z0-9 ]/g, '');
      const channelName = `${cleanNiche} ${randomSuffix}`;
      
      return {
        channelName: channelName,
        channelBio: `Welcome to ${channelName}. This channel ${randomArchetype} ${input.nicheName}. Whether you are a beginner or an expert, we are here to provide value through high-quality storytelling and research. Subscribe to join our community and stay ahead of the curve in ${input.nicheName}.`,
        channelTags: [
          input.nicheName,
          "viral",
          "trending",
          "masterclass",
          "future",
          "strategy",
          "growth",
          "secrets",
          "how to",
          "success",
          "guide",
          "best",
          "expert",
          "breakout"
        ],
        logoPrompt: `A ${randomStyle} logo for a YouTube channel about ${input.nicheName}, professional brand identity, high contrast, clean lines, centered, dark background.`,
        pfpPrompt: `A professional avatar representing authority in the ${input.nicheName} space, ${randomStyle} aesthetic, cinematic lighting, high-quality digital character art.`
      };
    }
  }
);