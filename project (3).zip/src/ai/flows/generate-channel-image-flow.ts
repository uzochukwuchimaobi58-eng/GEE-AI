'use server';
/**
 * @fileOverview A Genkit flow for generating channel branding images (logos/pfps).
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateImageInputSchema = z.object({
  prompt: z.string().describe('The prompt for image generation.'),
  type: z.enum(['logo', 'pfp']).describe('The type of asset being generated.'),
});
export type GenerateImageInput = z.infer<typeof GenerateImageInputSchema>;

const GenerateImageOutputSchema = z.object({
  imageUrl: z.string().describe('Data URI of the generated image.'),
});
export type GenerateImageOutput = z.infer<typeof GenerateImageOutputSchema>;

export async function generateChannelImage(input: GenerateImageInput): Promise<GenerateImageOutput> {
  return generateChannelImageFlow(input);
}

const generateChannelImageFlow = ai.defineFlow(
  {
    name: 'generateChannelImageFlow',
    inputSchema: GenerateImageInputSchema,
    outputSchema: GenerateImageOutputSchema,
  },
  async input => {
    const { media } = await ai.generate({
      model: 'googleai/imagen-4.0-fast-generate-001',
      prompt: input.prompt,
    });

    if (!media || !media.url) {
      throw new Error('Image generation failed');
    }

    return {
      imageUrl: media.url,
    };
  }
);
