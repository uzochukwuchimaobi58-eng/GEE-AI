'use server';
/**
 * @fileOverview Secure Genkit flow for generating AI videos using Gemini Veo.
 * Features:
 * - Bot Protection: Daily generation limits per user.
 * - Atomic Credit Validation: Prevents generation if balance is insufficient.
 * - Enforced Standards: Supports 16:9 (YouTube), 9:16 (TikTok), 1:1 (Instagram), and 4:5 (Facebook).
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { googleAI } from '@genkit-ai/google-genai';
import { initializeFirebase } from '@/firebase';
import { doc, getDoc, updateDoc, increment } from 'firebase/firestore';

const GenerateVideoInputSchema = z.object({
  prompt: z.string().optional().describe('Visual description.'),
  imageRef: z.string().optional().describe('Data URI of reference image.'),
  mode: z.enum(['text-to-video', 'image-to-video']).describe('Production mode.'),
  userId: z.string().describe('UID of the requester.'),
  aspectRatio: z.enum(['16:9', '9:16', '1:1', '4:5']).optional().default('16:9').describe('Target format.'),
});

const GenerateVideoOutputSchema = z.object({
  videoUrl: z.string().describe('Data URI of generated MP4.'),
});

// ENFORCED GLOBAL REVENUE STANDARDS
const ENFORCED_COST = 50;

export async function generateVideo(input: z.infer<typeof GenerateVideoInputSchema>) {
  return generateVideoFlow(input);
}

export const generateVideoFlow = ai.defineFlow(
  {
    name: 'generateVideoFlow',
    inputSchema: GenerateVideoInputSchema,
    outputSchema: GenerateVideoOutputSchema,
  },
  async (input) => {
    const { firestore } = initializeFirebase();
    const userRef = doc(firestore, 'users', input.userId);
    const userSnap = await getDoc(userRef);

    if (!userSnap.exists()) throw new Error('Security Error: Production node not registered.');

    const userData = userSnap.data();
    const today = new Date().toISOString().split('T')[0];
    
    // --- BOT PROTECTION ---
    const lastGenDate = userData.lastGenerationDate || '';
    const currentDailyCount = lastGenDate === today ? (userData.dailyGenerationCount || 0) : 0;
    const DAILY_LIMIT = userData.is_premium ? 100 : 20;

    if (currentDailyCount >= DAILY_LIMIT) {
      throw new Error(`Daily Limit Reached: Your node is restricted to ${DAILY_LIMIT} renders per 24h.`);
    }

    // ENFORCE ATOMIC CREDIT VALIDATION (FIXED REVENUE MODE)
    if ((userData.credits || 0) < ENFORCED_COST) {
      throw new Error(`Insufficient Power: This render requires ${ENFORCED_COST} credits.`);
    }

    // --- ATOMIC SECURITY UPDATE ---
    await updateDoc(userRef, {
      credits: increment(-ENFORCED_COST),
      dailyGenerationCount: (currentDailyCount + 1),
      lastGenerationDate: today,
      updatedAt: new Date().toISOString()
    });

    const pacingInstructions = `IMPORTANT: High-fidelity cinematic rendering. Format: ${input.aspectRatio}. Style: Photorealistic.`;
    const enhancedPrompt = `${input.prompt || "Cinematic aerial shot"}. ${pacingInstructions}`;

    try {
      // Utilizing the latest 3.1 Fast model for expanded ratio support
      let { operation } = await ai.generate({
        model: googleAI.model('veo-3.1-fast-generate-preview'),
        prompt: input.mode === 'text-to-video' ? enhancedPrompt : [
          { text: enhancedPrompt },
          { media: { url: input.imageRef!, contentType: 'image/jpeg' } }
        ],
        config: {
          aspectRatio: input.aspectRatio,
        },
      });

      if (!operation) throw new Error('AI Engine Error: Failed to initialize pipeline.');

      let pollCount = 0;
      while (!operation.done && pollCount < 60) {
        await new Promise((resolve) => setTimeout(resolve, 5000));
        operation = await ai.checkOperation(operation);
        pollCount++;
      }

      if (!operation.done) throw new Error('Generation Timeout: Node busy.');
      if (operation.error) throw new Error('Engine Error: ' + operation.error.message);

      const videoPart = operation.output?.message?.content.find((p) => !!p.media);
      if (!videoPart?.media?.url) throw new Error('Retrieval Error: Content not found.');

      const response = await fetch(`${videoPart.media.url}&key=${process.env.GEMINI_API_KEY}`);
      if (!response.ok) throw new Error('Download Error: Provider rejected request.');
      
      const buffer = await response.arrayBuffer();
      const base64Video = Buffer.from(buffer).toString('base64');

      return { videoUrl: `data:video/mp4;base64,${base64Video}` };
    } catch (e: any) {
      console.error('SECURE_FLOW_ERROR:', e.message);
      throw new Error(e.message || 'Critical Engine Failure.');
    }
  }
);