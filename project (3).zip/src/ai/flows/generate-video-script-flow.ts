'use server';
/**
 * @fileOverview GEE AI Lead Content Strategist Flow.
 * 
 * Implements the H.V.B. Formula (Hook, Value, Bridge) for maximum retention.
 * Supports specialized production tiers: SHORT, MEDIUM, and LONG.
 * The LONG tier acts as a professional director, providing 20 scenes for a 10-minute masterclass.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateVideoScriptInputSchema = z.object({
  topic: z.string().describe('The topic for the video script.'),
  tone: z.string().describe('The desired tone for the video script.'),
  platform: z.enum(['YouTube', 'Facebook', 'TikTok', 'Instagram']).describe('The target platform for the video.'),
  durationId: z.enum(['short', 'medium', 'long']).optional().default('short').describe('The production tier (short/medium/long).'),
});
export type GenerateVideoScriptInput = z.infer<typeof GenerateVideoScriptInputSchema>;

const GenerateVideoScriptOutputSchema = z.object({
  script: z.string().describe('The generated viral video script with metadata and visual cues.'),
});
export type GenerateVideoScriptOutput = z.infer<typeof GenerateVideoScriptOutputSchema>;

export async function generateVideoScript(input: GenerateVideoScriptInput): Promise<GenerateVideoScriptOutput> {
  return generateVideoScriptFlow(input);
}

const generateVideoScriptPrompt = ai.definePrompt({
  name: 'generateVideoScriptPrompt',
  input: {schema: GenerateVideoScriptInputSchema},
  output: {schema: GenerateVideoScriptOutputSchema},
  prompt: `You are the Lead Content Strategist and a Professional Video Director for GEE AI. Your goal is to generate high-end, high-retention scripts for YouTube and Social Media automation.

STRICT RULES:
- HOOK: The first 15-30 seconds must be high-stakes or curiosity-driven.
- PACING: Use short, punchy sentences. Never use corporate jargon.
- FORMATTING: Use clear markers for [Visual Description] and [Voiceover Script].

Topic: "{{{topic}}}"
Tone: "{{{tone}}}"
Platform: {{{platform}}}

{{#if (eq durationId "short")}}
[PRODUCTION TIER: SHORT - 60 SECONDS]
Structure:
- 0-10s: Aggressive Hook.
- 10-50s: Rapid-fire value.
- 50-60s: Loop-able Outro.
Format: Breakdown into 3-4 segments with visual cues.
{{/if}}

{{#if (eq durationId "medium")}}
[PRODUCTION TIER: MEDIUM - 4 MINUTES]
Structure:
- Intro: 30s Problem/Solution Frame.
- Body: 3 Distinct Chapters.
- Outro: Strategic Call to Action.
Format: Breakdown into 8-10 scenes.
{{/if}}

{{#if (eq durationId "long")}}
[PRODUCTION TIER: LONG-FORM MASTERY - 10 MINUTES]
Act as a Professional Video Director. Expand the topic into a 10-minute cinematic masterclass.

STRICT FORMATTING FOR LONG-FORM:
1. Divide the script into EXACTLY 20 distinct scenes.
2. Each scene must last exactly 30 seconds.
3. For EVERY SCENE, provide:
   - Scene Number (1-20)
   - [Visual Description]: Detailed description for a video generation model (lighting, camera angle, action).
   - [Voiceover Script]: The spoken narration for that 30-second block.

Content Arc:
- Scenes 1-2: The Cold Open (Deep Hook).
- Scenes 3-6: The Problem & Context (The Hook).
- Scenes 7-15: The Deep Dive / Value Delivery (The Value).
- Scenes 16-18: The Master Secret / Climax.
- Scenes 19-20: The Bridge & Final Call (The Bridge).
{{/if}}`,
});

const generateVideoScriptFlow = ai.defineFlow(
  {
    name: 'generateVideoScriptFlow',
    inputSchema: GenerateVideoScriptInputSchema,
    outputSchema: GenerateVideoScriptOutputSchema,
  },
  async input => {
    try {
      const {output} = await generateVideoScriptPrompt(input);
      return output!;
    } catch (e: any) {
      console.warn('Script Flow - Error, using fallback:', e.message);
      return { 
        script: `[GEE AI CONTENT STRATEGIST FALLBACK]
Title: Why ${input.topic} is the Future
Keywords: ${input.topic}, trends, 2025, viral, insight

Scene 1:
[Visual Description: High-tech digital grid forming the words ${input.topic} in glowing neon]
[Voiceover Script: Most people think they understand ${input.topic}. But they're missing the one hidden detail that changes everything.]

(AI is currently re-calibrating for your specific ${input.durationId} production tier. Please try again for the full strategic breakdown!)`
      };
    }
  }
);