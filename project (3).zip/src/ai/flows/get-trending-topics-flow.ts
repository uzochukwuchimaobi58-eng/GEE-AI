'use server';
/**
 * @fileOverview A Genkit flow that fetches 20 current trending topics using Google Search grounding.
 * Now includes SEO keywords, optimized descriptions, video hooks, and momentum categorization.
 * Includes a robust fallback mechanism for RESOURCE_EXHAUSTED (rate limit) scenarios.
 *
 * - getTrendingTopics - A function that fetches rising trends in specific categories or for a custom query.
 * - GetTrendingTopicsInput - Input schema for category, custom search, and time range.
 * - GetTrendingTopicsOutput - Output schema for a list of trending topics with strategic insights.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import {googleAI} from '@genkit-ai/google-genai';

const GetTrendingTopicsInputSchema = z.object({
  category: z.enum(['tech', 'lifestyle']).optional().describe('The category to search for trends.'),
  searchQuery: z.string().optional().describe('A custom search query for trends.'),
  timeRange: z.enum(['today', 'week', 'month']).optional().default('week').describe('The time range for the trends.'),
});
export type GetTrendingTopicsInput = z.infer<typeof GetTrendingTopicsInputSchema>;

const TrendingTopicSchema = z.object({
  keyword: z.string().describe('The trending keyword or phrase.'),
  description: z.string().describe('A brief explanation of why this is trending.'),
  risingScore: z.string().describe('A qualitative indicator of how fast it is rising (e.g., "Breakout", "+500%").'),
  type: z.enum(['trending', 'rising', 'exploding']).describe('The momentum category: trending (steady), rising (fast), exploding (breakout/viral).'),
  seoKeywords: z.array(z.string()).describe('A list of 5-8 highly relevant SEO keywords for this topic.'),
  optimizedDescription: z.string().describe('A 2-3 sentence SEO-optimized video description.'),
  videoHook: z.string().describe('A high-engagement opening line (hook) for a video about this topic.'),
});

const GetTrendingTopicsOutputSchema = z.object({
  trends: z.array(TrendingTopicSchema).describe('A list of 20 trending topics with strategic details.'),
});
export type GetTrendingTopicsOutput = z.infer<typeof GetTrendingTopicsOutputSchema>;

export async function getTrendingTopics(input: GetTrendingTopicsInput): Promise<GetTrendingTopicsOutput> {
  return getTrendingTopicsFlow(input);
}

const getTrendingTopicsFlow = ai.defineFlow(
  {
    name: 'getTrendingTopicsFlow',
    inputSchema: GetTrendingTopicsInputSchema,
    outputSchema: GetTrendingTopicsOutputSchema,
  },
  async (input) => {
    const subject = input.searchQuery ? `related to "${input.searchQuery}"` : `for the ${input.category || 'tech'} category`;
    
    const rangeMap = {
      today: 'in the last 24 hours',
      week: 'in the last 7 days',
      month: 'in the last 30 days'
    };
    const timePhrase = rangeMap[input.timeRange || 'week'];

    try {
      // Step 1: Identify trends using Google Search retrieval
      const searchResponse = await ai.generate({
        model: googleAI.model('gemini-2.5-flash'),
        prompt: `Using Google Search retrieval, identify the top 20 latest trending keywords and breakout topics ${subject} ${timePhrase}. 
        Categorize each keyword into one of three momentum types:
        - "trending": Steady, consistent growth.
        - "rising": High velocity, fast-growing interest.
        - "exploding": Breakout, viral, or massive sudden spike.
        
        Focus on topics popular on TikTok, YouTube, X, and Instagram. 
        For each of the 20 trends, provide:
        1. Keyword
        2. Brief explanation of the trend
        3. Rising score (e.g. "Breakout")
        4. Momentum type (trending, rising, or exploding)
        5. A list of 5 targeted SEO keywords
        6. A short SEO-optimized video description (2 sentences)
        7. A viral-style video hook (the first line of a script).
        
        IMPORTANT: If you cannot find real-time data, provide 20 highly relevant evergreen high-growth topics for the ${input.category || 'tech'} niche instead.`,
        config: {
          googleSearchRetrieval: true,
          safetySettings: [
            { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
            { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
            { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' },
            { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
            { category: 'HARM_CATEGORY_CIVIC_INTEGRITY', threshold: 'BLOCK_ONLY_HIGH' },
          ],
        },
      });

      // Step 2: Format the retrieved text into the structured JSON schema
      const formatResponse = await ai.generate({
        model: googleAI.model('gemini-2.5-flash'),
        prompt: `Based on the following trending topics information ${subject}, 
        format it into a structured JSON list of 20 items. 
        
        Trends Information:
        ${searchResponse.text || "No specific trends found. Please generate 20 evergreen viral topics for " + subject}
        
        Requirements:
        - Return exactly 20 trends.
        - Each trend must have: keyword, description, risingScore, type (trending/rising/exploding), seoKeywords (array), optimizedDescription, and videoHook.
        - If no info is provided above, generate 20 realistic viral topics for this niche.`,
        output: {
          schema: GetTrendingTopicsOutputSchema,
        },
      });

      return formatResponse.output || { trends: getFallbackTrends() };
    } catch (e: any) {
      console.warn('Trending Topics Flow - Rate Limit or Error, using fallback:', e.message);
      return { trends: getFallbackTrends() };
    }
  }
);

function getFallbackTrends() {
  const momentum: ('trending' | 'rising' | 'exploding')[] = ['trending', 'rising', 'exploding'];
  return [
    {
      keyword: "AI Video Automation",
      description: "AI-driven tools for automated video editing and scripting are seeing massive growth.",
      risingScore: "Breakout",
      type: "exploding",
      seoKeywords: ["AI video", "automation", "content creation", "video editing", "SaaS"],
      optimizedDescription: "Master AI video automation in 2025. Learn the best workflows to scale your channel.",
      videoHook: "The old way of editing video is dead. Here's how AI is taking over."
    },
    {
      keyword: "Spatial Computing",
      description: "Increased interest in AR/VR headsets and mixed reality ecosystems.",
      risingScore: "+450%",
      type: "rising",
      seoKeywords: ["Spatial computing", "Apple Vision Pro", "VR headsets", "AR tech", "Mixed reality"],
      optimizedDescription: "Spatial computing is the next frontier. We dive into the top hardware releases.",
      videoHook: "Is spatial computing actually the future or just another tech gimmick?"
    },
    {
      keyword: "Digital Detox Apps",
      description: "Users are seeking tools to limit screen time and improve mental focus.",
      risingScore: "Steady",
      type: "trending",
      seoKeywords: ["Digital detox", "productivity", "mental health", "app limits", "focus mode"],
      optimizedDescription: "The best digital detox apps to reclaim your focus. Stop scrolling and start living.",
      videoHook: "Your phone is stealing your life. Here's how to get it back."
    },
    {
      keyword: "Personal Branding for Gen Z",
      description: "Young creators are focusing on building long-term career assets through social media.",
      risingScore: "Exploding",
      type: "exploding",
      seoKeywords: ["Personal branding", "Gen Z", "career tips", "LinkedIn marketing", "content strategy"],
      optimizedDescription: "Personal branding is the new degree. Build your digital footprint starting today.",
      videoHook: "Why a resume won't get you a job in 2025, but your personal brand will."
    },
    {
      keyword: "Sustainable Tech Gadgets",
      description: "Eco-friendly electronics and circular economy tech products are trending.",
      risingScore: "+200%",
      type: "rising",
      seoKeywords: ["Sustainable tech", "eco-friendly gadgets", "green energy", "recyclable electronics", "solar"],
      optimizedDescription: "The green tech revolution is here. Check out the best sustainable gadgets this year.",
      videoHook: "Tech doesn't have to be trash. Here are 5 gadgets that are actually good for the planet."
    },
    {
      keyword: "No-Code SaaS Development",
      description: "Entrepreneurs are building and launching products without writing a single line of code.",
      risingScore: "Breakout",
      type: "exploding",
      seoKeywords: ["No-code", "SaaS", "startup", "Bubble", "Webflow", "low-code"],
      optimizedDescription: "Launch your own SaaS in weeks, not months. The ultimate guide to no-code development.",
      videoHook: "You don't need to be a developer to build a million dollar software company."
    },
    {
      keyword: "Micro-Influencer Marketing",
      description: "Brands are shifting budgets toward creators with smaller, highly engaged audiences.",
      risingScore: "Steady",
      type: "trending",
      seoKeywords: ["Micro-influencer", "influencer marketing", "brand deals", "social media", "engagement"],
      optimizedDescription: "Why micro-influencers are winning the marketing war. How to get brand deals with 1k followers.",
      videoHook: "Forget the 100k follower count. Here's why small creators are making more money."
    },
    {
      keyword: "Cybersecurity for Families",
      description: "Rising demand for protecting children and home networks from online threats.",
      risingScore: "+120%",
      type: "rising",
      seoKeywords: ["Cybersecurity", "family safety", "online privacy", "VPN", "parental controls"],
      optimizedDescription: "Is your home network safe? Essential cybersecurity tips for the modern family.",
      videoHook: "The scary truth about your home Wi-Fi and what hackers know about your kids."
    },
    {
      keyword: "Interactive Livestreaming",
      description: "Streamers are using custom AI and game integrations to engage viewers in real-time.",
      risingScore: "Breakout",
      type: "exploding",
      seoKeywords: ["Livestreaming", "Twitch", "interactive tech", "AI streaming", "audience engagement"],
      optimizedDescription: "The future of streaming is interactive. Learn how to build an engaged community through tech.",
      videoHook: "Watching a stream is boring. Here's how the next generation of creators is letting viewers play."
    },
    {
      keyword: "Ethical AI Development",
      description: "Debates around data privacy, bias, and copyright in AI models are intensifying.",
      risingScore: "Steady",
      type: "trending",
      seoKeywords: ["Ethical AI", "AI bias", "data privacy", "AI regulations", "fair tech"],
      optimizedDescription: "Can AI be fair? Exploring the biggest ethical challenges in artificial intelligence today.",
      videoHook: "Who owns your data? The AI war for your identity has already started."
    },
    {
      keyword: "Biohacking & Nootropics",
      description: "Optimization of human performance through science-backed supplements and lifestyle changes.",
      risingScore: "+300%",
      type: "rising",
      seoKeywords: ["Biohacking", "nootropics", "performance", "health optimization", "focus"],
      optimizedDescription: "Upgrade your brain. A deep dive into the world of biohacking and cognitive performance.",
      videoHook: "What if you could work twice as fast with half the effort? Welcome to biohacking."
    },
    {
      keyword: "Creator Economy Middle Class",
      description: "More creators are making a stable full-time income through niche communities rather than viral hits.",
      risingScore: "Rising",
      type: "rising",
      seoKeywords: ["Creator economy", "monetization", "niche communities", "Patreon", "Substack"],
      optimizedDescription: "You don't need to be a celebrity to be rich. The rise of the creator economy middle class.",
      videoHook: "The era of the 'Mega Influencer' is ending. Here's where the real money is moving."
    },
    {
      keyword: "Short-Form Video SEO",
      description: "Optimizing TikTok and Reels for search visibility is becoming a primary skill.",
      risingScore: "Breakout",
      type: "exploding",
      seoKeywords: ["Short-form SEO", "TikTok SEO", "Reels search", "video growth", "algorithms"],
      optimizedDescription: "TikTok is the new Google. Learn how to optimize your short videos for maximum search traffic.",
      videoHook: "Stop guessing why your videos aren't getting views. It's not the algorithm, it's your SEO."
    },
    {
      keyword: "Hybrid Remote Work Culture",
      description: "Companies and employees are redefining productivity in a mixed office and home environment.",
      risingScore: "Steady",
      type: "trending",
      seoKeywords: ["Hybrid work", "remote work", "productivity", "office culture", "future of work"],
      optimizedDescription: "The office isn't dead, but it's changed forever. How to thrive in a hybrid work world.",
      videoHook: "The 9-to-5 office job is gone. Here's what your boss isn't telling you about remote work."
    },
    {
      keyword: "AI Music Generation",
      description: "Music producers and creators are leveraging AI to generate royalty-free background music.",
      risingScore: "+500%",
      type: "exploding",
      seoKeywords: ["AI music", "Suno", "Udio", "music production", "royalty-free music"],
      optimizedDescription: "AI is writing the hits. A guide to the best AI music generators for content creators.",
      videoHook: "That song you've been listening to on repeat? It might have been written by an AI."
    },
    {
      keyword: "Vertical Screen Marketing",
      description: "Brands are designing entire ad campaigns specifically for vertical consumption first.",
      risingScore: "Rising",
      type: "rising",
      seoKeywords: ["Vertical video", "marketing", "TikTok ads", "Reels ads", "mobile first"],
      optimizedDescription: "Mobile first is no longer optional. Why vertical marketing is the only strategy that works in 2025.",
      videoHook: "If your brand isn't vertical, you're invisible. Here's why."
    },
    {
      keyword: "Indie Game Development",
      description: "Solo developers are finding success with niche, high-fidelity indie games on Steam.",
      risingScore: "Steady",
      type: "trending",
      seoKeywords: ["Indie game", "Steam", "game dev", "Unity", "Unreal Engine", "solo dev"],
      optimizedDescription: "The golden age of indie games. How solo developers are beating triple-A studios.",
      videoHook: "One person made this game in their bedroom and earned millions. Here's how."
    },
    {
      keyword: "AI Personal Assistants",
      description: "Transition from simple chatbots to agentic personal assistants that perform tasks.",
      risingScore: "Exploding",
      type: "exploding",
      seoKeywords: ["AI agents", "personal assistant", "automation", "ChatGPT", "productivity"],
      optimizedDescription: "The rise of the AI agent. Your personal assistant is finally smart enough to do your work.",
      videoHook: "Stop talking to AI and start letting AI do things for you."
    },
    {
      keyword: "Renewable Energy storage",
      description: "Innovations in battery tech for home and industrial energy storage.",
      risingScore: "Rising",
      type: "rising",
      seoKeywords: ["Energy storage", "batteries", "solar energy", "Tesla Powerwall", "renewable energy"],
      optimizedDescription: "Storing the sun. The latest breakthroughs in battery technology for a green future.",
      videoHook: "The biggest problem with green energy just got solved. Here's the tech behind it."
    },
    {
      keyword: "Decentralized Social Media",
      description: "Growing interest in platforms like BlueSky and Mastodon for user-owned content.",
      risingScore: "Steady",
      type: "trending",
      seoKeywords: ["Decentralized social", "BlueSky", "Mastodon", "Web3", "user ownership"],
      optimizedDescription: "Tired of big tech algorithms? Why creators are moving to decentralized social media.",
      videoHook: "What if you actually owned your social media following? The revolution has started."
    }
  ];
}
