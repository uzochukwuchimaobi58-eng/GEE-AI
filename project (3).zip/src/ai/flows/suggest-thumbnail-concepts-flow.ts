'use server';
/**
 * @fileOverview This file implements a Genkit flow for generating AI-powered thumbnail concept suggestions.
 * Now includes a robust fallback mechanism for RESOURCE_EXHAUSTED (rate limit) scenarios.
 *
 * - suggestThumbnailConcepts - A function that handles the generation of thumbnail concepts.
 * - SuggestThumbnailConceptsInput - The input type for the suggestThumbnailConcepts function.
 * - SuggestThumbnailConceptsOutput - The return type for the suggestThumbnailConcepts function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestThumbnailConceptsInputSchema = z
  .object({
    videoScript: z
      .string()
      .optional()
      .describe('The full script of the video.'),
    videoTopic: z
      .string()
      .optional()
      .describe('A brief topic or theme of the video.'),
  })
  .refine(
    data => data.videoScript || data.videoTopic,
    'Either videoScript or videoTopic must be provided.'
  );

export type SuggestThumbnailConceptsInput = z.infer<
  typeof SuggestThumbnailConceptsInputSchema
>;

const SuggestThumbnailConceptsOutputSchema = z.object({
  concepts: z
    .array(z.string())
    .describe('A list of creative and engaging thumbnail concept suggestions.'),
});

export type SuggestThumbnailConceptsOutput = z.infer<
  typeof SuggestThumbnailConceptsOutputSchema
>;

export async function suggestThumbnailConcepts(
  input: SuggestThumbnailConceptsInput
): Promise<SuggestThumbnailConceptsOutput> {
  return suggestThumbnailConceptsFlow(input);
}

const suggestThumbnailConceptsPrompt = ai.definePrompt({
  name: 'suggestThumbnailConceptsPrompt',
  input: {schema: SuggestThumbnailConceptsInputSchema},
  output: {schema: SuggestThumbnailConceptsOutputSchema},
  prompt: `You are an expert video thumbnail designer. Your goal is to generate creative and engaging thumbnail concept suggestions for a video.

Consider the following information:

{{#if videoTopic}}
Video Topic: {{{videoTopic}}}
{{/if}}

{{#if videoScript}}
Video Script:
\`\`\`
{{{videoScript}}}
\`\`\`
{{/if}}

Based on the information provided, generate 5 distinct and attention-grabbing thumbnail concept ideas. Each concept should be a short, descriptive phrase.

Return the suggestions as a JSON object with a single key 'concepts', which is an array of strings.`,
});

const suggestThumbnailConceptsFlow = ai.defineFlow(
  {
    name: 'suggestThumbnailConceptsFlow',
    inputSchema: SuggestThumbnailConceptsInputSchema,
    outputSchema: SuggestThumbnailConceptsOutputSchema,
  },
  async input => {
    try {
      const {output} = await suggestThumbnailConceptsPrompt(input);
      return output!;
    } catch (e: any) {
      console.warn('Suggest Concepts Flow - Rate Limit or Error, using fallback:', e.message);
      return {
        concepts: [
          "Extreme Close-up with Shocked Expression",
          "Side-by-Side Comparison: Before vs After",
          "Bright Neon Text with Bold Outlines",
          "Arrows pointing to a Hidden Detail",
          "High Contrast Action Shot from the Video"
        ]
      };
    }
  }
);
