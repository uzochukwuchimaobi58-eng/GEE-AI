'use server';
/**
 * @fileOverview A secure Genkit flow for unlocking channel branding using credits.
 * Deducts 200 credits and generates branding + strategic analysis in one atomic operation.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { initializeFirebase } from '@/firebase';
import { doc, getDoc, updateDoc, increment } from 'firebase/firestore';

const UnlockBrandingInputSchema = z.object({
  userId: z.string(),
  nicheName: z.string(),
  nicheDescription: z.string(),
});

const UnlockBrandingOutputSchema = z.object({
  channelName: z.string().describe('A catchy, brandable YouTube channel name.'),
  channelBio: z.string().describe('A 150-word SEO-optimized channel description.'),
  channelTags: z.array(z.string()).describe('15 high-ranking SEO tags.'),
  logoPrompt: z.string().describe('Detailed prompt for an AI logo generator.'),
  pfpPrompt: z.string().describe('Detailed prompt for an AI profile picture.'),
  analysis: z.object({
    difficulty: z.string().describe('Ranking difficulty (e.g., "Easy", "Medium", "Hard").'),
    competitionScore: z.number().describe('0-100 score of current competitor saturation.'),
    potentialCPM: z.string().describe('Estimated AdSense revenue range (e.g., "$12 - $45").'),
    trendingKeywords: z.array(z.string()).describe('Top 5 breakout keywords for this specific niche.'),
    growthForecast: z.string().describe('A 1-sentence prediction of niche performance for the next 6 months.'),
  }),
});

export async function unlockBranding(input: z.infer<typeof UnlockBrandingInputSchema>) {
  return unlockBrandingFlow(input);
}

const brandingPrompt = ai.definePrompt({
  name: 'unlockBrandingPrompt',
  input: {
    schema: z.object({
      nicheName: z.string(),
      nicheDescription: z.string(),
    })
  },
  output: { schema: UnlockBrandingOutputSchema },
  prompt: `You are a world-class YouTube branding and market analyst. Create a unique identity and strategic analysis for a channel in this niche:
  Niche: {{{nicheName}}}
  Description: {{{nicheDescription}}}
  
  Provide:
  1. A catchy name.
  2. A 150-word high-conversion bio.
  3. 15 SEO tags.
  4. Detailed prompts for a Logo and Profile Picture.
  5. A STRATEGIC ANALYSIS including ranking difficulty, competition score (0-100), estimated CPM, 5 breakout keywords, and a 6-month growth forecast.`,
});

const unlockBrandingFlow = ai.defineFlow(
  {
    name: 'unlockBrandingFlow',
    inputSchema: UnlockBrandingInputSchema,
    outputSchema: UnlockBrandingOutputSchema,
  },
  async (input) => {
    const { firestore } = initializeFirebase();
    const userRef = doc(firestore, 'users', input.userId);
    const userSnap = await getDoc(userRef);

    if (!userSnap.exists()) throw new Error('User not found');
    
    const credits = userSnap.data().credits || 0;
    const COST = 200;

    if (credits < COST) {
      throw new Error(`Insufficient credits. You need ${COST} credits to unlock professional branding.`);
    }

    // Deduct credits on server
    await updateDoc(userRef, {
      credits: increment(-COST),
      updatedAt: new Date().toISOString()
    });

    // Generate Branding and Analysis
    const { output } = await brandingPrompt({
      nicheName: input.nicheName,
      nicheDescription: input.nicheDescription
    });

    return output!;
  }
);
