'use server';
/**
 * @fileOverview A Genkit flow for verifying Flutterwave transactions.
 * 
 * - verifyPayment - Calls Flutterwave API to confirm transaction status.
 * - VerifyPaymentInput - Transaction ID from Flutterwave.
 * - VerifyPaymentOutput - Payment status and amount.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const VerifyPaymentInputSchema = z.object({
  transactionId: z.string().describe('The Flutterwave transaction ID.'),
});
export type VerifyPaymentInput = z.infer<typeof VerifyPaymentInputSchema>;

const VerifyPaymentOutputSchema = z.object({
  status: z.enum(['success', 'failed', 'pending']),
  amount: z.number().optional(),
  currency: z.string().optional(),
  customerEmail: z.string().optional(),
});
export type VerifyPaymentOutput = z.infer<typeof VerifyPaymentOutputSchema>;

export async function verifyPayment(input: VerifyPaymentInput): Promise<VerifyPaymentOutput> {
  return verifyPaymentFlow(input);
}

const verifyPaymentFlow = ai.defineFlow(
  {
    name: 'verifyPaymentFlow',
    inputSchema: VerifyPaymentInputSchema,
    outputSchema: VerifyPaymentOutputSchema,
  },
  async (input) => {
    const FLUTTERWAVE_SECRET_KEY = process.env.FLUTTERWAVE_SECRET_KEY;

    if (!FLUTTERWAVE_SECRET_KEY) {
      // For development, we'll simulate success if no key is provided
      console.warn('FLUTTERWAVE_SECRET_KEY not set. Simulating verification.');
      return { status: 'success', amount: 10, currency: 'USD' };
    }

    try {
      const response = await fetch(`https://api.flutterwave.com/v3/transactions/${input.transactionId}/verify`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${FLUTTERWAVE_SECRET_KEY}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (data.status === 'success' && data.data.status === 'successful') {
        return {
          status: 'success',
          amount: data.data.amount,
          currency: data.data.currency,
          customerEmail: data.data.customer.email,
        };
      }

      return { status: 'failed' };
    } catch (error) {
      console.error('Flutterwave Verification Error:', error);
      throw new Error('Failed to verify payment with Flutterwave');
    }
  }
);
