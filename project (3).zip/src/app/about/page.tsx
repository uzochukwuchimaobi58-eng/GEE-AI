'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  ChevronLeft, 
  Shield, 
  Sparkles, 
  Trophy, 
  Target, 
  Home, 
  Clapperboard, 
  Type, 
  ImageIcon, 
  LayoutGrid, 
  CreditCard, 
  Layers, 
  Settings as SettingsIcon, 
  Headphones, 
  LogOut,
  Play,
  Menu,
  Film
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { useUser, useAuth } from '@/firebase';
import { signOut } from 'firebase/auth';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from '@/components/ui/sheet';

export default function AboutPage() {
  const router = useRouter();
  const { user } = useUser();
  const auth = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const SidebarItem = ({ icon: Icon, label, tab, badge, active }: { icon: any, label: string, tab?: string, badge?: string, active?: boolean }) => (
    <Button 
      variant="ghost" 
      className={`w-full justify-start gap-4 px-4 py-3.5 rounded-xl transition-all font-bold border border-transparent ${active ? 'bg-primary text-white shadow-[0_0_20px_rgba(0,102,255,0.4)]' : 'text-muted-foreground hover:text-white hover:bg-primary/10'}`}
      onClick={() => {
        setIsMobileMenuOpen(false);
        if (tab) router.push(`/studio?tab=${tab}`);
        else if (label === 'Home') router.push('/');
      }}
    >
      <Icon className={`w-5 h-5 ${active ? 'text-white' : ''}`} />
      <span className="flex-1 text-left text-[12px] uppercase tracking-widest">{label}</span>
      {badge && <Badge className="bg-amber-500 text-black border-none text-[8px] px-1.5 h-4 font-black uppercase tracking-tighter ml-auto">{badge}</Badge>}
    </Button>
  );

  const SharedSidebarContent = () => (
    <div className="flex flex-col h-full gap-6 p-6 overflow-y-auto bg-[#020617]">
      <div className="flex flex-col gap-1 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-800 rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
            <span className="text-2xl font-black text-white italic tracking-tighter">GG</span>
          </div>
          <div className="flex flex-col">
            <h1 className="text-xl font-headline font-black tracking-tighter text-white uppercase leading-none">GEE</h1>
            <p className="text-[10px] font-black tracking-[0.2em] text-primary/80 uppercase">GROUP</p>
          </div>
        </div>
        <p className="text-[8px] font-bold tracking-[0.25em] text-muted-foreground/60 uppercase mt-2 px-1">AI VIDEO GENERATOR</p>
      </div>

      <nav className="flex flex-col gap-1.5 mt-4">
        <SidebarItem icon={Home} label="Home" />
        <SidebarItem icon={Clapperboard} label="Create Videos" tab="script" />
        <SidebarItem icon={Type} label="AI Text to Video" tab="generator" />
        <SidebarItem icon={ImageIcon} label="Image to Video" tab="character" />
        <SidebarItem icon={LayoutGrid} label="Market Hub" tab="discovery" />
        <SidebarItem icon={CreditCard} label="Subscription" tab="plans" badge="PRO" />
        <SidebarItem icon={Layers} label="Project Studio" tab="video" />

        <div className="h-px bg-white/5 my-4 mx-2" />

        <SidebarItem icon={SettingsIcon} label="Settings" />
        <SidebarItem icon={Headphones} label="Help & Support" active />
      </nav>
      
      <div className="mt-auto pt-6">
        <Card className="bg-gradient-to-br from-blue-900/40 to-black border border-primary/20 p-5 rounded-[24px] relative overflow-hidden group shadow-2xl">
          <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-primary/20 rounded-full blur-2xl group-hover:scale-150 transition-transform" />
          <h3 className="text-[14px] font-bold text-white mb-1.5 relative z-10">Unleash Creativity</h3>
          <p className="text-[10px] text-muted-foreground mb-4 relative z-10 leading-relaxed font-medium">Turn ideas into stunning videos with AI power.</p>
          <div className="relative z-10 flex justify-end">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shadow-[0_0_20px_rgba(0,102,255,0.4)]">
              <Play className="w-3.5 h-3.5 fill-white text-white" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground wireframe-bg flex">
      {/* DESKTOP PERSISTENT SIDEBAR */}
      <aside className="hidden lg:flex w-72 sidebar-glass flex-col shrink-0 overflow-hidden border-r border-primary/10">
        <SharedSidebarContent />
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <nav className="fixed top-0 left-0 lg:left-72 right-0 z-[100] border-b border-primary/20 bg-background/80 backdrop-blur-md">
          <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 group lg:hidden">
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center border border-primary/40 group-hover:bg-primary/30 transition-all">
                  <Film className="text-primary w-4 h-4" />
              </div>
              <span className="text-xl font-headline font-black tracking-tighter uppercase text-white group-hover:text-primary transition-colors">GEE AI</span>
            </Link>
            
            <div className="flex items-center gap-3 ml-auto">
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-primary bg-primary/10 hover:bg-primary/20 rounded-xl">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="p-0 w-72 bg-[#020617] border-l border-primary/20">
                  <SheetHeader className="sr-only">
                    <SheetTitle>Navigation Menu</SheetTitle>
                    <SheetDescription>Access production nodes and strategic blueprints.</SheetDescription>
                  </SheetHeader>
                  <SharedSidebarContent />
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </nav>

        <div className="max-w-4xl mx-auto p-6 md:p-12 pt-24 space-y-10">
          <Link href="/">
            <Button variant="ghost" className="gap-2 text-primary hover:bg-primary/10 mb-4">
              <ChevronLeft className="w-4 h-4" />
              Back to Command Center
            </Button>
          </Link>

          <header className="space-y-4">
            <h1 className="text-4xl md:text-6xl font-headline font-black text-white uppercase tracking-tighter">
              About <span className="text-primary">GEE AI</span>
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Revolutionizing the Creator Economy through Intelligent Automation and Strategic Production.
            </p>
          </header>

          <section className="space-y-6">
            <h2 className="text-2xl font-headline font-bold text-primary uppercase">The Mission</h2>
            <p className="text-muted-foreground leading-relaxed">
              GEE AI was founded with a singular purpose: to bridge the gap between creative vision and high-output production. In the fast-paced world of YouTube and TikTok, creators often find themselves bogged down by the technicalities of scripting, SEO, and visual assembly. 
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Our suite of tools leverages the H.V.B. (Hook, Value, Bridge) formula and the latest generative AI engines to ensure that every second of your content is optimized for maximum viewer retention and platform growth. We don't just help you make videos; we help you build an automated empire.
            </p>
          </section>

          <section className="grid grid-cols-1 md:grid-cols-2 gap-8 py-4">
            <div className="p-6 bg-card/50 border border-primary/20 rounded-2xl space-y-4">
              <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center border border-primary/30">
                <Trophy className="text-primary w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold uppercase">Proven Growth</h3>
              <p className="text-sm text-muted-foreground">Using AI-driven insights to identify trending niches before they go viral.</p>
            </div>
            <div className="p-6 bg-card/50 border border-primary/20 rounded-2xl space-y-4">
              <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center border border-primary/30">
                <Target className="text-primary w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold uppercase">Strategic Precision</h3>
              <p className="text-sm text-muted-foreground">Every script is drafted with precision to hit the 60-second or 10-minute sweet spots.</p>
            </div>
          </section>

          <section className="space-y-6 bg-primary/5 p-8 md:p-12 rounded-3xl border border-primary/20 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <Sparkles className="w-32 h-32 text-primary" />
            </div>
            <h2 className="text-3xl font-headline font-black text-white uppercase tracking-tight">Meet the Founder</h2>
            <div className="space-y-4 relative z-10">
              <p className="text-lg font-bold text-primary uppercase tracking-widest">Founder of the Gee Group</p>
              <p className="text-muted-foreground leading-relaxed">
                As the architect behind the GEE Group, our founder recognized the shift in digital media early on. With a background in strategic automation and a passion for empowering individual creators, the vision was clear: create a "Node" where anyone, regardless of technical skill, could command the same power as a full production house.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                "Our goal isn't just to provide a tool; it's to provide a partner. GEE AI is the strategist that never sleeps, the editor that never tires, and the researcher that sees every trend."
              </p>
            </div>
          </section>

          <footer className="pt-12 border-t border-primary/10 text-center">
            <p className="text-sm text-muted-foreground uppercase font-black tracking-widest">© 2025 GEE GROUP. ALL RIGHTS RESERVED.</p>
          </footer>
        </div>
      </div>
    </div>
  );
}
