import { NextResponse } from 'next/server';
import { generateVideoFlow } from '@/ai/flows/generate-video-flow';

/**
 * @fileOverview Secure API Route for AI Video Generation.
 * Protected by Node Handshake Protocol (x-gee-node-sig).
 */

export const maxDuration = 300; // 5 minute limit for long-running AI tasks

export async function POST(req: Request) {
  try {
    const signature = req.headers.get('x-gee-node-sig');
    
    // Basic bot/external request protection
    if (!signature || !signature.startsWith('gee_active_node_')) {
      return NextResponse.json({ error: 'Unauthorized: External node rejected.' }, { status: 401 });
    }

    const input = await req.json();
    
    if (!input.userId || (!input.prompt && !input.imageRef) || !input.mode) {
      return NextResponse.json({ error: 'Validation Error: Missing production parameters.' }, { status: 400 });
    }

    console.log(`SECURE_API: Initializing render for ${input.userId} (Mode: ${input.mode}, Ratio: ${input.aspectRatio || '16:9'})`);
    
    const result = await generateVideoFlow(input);
    return NextResponse.json(result);
  } catch (error: any) {
    console.error('SECURE_API_ERROR:', error.message);
    return NextResponse.json(
      { error: error.message || 'The production node encountered a critical error.' },
      { status: 500 }
    );
  }
}