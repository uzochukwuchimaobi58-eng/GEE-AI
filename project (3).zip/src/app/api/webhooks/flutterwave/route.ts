
import { NextResponse } from 'next/server';
import { initializeFirebase } from '@/firebase';
import { doc, updateDoc, increment } from 'firebase/firestore';

/**
 * @fileOverview Flutterwave Webhook Endpoint.
 * 
 * Logic: 
 * 1. Verify payment status.
 * 2. Update credits balance.
 * 3. Switch 'is_premium' to true to instantly hide ads and unlock features.
 */

export async function POST(req: Request) {
  try {
    const secretHash = process.env.FLUTTERWAVE_WEBHOOK_HASH;
    const signature = req.headers.get('verif-hash');

    if (secretHash && signature !== secretHash) {
      console.error('Invalid Flutterwave Webhook Signature');
      return new NextResponse('Invalid signature', { status: 401 });
    }

    const payload = await req.json();
    
    const isSuccessful = payload.status === 'success' || 
                        (payload.data && payload.data.status === 'successful') ||
                        payload.event === 'charge.completed';

    if (isSuccessful) {
      const meta = payload.data?.meta || payload.meta || {};
      const { firebase_uid, add_credits, plan_name } = meta;

      if (firebase_uid) {
        console.log(`Upgrading user to Premium: ${firebase_uid}`);
        
        const { firestore } = initializeFirebase();
        const userRef = doc(firestore, 'users', firebase_uid);

        // Perform the upgrade action: Switch is_premium to true
        // and add the credits associated with the plan.
        await updateDoc(userRef, {
          is_premium: true,
          credits: increment(Number(add_credits || 0)),
          plan: plan_name || 'Premium',
          updatedAt: new Date().toISOString()
        });

        return NextResponse.json({ status: 'success', message: 'Premium status and credits applied' });
      } else {
        console.warn('Webhook received but missing firebase_uid');
      }
    }

    return NextResponse.json({ status: 'received' });
  } catch (error: any) {
    console.error('Flutterwave Webhook Error:', error);
    return new NextResponse(error.message || 'Internal Server Error', { status: 500 });
  }
}
