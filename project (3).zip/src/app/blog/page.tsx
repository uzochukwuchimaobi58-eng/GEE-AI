
import { redirect } from 'next/navigation';

/**
 * @fileOverview The blog listing has been moved to the primary landing page (root).
 * This route now redirects to the home page to maintain SEO link equity.
 */
export default function BlogRedirectPage() {
  redirect('/');
}
