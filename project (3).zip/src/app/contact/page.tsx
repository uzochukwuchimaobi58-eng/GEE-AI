
'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  ChevronLeft, 
  Mail, 
  MessageSquare, 
  Globe, 
  ArrowRight, 
  Github, 
  Twitter,
  Home,
  Clapperboard,
  Type,
  ImageIcon,
  LayoutGrid,
  CreditCard,
  Layers,
  Settings as SettingsIcon,
  Headphones,
  LogOut,
  Play,
  Menu,
  Film
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { useUser, useAuth } from '@/firebase';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from '@/components/ui/sheet';

export default function ContactPage() {
  const router = useRouter();
  const { user } = useUser();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const SidebarItem = ({ icon: Icon, label, tab, badge, active }: { icon: any, label: string, tab?: string, badge?: string, active?: boolean }) => (
    <Button 
      variant="ghost" 
      className={`w-full justify-start gap-4 px-4 py-3.5 rounded-xl transition-all font-bold border border-transparent ${active ? 'bg-primary text-white shadow-[0_0_20px_rgba(0,102,255,0.4)]' : 'text-muted-foreground hover:text-white hover:bg-primary/10'}`}
      onClick={() => {
        setIsMobileMenuOpen(false);
        if (tab) router.push(`/studio?tab=${tab}`);
        else if (label === 'Home') router.push('/');
      }}
    >
      <Icon className={`w-5 h-5 ${active ? 'text-white' : ''}`} />
      <span className="flex-1 text-left text-[12px] uppercase tracking-widest">{label}</span>
      {badge && <Badge className="bg-amber-500 text-black border-none text-[8px] px-1.5 h-4 font-black uppercase tracking-tighter ml-auto">{badge}</Badge>}
    </Button>
  );

  const SharedSidebarContent = () => (
    <div className="flex flex-col h-full gap-6 p-6 overflow-y-auto bg-[#020617]">
      <div className="flex flex-col gap-1 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-800 rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
            <span className="text-2xl font-black text-white italic tracking-tighter">GG</span>
          </div>
          <div className="flex flex-col">
            <h1 className="text-xl font-headline font-black tracking-tighter text-white uppercase leading-none">GEE</h1>
            <p className="text-[10px] font-black tracking-[0.2em] text-primary/80 uppercase">GROUP</p>
          </div>
        </div>
        <p className="text-[8px] font-bold tracking-[0.25em] text-muted-foreground/60 uppercase mt-2 px-1">AI VIDEO GENERATOR</p>
      </div>

      <nav className="flex flex-col gap-1.5 mt-4">
        <SidebarItem icon={Home} label="Home" />
        <SidebarItem icon={Clapperboard} label="Create Videos" tab="script" />
        <SidebarItem icon={Type} label="AI Text to Video" tab="generator" />
        <SidebarItem icon={ImageIcon} label="Image to Video" tab="character" />
        <SidebarItem icon={LayoutGrid} label="Market Hub" tab="discovery" />
        <SidebarItem icon={CreditCard} label="Subscription" tab="plans" badge="PRO" />
        <SidebarItem icon={Layers} label="Project Studio" tab="video" />

        <div className="h-px bg-white/5 my-4 mx-2" />

        <SidebarItem icon={SettingsIcon} label="Settings" />
        <SidebarItem icon={Headphones} label="Help & Support" active />
      </nav>
      
      <div className="mt-auto pt-6">
        <Card className="bg-gradient-to-br from-blue-900/40 to-black border border-primary/20 p-5 rounded-[24px] relative overflow-hidden group shadow-2xl">
          <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-primary/20 rounded-full blur-2xl group-hover:scale-150 transition-transform" />
          <h3 className="text-[14px] font-bold text-white mb-1.5 relative z-10">Unleash Creativity</h3>
          <p className="text-[10px] text-muted-foreground mb-4 relative z-10 leading-relaxed font-medium">Turn ideas into stunning videos with AI power.</p>
          <div className="relative z-10 flex justify-end">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shadow-[0_0_20px_rgba(0,102,255,0.4)]">
              <Play className="w-3.5 h-3.5 fill-white text-white" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground wireframe-bg flex">
      {/* DESKTOP PERSISTENT SIDEBAR */}
      <aside className="hidden lg:flex w-72 sidebar-glass flex-col shrink-0 overflow-hidden border-r border-primary/10">
        <SharedSidebarContent />
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <nav className="fixed top-0 left-0 lg:left-72 right-0 z-[100] border-b border-primary/20 bg-background/80 backdrop-blur-md">
          <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 group lg:hidden">
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center border border-primary/40 group-hover:bg-primary/30 transition-all">
                  <Film className="text-primary w-4 h-4" />
              </div>
              <span className="text-xl font-headline font-black tracking-tighter uppercase text-white group-hover:text-primary transition-colors">GEE AI</span>
            </Link>
            
            <div className="flex items-center gap-3 ml-auto">
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-primary bg-primary/10 hover:bg-primary/20 rounded-xl">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="p-0 w-72 bg-[#020617] border-l border-primary/20">
                  <SheetHeader className="sr-only">
                    <SheetTitle>Navigation Menu</SheetTitle>
                    <SheetDescription>Access production nodes and strategic blueprints.</SheetDescription>
                  </SheetHeader>
                  <SharedSidebarContent />
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </nav>

        <div className="max-w-4xl mx-auto p-6 md:p-12 pt-32 space-y-12">
          <Link href="/">
            <Button variant="ghost" className="gap-2 text-primary hover:bg-primary/10 mb-8">
              <ChevronLeft className="w-4 h-4" />
              Back to Command Center
            </Button>
          </Link>

          <header className="space-y-4">
            <h1 className="text-4xl md:text-6xl font-headline font-black text-white uppercase tracking-tighter">
              Contact <span className="text-primary">Us</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Get in touch with the GEE Group support and sales team.
            </p>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 py-8">
            <Card className="bg-card/50 border-primary/20 rounded-3xl overflow-hidden group">
              <CardContent className="p-8 space-y-6">
                <div className="w-14 h-14 bg-primary/20 rounded-2xl flex items-center justify-center border border-primary/30 group-hover:bg-primary/30 transition-all">
                  <Mail className="text-primary w-7 h-7" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-headline font-bold text-white uppercase">Email Support</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    For technical issues, billing inquiries, or general questions about GEE AI automation.
                  </p>
                </div>
                <a 
                  href="mailto:uzochukwuchimaobi58@gmail.com" 
                  className="inline-flex items-center gap-2 text-primary font-black uppercase tracking-widest hover:underline group-hover:gap-4 transition-all"
                >
                  uzochukwuchimaobi58@gmail.com
                  <ArrowRight className="w-4 h-4" />
                </a>
              </CardContent>
            </Card>

            <Card className="bg-card/50 border-primary/20 rounded-3xl overflow-hidden group">
              <CardContent className="p-8 space-y-6">
                <div className="w-14 h-14 bg-primary/20 rounded-2xl flex items-center justify-center border border-primary/30 group-hover:bg-primary/30 transition-all">
                  <MessageSquare className="text-primary w-7 h-7" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-headline font-bold text-white uppercase">Sales & Partnerships</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Interested in enterprise licenses, custom API access, or partnering with the GEE Group?
                  </p>
                </div>
                <Link 
                  href="mailto:uzochukwuchimaobi58@gmail.com?subject=Partnership Inquiry" 
                  className="inline-flex items-center gap-2 text-primary font-black uppercase tracking-widest hover:underline group-hover:gap-4 transition-all"
                >
                  Inquire Now
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </CardContent>
            </Card>
          </div>

          <section className="bg-white/5 border border-white/10 rounded-3xl p-8 md:p-12 space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2">
                <h2 className="text-3xl font-headline font-black uppercase">Global Presence</h2>
                <p className="text-muted-foreground">Powering creators across YouTube and TikTok ecosystems worldwide.</p>
              </div>
              <div className="flex gap-4">
                <Button variant="outline" size="icon" className="rounded-full border-white/10 bg-white/5"><Github className="w-5 h-5" /></Button>
                <Button variant="outline" size="icon" className="rounded-full border-white/10 bg-white/5"><Twitter className="w-5 h-5" /></Button>
                <Button variant="outline" size="icon" className="rounded-full border-white/10 bg-white/5"><Globe className="w-5 h-5" /></Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8 border-t border-white/10">
              <div className="space-y-1">
                <p className="text-[10px] font-black uppercase tracking-widest text-primary">Office</p>
                <p className="text-sm text-white font-bold">GEE Group Headquarters</p>
                <p className="text-xs text-muted-foreground">Digital-First Operations</p>
              </div>
              <div className="space-y-1">
                <p className="text-[10px] font-black uppercase tracking-widest text-primary">Hours</p>
                <p className="text-sm text-white font-bold">24/7 AI Availability</p>
                <p className="text-xs text-muted-foreground">Support: Mon - Fri</p>
              </div>
              <div className="space-y-1">
                <p className="text-[10px] font-black uppercase tracking-widest text-primary">Response Time</p>
                <p className="text-sm text-white font-bold">&lt; 24 Hours</p>
                <p className="text-xs text-muted-foreground">Standard Support Node</p>
              </div>
            </div>
          </section>

          <footer className="pt-12 text-center">
            <p className="text-xs text-muted-foreground uppercase font-black tracking-widest">GEE AI NODE: CONNECTED</p>
          </footer>
        </div>
      </div>
    </div>
  );
}
