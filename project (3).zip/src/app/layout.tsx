import type {Metadata} from 'next';
import './globals.css';
import { FirebaseClientProvider } from '@/firebase';
import { ConnectivityBanner } from '@/components/studio/ConnectivityBanner';
import { FirebaseErrorListener } from '@/components/FirebaseErrorListener';
import { Inter, Space_Grotesk } from 'next/font/google';

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

const spaceGrotesk = Space_Grotesk({ 
  subsets: ['latin'],
  variable: '--font-space',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'GEE AI | Video Studio',
  description: 'AI-Powered Video Scripting and Editing Studio',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`dark ${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="font-body antialiased selection:bg-primary selection:text-primary-foreground">
        <FirebaseClientProvider>
          <ConnectivityBanner />
          <FirebaseErrorListener />
          {children}
        </FirebaseClientProvider>
      </body>
    </html>
  );
}
