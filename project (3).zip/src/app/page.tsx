
"use client";

import React, { useState, useEffect } from 'react';
import { 
  Film,
  Menu,
  Loader2
} from 'lucide-react';
import { AuthModal } from '@/components/AuthModal';
import { useUser } from '@/firebase';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { ProductionHub } from '@/components/studio/ProductionHub';
import { SettingsDialog } from '@/components/studio/SettingsDialog';
import { TerminalChat } from '@/components/studio/TerminalChat';

export default function LandingPage() {
  const { user, isUserLoading } = useUser();
  const router = useRouter();
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isProductionHubOpen, setIsProductionHubOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  useEffect(() => {
    if (user && !isUserLoading) {
      router.push('/studio');
    }
  }, [user, isUserLoading, router]);

  if (isUserLoading) return <div className="flex h-screen items-center justify-center bg-white"><Loader2 className="w-12 h-12 animate-spin text-blue-600" /></div>;

  return (
    <div className="h-screen bg-white flex flex-col overflow-hidden selection:bg-blue-600/30 font-body">
      {/* HEADER */}
      <header className="h-20 bg-white/90 backdrop-blur-xl z-50 px-6 md:px-10 flex items-center justify-between border-b border-slate-100 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600/5 rounded-xl flex items-center justify-center border border-blue-600/20">
            <Film className="text-blue-600 w-6 h-6" />
          </div>
          <h1 className="text-xl font-headline font-bold text-blue-600 tracking-[0.1em] uppercase leading-none">GEE GROUP</h1>
        </div>

        <div className="flex items-center gap-4 ml-auto">
          <button 
            className="bg-blue-600/5 text-blue-600 hover:bg-blue-600/10 px-6 rounded-xl border border-blue-600/10 font-bold uppercase text-[10px] tracking-[0.2em] h-10 gap-3 flex items-center transition-all group"
            onClick={() => setIsProductionHubOpen(true)}
          >
            <Menu className="w-4 h-4" /> MENU
          </button>
          <Button onClick={() => setIsAuthModalOpen(true)} className="bg-blue-600 hover:bg-blue-700 text-white font-black uppercase text-[10px] tracking-[0.2em] px-8 h-10 rounded-xl shadow-xl shadow-blue-600/20 transition-all border border-blue-600/20">Connect Account</Button>
        </div>
      </header>

      {/* MAIN CHATBOT HUB */}
      <main className="flex-1 overflow-hidden relative">
        <TerminalChat user={user} />
      </main>

      <AuthModal isOpen={isAuthModalOpen} onOpenChange={setIsAuthModalOpen} />
      <SettingsDialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen} />
      <ProductionHub 
        isOpen={isProductionHubOpen} 
        onClose={() => setIsProductionHubOpen(false)} 
        onOpenSettings={() => setIsSettingsOpen(true)}
      />
    </div>
  );
}
