
'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  ChevronLeft, 
  ShieldAlert, 
  Lock, 
  Eye, 
  Database,
  Home,
  Clapperboard,
  Type,
  ImageIcon,
  LayoutGrid,
  CreditCard,
  Layers,
  Settings as SettingsIcon,
  Headphones,
  LogOut,
  Play,
  Menu,
  Film
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { useUser, useAuth } from '@/firebase';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from '@/components/ui/sheet';

export default function PrivacyPage() {
  const router = useRouter();
  const { user } = useUser();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const SidebarItem = ({ icon: Icon, label, tab, badge, active }: { icon: any, label: string, tab?: string, badge?: string, active?: boolean }) => (
    <Button 
      variant="ghost" 
      className={`w-full justify-start gap-4 px-4 py-3.5 rounded-xl transition-all font-bold border border-transparent ${active ? 'bg-primary text-white shadow-[0_0_20px_rgba(0,102,255,0.4)]' : 'text-muted-foreground hover:text-white hover:bg-primary/10'}`}
      onClick={() => {
        setIsMobileMenuOpen(false);
        if (tab) router.push(`/studio?tab=${tab}`);
        else if (label === 'Home') router.push('/');
      }}
    >
      <Icon className={`w-5 h-5 ${active ? 'text-white' : ''}`} />
      <span className="flex-1 text-left text-[12px] uppercase tracking-widest">{label}</span>
      {badge && <Badge className="bg-amber-500 text-black border-none text-[8px] px-1.5 h-4 font-black uppercase tracking-tighter ml-auto">{badge}</Badge>}
    </Button>
  );

  const SharedSidebarContent = () => (
    <div className="flex flex-col h-full gap-6 p-6 overflow-y-auto bg-[#020617]">
      <div className="flex flex-col gap-1 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-800 rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
            <span className="text-2xl font-black text-white italic tracking-tighter">GG</span>
          </div>
          <div className="flex flex-col">
            <h1 className="text-xl font-headline font-black tracking-tighter text-white uppercase leading-none">GEE</h1>
            <p className="text-[10px] font-black tracking-[0.2em] text-primary/80 uppercase">GROUP</p>
          </div>
        </div>
        <p className="text-[8px] font-bold tracking-[0.25em] text-muted-foreground/60 uppercase mt-2 px-1">AI VIDEO GENERATOR</p>
      </div>

      <nav className="flex flex-col gap-1.5 mt-4">
        <SidebarItem icon={Home} label="Home" />
        <SidebarItem icon={Clapperboard} label="Create Videos" tab="script" />
        <SidebarItem icon={Type} label="AI Text to Video" tab="generator" />
        <SidebarItem icon={ImageIcon} label="Image to Video" tab="character" />
        <SidebarItem icon={LayoutGrid} label="Market Hub" tab="discovery" />
        <SidebarItem icon={CreditCard} label="Subscription" tab="plans" badge="PRO" />
        <SidebarItem icon={Layers} label="Project Studio" tab="video" />

        <div className="h-px bg-white/5 my-4 mx-2" />

        <SidebarItem icon={SettingsIcon} label="Settings" active />
        <SidebarItem icon={Headphones} label="Help & Support" />
      </nav>
      
      <div className="mt-auto pt-6">
        <Card className="bg-gradient-to-br from-blue-900/40 to-black border border-primary/20 p-5 rounded-[24px] relative overflow-hidden group shadow-2xl">
          <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-primary/20 rounded-full blur-2xl group-hover:scale-150 transition-transform" />
          <h3 className="text-[14px] font-bold text-white mb-1.5 relative z-10">Unleash Creativity</h3>
          <p className="text-[10px] text-muted-foreground mb-4 relative z-10 leading-relaxed font-medium">Turn ideas into stunning videos with AI power.</p>
          <div className="relative z-10 flex justify-end">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shadow-[0_0_20px_rgba(0,102,255,0.4)]">
              <Play className="w-3.5 h-3.5 fill-white text-white" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground wireframe-bg flex">
      {/* DESKTOP PERSISTENT SIDEBAR */}
      <aside className="hidden lg:flex w-72 sidebar-glass flex-col shrink-0 overflow-hidden border-r border-primary/10">
        <SharedSidebarContent />
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <nav className="fixed top-0 left-0 lg:left-72 right-0 z-[100] border-b border-primary/20 bg-background/80 backdrop-blur-md">
          <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 group lg:hidden">
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center border border-primary/40 group-hover:bg-primary/30 transition-all">
                  <Film className="text-primary w-4 h-4" />
              </div>
              <span className="text-xl font-headline font-black tracking-tighter uppercase text-white group-hover:text-primary transition-colors">GEE AI</span>
            </Link>
            
            <div className="flex items-center gap-3 ml-auto">
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-primary bg-primary/10 hover:bg-primary/20 rounded-xl">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="p-0 w-72 bg-[#020617] border-l border-primary/20">
                  <SheetHeader className="sr-only">
                    <SheetTitle>Navigation Menu</SheetTitle>
                    <SheetDescription>Access production nodes and strategic blueprints.</SheetDescription>
                  </SheetHeader>
                  <SharedSidebarContent />
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </nav>

        <div className="max-w-4xl mx-auto p-6 md:p-12 pt-32 space-y-12">
          <Link href="/">
            <Button variant="ghost" className="gap-2 text-primary hover:bg-primary/10 mb-8">
              <ChevronLeft className="w-4 h-4" />
              Back to Dashboard
            </Button>
          </Link>

          <header className="space-y-4">
            <h1 className="text-4xl md:text-6xl font-headline font-black text-white uppercase tracking-tighter">
              Privacy <span className="text-primary">Policy</span>
            </h1>
            <p className="text-muted-foreground">Effective Date: January 1, 2025</p>
          </header>

          <div className="space-y-12 text-muted-foreground leading-relaxed">
            <section className="space-y-4">
              <div className="flex items-center gap-3 text-white">
                <ShieldAlert className="w-6 h-6 text-primary" />
                <h2 className="text-xl font-bold uppercase tracking-tight">1. Overview</h2>
              </div>
              <p>
                GEE AI, a product of the GEE Group, is committed to protecting your privacy. This policy outlines how we collect, use, and safeguard your data when you use our YouTube and TikTok automation platform. Your trust is our primary asset.
              </p>
            </section>

            <section className="space-y-4">
              <div className="flex items-center gap-3 text-white">
                <Database className="w-6 h-6 text-primary" />
                <h2 className="text-xl font-bold uppercase tracking-tight">2. Data Collection</h2>
              </div>
              <p>
                We collect information that you provide directly to us when you sign up for GEE AI via Google or Email. This includes:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Profile Information: Name, email address, and profile picture (via Google Sign-In).</li>
                <li>Production Data: Scripts, video prompts, and selected niches saved to your cloud profile.</li>
                <li>Transaction Data: Credit balances and purchase history handled securely via Flutterwave.</li>
              </ul>
            </section>

            <section className="space-y-4">
              <div className="flex items-center gap-3 text-white">
                <Lock className="w-6 h-6 text-primary" />
                <h2 className="text-xl font-bold uppercase tracking-tight">3. How We Use Your Data</h2>
              </div>
              <p>
                Your data is used exclusively to power the automation features of the GEE AI node. This includes:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Personalizing your Script Studio experience based on your selected niche.</li>
                <li>Maintaining your credit balance for AI generations.</li>
              </ul>
            </section>

            <section className="space-y-4">
              <div className="flex items-center gap-3 text-white">
                <Eye className="w-6 h-6 text-primary" />
                <h2 className="text-xl font-bold uppercase tracking-tight">4. Third-Party Services</h2>
              </div>
              <p>
                We utilize trusted industry leaders to ensure a seamless experience:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li><span className="text-white">Firebase/Google:</span> For secure authentication and cloud-based Firestore storage.</li>
                <li><span className="text-white">Flutterwave:</span> For encrypted payment processing.</li>
                <li><span className="text-white">Genkit/Gemini:</span> For processing your AI production requests.</li>
              </ul>
            </section>

            <section className="space-y-4 p-8 bg-card border border-primary/10 rounded-2xl">
              <h2 className="text-xl font-bold text-white uppercase tracking-tight">5. Contact Information</h2>
              <p>
                If you have any questions regarding this Privacy Policy or the data practices of the GEE Group, please contact us at:
              </p>
              <a 
                href="mailto:uzochukwuchimaobi58@gmail.com" 
                className="text-primary font-black hover:underline break-all"
              >
                uzochukwuchimaobi58@gmail.com
              </a>
            </section>
          </div>

          <footer className="pt-12 border-t border-primary/10 text-center">
            <p className="text-xs text-muted-foreground uppercase font-black tracking-[0.3em]">GEE GROUP SECURE PROTOCOL</p>
          </footer>
        </div>
      </div>
    </div>
  );
}
