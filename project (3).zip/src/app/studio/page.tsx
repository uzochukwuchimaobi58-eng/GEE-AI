
"use client";

import React, { useState, useEffect, Suspense } from 'react';
import { 
  Film,
  Zap,
  ImageIcon,
  LayoutGrid,
  Loader2,
  Clapperboard,
  Headphones,
  Layers,
  Menu,
  Award,
  Settings,
  Plus,
  ArrowRight,
  ShieldCheck,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Toaster } from '@/components/ui/toaster';
import { useUser, useAuth } from '@/firebase';
import { useRouter, useSearchParams } from 'next/navigation';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

// Component Imports
import { ScriptWriter } from '@/components/studio/ScriptWriter';
import { AIVideoGenerator } from '@/components/studio/AIVideoGenerator';
import { PricingSection } from '@/components/studio/PricingSection';
import { VideoAssembler } from '@/components/studio/VideoAssembler';
import { SettingsDialog } from '@/components/studio/SettingsDialog';
import { UserMenu } from '@/components/studio/UserMenu';
import { TrendingTopics } from '@/components/studio/TrendingTopics';
import { ProductionHub } from '@/components/studio/ProductionHub';
import { YoutubeCustomizationWizard } from '@/components/studio/YoutubeCustomizationWizard';
import { TerminalChat } from '@/components/studio/TerminalChat';

function StudioContent() {
  const searchParams = useSearchParams();
  const [activeTab, setActiveTab] = useState('home');
  const [topic, setTopic] = useState('');
  const [script, setScript] = useState('');
  const [timeline, setTimeline] = useState<any[]>([]);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isProductionHubOpen, setIsProductionHubOpen] = useState(false);
  
  const { user, isUserLoading } = useUser();
  const router = useRouter();

  useEffect(() => {
    const tab = searchParams.get('tab');
    if (tab) setActiveTab(tab);
  }, [searchParams]);

  useEffect(() => {
    if (!isUserLoading && !user) router.push('/');
  }, [user, isUserLoading, router]);

  const TabItem = ({ value, icon: Icon, label, badge }: { value: string, icon: any, label: string, badge?: string }) => (
    <TabsTrigger 
      value={value}
      className="flex items-center gap-2 px-6 h-12 rounded-xl data-[state=active]:bg-blue-600 data-[state=active]:text-white transition-all font-bold uppercase text-[10px] tracking-widest border border-transparent data-[state=active]:shadow-lg data-[state=active]:shadow-blue-600/20"
    >
      <Icon className="w-4 h-4" />
      {label}
      {badge && <Badge className="bg-amber-500 text-black border-none text-[8px] px-1.5 h-4 font-black">{badge}</Badge>}
    </TabsTrigger>
  );

  if (isUserLoading) return <div className="flex h-screen items-center justify-center bg-white"><Loader2 className="w-12 h-12 animate-spin text-blue-600" /></div>;

  return (
    <div className="flex flex-col h-screen bg-white overflow-hidden">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
        {/* HEADER */}
        <header className="h-20 bg-white/95 backdrop-blur-xl z-50 px-6 md:px-10 flex items-center justify-between border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-3">
            <Film className="text-blue-600 w-8 h-8" />
            <h1 className="text-xl font-headline font-bold text-blue-600 tracking-tighter uppercase leading-none">GEE GROUP</h1>
          </div>

          <div className="flex items-center gap-4 ml-auto">
            <Button 
              variant="ghost" 
              className="bg-blue-600/5 text-blue-600 hover:bg-blue-600/10 px-6 rounded-xl border border-blue-600/10 font-bold uppercase text-[10px] tracking-widest h-11 gap-2 shadow-sm"
              onClick={() => setIsProductionHubOpen(true)}
            >
              <Menu className="w-4 h-4" /> MENU
            </Button>
            <UserMenu onNavigate={setActiveTab} />
          </div>
        </header>

        {/* TOP NAVIGATION HUB */}
        <div className="bg-slate-50/50 border-b border-slate-100 px-6 py-2 shrink-0">
          <TabsList className="bg-transparent h-auto p-0 flex justify-start w-full border-none shadow-none">
            <div className="max-w-7xl mx-auto flex items-center gap-2 overflow-x-auto custom-scrollbar pb-1 w-full">
              <TabItem value="home" icon={Zap} label="Home" />
              <TabItem value="discovery" icon={LayoutGrid} label="Select Niche" />
              <TabItem value="script" icon={Clapperboard} label="Script Studio" />
              <TabItem value="text-to-video" icon={Zap} label="Text to Video" />
              <TabItem value="image-to-video" icon={ImageIcon} label="Image to Video" />
              <TabItem value="customize" icon={Settings} label="Customize" />
              <TabItem value="video" icon={Layers} label="Project Vault" />
              <TabItem value="plans" icon={Award} label="Pro" badge="PRO" />
            </div>
          </TabsList>
        </div>

        {/* MAIN CONTENT AREA */}
        <main className="flex-1 overflow-hidden relative bg-white">
          <TabsContent value="home" className="m-0 h-full overflow-hidden">
            <TerminalChat user={user} onNavigate={setActiveTab} />
          </TabsContent>
          
          <TabsContent value="discovery" className="m-0 h-full overflow-y-auto custom-scrollbar"><TrendingTopics onSelectTrend={(t) => { setTopic(t); setActiveTab('script'); }} onNavigate={setActiveTab} /></TabsContent>
          <TabsContent value="script" className="m-0 h-full overflow-y-auto custom-scrollbar"><ScriptWriter script={script} setScript={setScript} topic={topic} setTopic={setTopic} onVideoGenerated={(url) => { setTimeline(prev => [...prev, { url, timelineId: Date.now() }]); setActiveTab('video'); }} onNavigate={setActiveTab} /></TabsContent>
          <TabsContent value="text-to-video" className="m-0 h-full overflow-y-auto custom-scrollbar"><AIVideoGenerator mode="text-to-video" onVideoGenerated={(url) => { setTimeline(prev => [...prev, { url, timelineId: Date.now() }]); setActiveTab('video'); }} onNavigate={setActiveTab} /></TabsContent>
          <TabsContent value="image-to-video" className="m-0 h-full overflow-y-auto custom-scrollbar"><AIVideoGenerator mode="image-to-video" onVideoGenerated={(url) => { setTimeline(prev => [...prev, { url, timelineId: Date.now() }]); setActiveTab('video'); }} onNavigate={setActiveTab} /></TabsContent>
          <TabsContent value="customize" className="m-0 h-full overflow-y-auto custom-scrollbar"><YoutubeCustomizationWizard onNavigate={setActiveTab} user={user} /></TabsContent>
          <TabsContent value="plans" className="m-0 h-full overflow-y-auto custom-scrollbar"><PricingSection onNavigate={setActiveTab} /></TabsContent>
          <TabsContent value="video" className="m-0 h-full overflow-hidden"><VideoAssembler timeline={timeline} setTimeline={setTimeline} script={script} topic={topic} onNavigate={setActiveTab} /></TabsContent>
          <TabsContent value="support" className="m-0 h-full flex flex-col items-center justify-center text-center space-y-4 px-6 overflow-y-auto custom-scrollbar">
            <h2 className="text-4xl font-headline font-black text-foreground uppercase tracking-tighter">Help Center</h2>
            <p className="text-muted-foreground max-w-md uppercase font-bold text-xs">Strategic support node available 24/7.</p>
            <Button onClick={() => window.open("mailto:uzochukwuchimaobi58@gmail.com")} className="bg-blue-600 px-8 h-14 font-black uppercase tracking-widest rounded-2xl shadow-xl shadow-blue-600/20 text-white">Initialize Support Request</Button>
          </TabsContent>
        </main>
      </Tabs>

      <Toaster />
      <SettingsDialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen} />
      <ProductionHub 
        isOpen={isProductionHubOpen} 
        onClose={() => setIsProductionHubOpen(false)} 
        activeTab={activeTab} 
        onNavigate={setActiveTab}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />
    </div>
  );
}

export default function StudioPage() {
  return (
    <Suspense fallback={<div className="flex h-screen items-center justify-center bg-white"><Loader2 className="w-12 h-12 animate-spin text-blue-600" /></div>}>
      <StudioContent />
    </Suspense>
  );
}
