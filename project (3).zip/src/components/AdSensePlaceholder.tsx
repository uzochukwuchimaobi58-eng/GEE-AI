'use client';

import React, { useEffect } from 'react';
import { trackAdImpressionDetailed } from '@/lib/firebase';

/**
 * @fileOverview A placeholder component for Google AdSense.
 * Optimized for the GEE AI web studio dashboard layout.
 * Now includes automatic revenue tracking synchronization with GA4.
 */
export function AdSensePlaceholder() {
  
  useEffect(() => {
    // When the ad component is mounted/rendered, log the impression
    // with an estimated revenue value to populate the analytics dashboard.
    // In production, these values can be passed from your ad provider's API.
    trackAdImpressionDetailed({
      ad_platform: 'Google AdSense',
      ad_source: 'GEE_AI_Direct',
      ad_format: 'Responsive Banner',
      ad_unit_name: 'dashboard_monetization_node',
      value: 0.01, // Estimated $0.01 revenue per impression
      currency: 'USD'
    });
  }, []);

  return (
    <div className="w-full bg-white/5 border border-primary/10 rounded-2xl flex flex-col items-center justify-center text-muted-foreground/30 uppercase font-black text-[10px] tracking-[0.2em] relative overflow-hidden group py-8 md:py-12">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-50" />
      <div className="relative z-10 flex flex-col items-center gap-2">
        <div className="flex items-center gap-2">
          <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-[8px] border border-primary/20">Sponsored</span>
          <span className="text-[7px] text-primary/40 italic">Revenue Node: Active</span>
        </div>
        <span>AdSense Display Unit</span>
        <span className="text-[7px] opacity-50">728 x 90 / Responsive Layout</span>
      </div>
      {/* 
        In production, replace this entire div with your Google AdSense code:
        <ins className="adsbygoogle"
             style={{ display: 'block' }}
             data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
             data-ad-slot="XXXXXXXXXX"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
      */}
    </div>
  );
}
