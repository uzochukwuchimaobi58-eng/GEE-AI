'use client';

import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  initiateEmailSignIn, 
  initiateEmailSignUp, 
  initiateGoogleSignIn 
} from '@/firebase/non-blocking-login';
import { useAuth } from '@/firebase';
import { sendPasswordResetEmail } from 'firebase/auth';
import { Mail, Lock, Chrome, Loader2, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AuthModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AuthModal({ isOpen, onOpenChange }: AuthModalProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const auth = useAuth();
  const { toast } = useToast();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    
    setIsLoading(true);
    try {
      if (isLogin) {
        await initiateEmailSignIn(auth, email, password);
      } else {
        await initiateEmailSignUp(auth, email, password);
      }
      onOpenChange(false);
    } catch (error: any) {
      console.error('Auth error:', error);
      if (error.code === 'auth/operation-not-allowed') {
        toast({
          variant: "destructive",
          title: "Provider Not Enabled",
          description: "Please enable Email/Password and Google in your Firebase Console (Authentication > Sign-in method).",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Authentication Failed",
          description: error.message || "An error occurred during sign in.",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!email || email.trim() === '') {
      toast({
        variant: "destructive",
        title: "Email Required",
        description: "Please type your email in the field below so we know where to send the link.",
      });
      return;
    }

    setIsResetting(true);
    try {
      await sendPasswordResetEmail(auth, email);
      toast({
        title: "Recovery Link Sent",
        description: "Check your inbox for the password reset instructions.",
      });
    } catch (error: any) {
      console.error('Forgot password error:', error);
      let message = "Could not send reset email.";
      if (error.code === 'auth/user-not-found') message = "No account exists with this email.";
      if (error.code === 'auth/invalid-email') message = "Invalid email address format.";
      
      toast({
        variant: "destructive",
        title: "Recovery Error",
        description: message,
      });
    } finally {
      setIsResetting(false);
    }
  };

  const handleGoogleAuth = async () => {
    setIsLoading(true);
    try {
      await initiateGoogleSignIn(auth);
      onOpenChange(false);
    } catch (error: any) {
      console.error('Google auth error:', error);
      if (error.code === 'auth/operation-not-allowed') {
        toast({
          variant: "destructive",
          title: "Google Sign-In Disabled",
          description: "Please enable the Google provider in your Firebase Console.",
        });
      } else if (error.code !== 'auth/popup-closed-by-user') {
        toast({
          variant: "destructive",
          title: "Google Auth Failed",
          description: error.message,
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px] bg-card border-primary/20 p-0 overflow-hidden shadow-2xl">
        <div className="bg-primary/10 p-6 flex flex-col items-center gap-2 border-b border-primary/20">
          <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center border border-primary/40 shadow-[0_0_15px_rgba(38,209,219,0.2)]">
            <Sparkles className="text-primary w-6 h-6" />
          </div>
          <DialogTitle className="text-2xl font-headline font-black text-primary uppercase tracking-tighter">
            {isLogin ? 'Welcome Back' : 'Join GEE AI'}
          </DialogTitle>
          <DialogDescription className="text-[10px] font-bold uppercase text-muted-foreground tracking-widest text-center">
            {isLogin 
              ? 'Access your video automation node.' 
              : 'Create your account and receive 70 FREE Credits.'}
          </DialogDescription>
        </div>

        <div className="p-6 space-y-6">
          <Button 
            variant="outline" 
            className="w-full h-12 gap-3 border-primary/20 hover:bg-primary/5 font-black uppercase tracking-widest text-xs"
            onClick={handleGoogleAuth}
            disabled={isLoading}
          >
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Chrome className="w-5 h-5 text-primary" />}
            Continue with Google
          </Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-primary/10"></span>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground font-bold">Or use email</span>
            </div>
          </div>

          <form onSubmit={handleAuth} className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-[10px] uppercase font-black text-primary/70 tracking-widest">Email Address</Label>
                {isLogin && (
                  <button 
                    type="button" 
                    onClick={handleForgotPassword}
                    disabled={isResetting}
                    className="text-[10px] font-black uppercase text-primary hover:text-white transition-all disabled:opacity-50 py-1 pl-4 relative z-50 cursor-pointer"
                  >
                    {isResetting ? 'Processing...' : 'Forgot Password?'}
                  </button>
                )}
              </div>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  type="email" 
                  placeholder="name@example.com" 
                  className="pl-10 h-11 bg-background/50 border-primary/20"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-black text-primary/70 tracking-widest">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  type="password" 
                  placeholder="••••••••" 
                  className="pl-10 h-11 bg-background/50 border-primary/20"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required={isLogin}
                />
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 bg-primary text-primary-foreground font-black uppercase tracking-widest text-sm shadow-xl shadow-primary/20"
              disabled={isLoading}
            >
              {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : (isLogin ? 'Sign In' : 'Sign Up')}
            </Button>
          </form>

          <div className="flex flex-col items-center gap-4 pt-2">
            <button 
              type="button"
              className="text-[10px] font-black uppercase text-primary hover:underline tracking-widest transition-all"
              onClick={() => setIsLogin(!isLogin)}
            >
              {isLogin 
                ? "Don't have an account? Sign Up" 
                : "Already have an account? Login"}
            </button>
          </div>
        </div>
        
        <div className="bg-muted/30 p-2 border-t border-white/5 text-center">
          <p className="text-[7px] text-muted-foreground uppercase font-black tracking-[0.3em] opacity-40">GEE GROUP SECURE AUTH NODE</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
