
"use client";

import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Sparkles, 
  Loader2, 
  Plus,
  Coins,
  Image as ImageIcon,
  X,
  Type,
  ShieldCheck,
  Monitor,
  Clock,
  Clapperboard,
  Cpu,
  Lock,
  Wand2,
  Smartphone,
  Tv,
  Square,
  RectangleVertical
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth, useFirestore, useDoc, setDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { useOnlineStatus } from '@/hooks/use-online-status';
import { doc } from 'firebase/firestore';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import Image from 'next/image';
import { AuthModal } from '@/components/AuthModal';

/**
 * @fileOverview Visual Engine - Specialized Production Node.
 * Mode: Configurable via prop (Text to Video or Image to Video)
 */

type AspectRatio = '16:9' | '9:16' | '1:1' | '4:5';

const FIXED_RENDER_COST = 50; 

const I2V_PRESETS = [
  "Slow cinematic zoom into the subject.",
  "Dramatic camera pan around the character.",
  "Subtle movement with cinematic lighting shifts.",
  "Dynamic action sequence based on this keyframe.",
  "Ethereal time-lapse effect with moving clouds."
];

export function AIVideoGenerator({ 
  mode = 'text-to-video',
  onVideoGenerated, 
  initialPrompt,
  onNavigate
}: { 
  mode?: 'text-to-video' | 'image-to-video';
  onVideoGenerated: (videoUrl: string) => void; 
  initialPrompt?: string;
  onNavigate?: (tab: string) => void;
}) {
  const [prompt, setPrompt] = useState(initialPrompt || '');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [isGenerating, setIsGenerating] = useState(false);
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const isOnline = useOnlineStatus();

  const auth = useAuth();
  const db = useFirestore();
  const user = auth?.currentUser;
  
  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);
  
  const credits = userProfile?.credits ?? 0;

  useEffect(() => {
    if (initialPrompt) setPrompt(initialPrompt);
  }, [initialPrompt]);

  const saveAssetToCloud = (videoUrl: string) => {
    if (!db || !user) return;
    const assetId = `asset_${Date.now()}`;
    const assetRef = doc(db, 'users', user.uid, 'assets', assetId);
    setDocumentNonBlocking(assetRef, {
      id: assetId,
      userId: user.uid,
      name: `Render: ${prompt.substring(0, 15)}...`,
      type: 'video',
      mimeType: 'video/mp4',
      url: videoUrl,
      sizeBytes: videoUrl.length,
      durationSeconds: 5,
      quality: '720p',
      aspectRatio: aspectRatio,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }, { merge: true });
  };

  const handleGenerate = async () => {
    if (!isOnline) return toast({ variant: "destructive", title: "Offline", description: "Check connection." });
    if (!user) return setShowAuthModal(true);
    
    if (credits < FIXED_RENDER_COST) {
      toast({ 
        variant: "destructive", 
        title: "Insufficient Power", 
        description: `This render requires ${FIXED_RENDER_COST} credits. Please top up your node.` 
      });
      return;
    }

    if (mode === 'image-to-video' && !referenceImage) {
      toast({ variant: "destructive", title: "Reference Required", description: "Please upload an image keyframe." });
      return;
    }

    setIsGenerating(true);
    try {
      const response = await fetch('/api/video/generate', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'x-gee-node-sig': `gee_active_node_${Date.now()}`
        },
        body: JSON.stringify({
          prompt: prompt || (mode === 'text-to-video' ? "Cinematic scene" : "Cinematic scene based on image reference."),
          imageRef: mode === 'image-to-video' ? referenceImage : undefined,
          mode: mode,
          userId: user.uid,
          aspectRatio: aspectRatio,
          quality: '720p'
        })
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Generation failed');
      
      if (result?.videoUrl) {
        saveAssetToCloud(result.videoUrl);
        onVideoGenerated(result.videoUrl);
        toast({ title: "Production Complete", description: `Video rendered at ${aspectRatio} format.` });
      }
    } catch (error: any) {
      toast({ variant: "destructive", title: "Render Error", description: error.message });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-4 md:p-8 h-full flex flex-col gap-6 animate-in fade-in slide-in-from-bottom-2 duration-500 bg-background pb-32 overflow-y-auto custom-scrollbar relative">
      <Button 
        variant="ghost" 
        size="icon" 
        className="absolute top-4 right-4 md:top-8 md:right-8 h-12 w-12 rounded-full bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white border border-white/5 z-[100]"
        onClick={() => onNavigate?.('home')}
      >
        <X className="w-6 h-6" />
      </Button>

      <div className="flex flex-col gap-1.5 shrink-0">
        <h2 className="text-4xl md:text-7xl font-headline font-black text-primary uppercase tracking-tighter leading-none">
          {mode === 'text-to-video' ? 'TEXT TO VIDEO' : 'IMAGE TO VIDEO'}
        </h2>
        <p className="text-[10px] md:text-sm font-bold uppercase tracking-[0.2em] text-muted-foreground">PRODUCTION NODE: <span className="text-primary">ACTIVE</span></p>
      </div>

      <div className="flex flex-col gap-2 shrink-0">
        <Label className="text-[10px] font-black uppercase text-primary/50 tracking-widest px-1">Platform Format</Label>
        <div className="flex bg-muted/50 p-1.5 rounded-2xl border border-primary/10 w-fit flex-wrap gap-1">
          <button 
            className={`h-11 px-4 rounded-xl font-black uppercase text-[9px] tracking-widest gap-2 flex items-center transition-all ${aspectRatio === '16:9' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:text-white'}`}
            onClick={() => setAspectRatio('16:9')}
          >
            <Tv className="w-4 h-4" /> 16:9
          </button>
          <button 
            className={`h-11 px-4 rounded-xl font-black uppercase text-[9px] tracking-widest gap-2 flex items-center transition-all ${aspectRatio === '9:16' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:text-white'}`}
            onClick={() => setAspectRatio('9:16')}
          >
            <Smartphone className="w-4 h-4" /> 9:16
          </button>
          <button 
            className={`h-11 px-4 rounded-xl font-black uppercase text-[9px] tracking-widest gap-2 flex items-center transition-all ${aspectRatio === '1:1' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:text-white'}`}
            onClick={() => setAspectRatio('1:1')}
          >
            <Square className="w-4 h-4" /> 1:1
          </button>
          <button 
            className={`h-11 px-4 rounded-xl font-black uppercase text-[9px] tracking-widest gap-2 flex items-center transition-all ${aspectRatio === '4:5' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:text-white'}`}
            onClick={() => setAspectRatio('4:5')}
          >
            <RectangleVertical className="w-4 h-4" /> 4:5
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 flex-1">
        <div className="lg:col-span-8">
          <Card className="bg-card/30 border-primary/20 min-h-[500px] rounded-[40px] border-2 shadow-2xl overflow-hidden flex flex-col">
            <CardHeader className="py-6 border-b border-primary/10 bg-primary/5 px-8">
              <CardTitle className="text-xs uppercase font-black text-primary tracking-[0.3em] flex items-center gap-3">
                <Cpu className="w-5 h-5" /> {mode === 'text-to-video' ? 'PROMPT TERMINAL' : 'KEYFRAME UPLOAD'}
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 p-0 flex flex-col bg-background/20">
              {mode === 'text-to-video' ? (
                <Textarea 
                  placeholder="Describe your cinematic vision or paste your script content here..." 
                  className="flex-1 w-full border-0 focus-visible:ring-0 bg-transparent resize-none p-10 text-xl leading-relaxed font-body placeholder:text-white/5 font-medium min-h-[400px]"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                />
              ) : (
                <div className="flex flex-col flex-1">
                  <div className="flex flex-col md:flex-row gap-6 p-8">
                    <div 
                      className={`w-full md:w-1/2 aspect-video rounded-3xl border-2 border-dashed flex flex-col items-center justify-center p-4 transition-all cursor-pointer ${!referenceImage ? 'hover:bg-primary/5' : ''}`} 
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <input type="file" className="hidden" ref={fileInputRef} onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => setReferenceImage(reader.result as string);
                          reader.readAsDataURL(file);
                        }
                      }} accept="image/*" />
                      {referenceImage ? (
                        <div className="relative w-full h-full group">
                          <Image src={referenceImage} alt="Ref" fill className="object-contain rounded-2xl" />
                          <Button size="icon" variant="destructive" className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 rounded-full h-8 w-8" onClick={(e) => { e.stopPropagation(); setReferenceImage(null); }}><X className="w-4 h-4" /></Button>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center gap-3 opacity-50">
                          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center"><Plus className="w-6 h-6 text-primary" /></div>
                          <span className="font-black uppercase tracking-widest text-[9px] text-primary">Upload Image</span>
                        </div>
                      )}
                    </div>

                    <div className="w-full md:w-1/2 flex flex-col gap-4">
                      <Label className="text-[10px] uppercase font-black text-primary/70 tracking-widest flex items-center gap-2">
                        <Type className="w-3.5 h-3.5" /> MOVEMENT INSTRUCTIONS
                      </Label>
                      <Textarea 
                        placeholder="Describe how you want the subject to move (e.g., 'Slow zoom into her eyes')..." 
                        className="flex-1 bg-background/50 border-primary/10 focus:border-primary/40 text-sm p-5 rounded-2xl resize-none font-medium leading-relaxed"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="px-8 pb-8 space-y-4">
                    <div className="flex items-center gap-3">
                      <Wand2 className="w-4 h-4 text-primary" />
                      <span className="text-[10px] font-black uppercase text-white/50 tracking-widest">Neural Movement Presets</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {I2V_PRESETS.map((p, idx) => (
                        <button 
                          key={idx}
                          onClick={() => setPrompt(p)}
                          className={`px-4 py-2 rounded-full border text-[9px] font-bold uppercase transition-all ${prompt === p ? 'bg-primary/20 border-primary text-primary shadow-lg' : 'bg-background/40 border-white/5 text-muted-foreground hover:border-primary/30 hover:text-white'}`}
                        >
                          {p.split(' ').slice(0, 3).join(' ')}...
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
            
            <div className="p-8 bg-primary/5 border-t border-primary/10 flex flex-col gap-6">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-3 text-[10px] font-black uppercase text-primary/60 tracking-[0.3em]">
                  <ShieldCheck className="w-4 h-4" /> SECURE RENDERING COST
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-5xl font-black text-white tracking-tighter">{FIXED_RENDER_COST}</span>
                  <span className="text-[9px] font-bold text-primary uppercase tracking-widest mt-1">TOTAL CREDITS REQUIRED</span>
                </div>
              </div>
              <Button 
                onClick={handleGenerate} 
                className="w-full h-24 bg-primary text-primary-foreground font-black uppercase tracking-[0.2em] rounded-[32px] text-xl shadow-2xl group relative overflow-hidden" 
                disabled={isGenerating}
              >
                {isGenerating ? <Loader2 className="w-8 h-8 animate-spin" /> : <Clapperboard className="w-10 h-10 mr-4 group-hover:scale-110 transition-transform" />}
                {isGenerating ? "RENDERING..." : "INITIALIZE RENDER"}
              </Button>
            </div>
          </Card>
        </div>

        <div className="lg:col-span-4 space-y-6">
          <Card className="bg-primary/5 border-primary/20 p-8 rounded-[40px] shadow-2xl">
             <h3 className="text-sm font-headline font-black text-primary uppercase tracking-[0.3em] mb-4">NODE CAPACITY</h3>
             <div className="flex items-center gap-4 bg-background/50 p-6 rounded-3xl border border-primary/10">
                <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center border border-primary/30">
                   <Coins className="w-6 h-6 text-primary" />
                </div>
                <div className="flex flex-col">
                   <span className="text-3xl font-headline font-black text-white leading-none">{(userProfile?.credits ?? 0).toLocaleString()}</span>
                   <span className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest mt-1">CREDITS AVAILABLE</span>
                </div>
             </div>
          </Card>
          
          <div className="p-6 bg-card border border-white/5 rounded-3xl opacity-50 space-y-4">
             <div className="flex items-center gap-2">
                <Monitor className="w-4 h-4 text-primary" />
                <span className="text-[10px] font-black uppercase tracking-widest">Configuration Node</span>
             </div>
             <div className="space-y-2">
                <div className="flex justify-between items-center text-[9px] font-bold uppercase">
                   <span className="text-muted-foreground">Node Pipeline</span>
                   <span className="text-white">Gemini Veo 3.1</span>
                </div>
                <div className="flex justify-between items-center text-[9px] font-bold uppercase">
                   <span className="text-muted-foreground">Output Quality</span>
                   <span className="text-white">720p HD</span>
                </div>
                <div className="flex justify-between items-center text-[9px] font-bold uppercase">
                   <span className="text-muted-foreground">Max Duration</span>
                   <span className="text-white">5 Seconds</span>
                </div>
             </div>
          </div>
        </div>
      </div>
      <AuthModal isOpen={showAuthModal} onOpenChange={setShowAuthModal} />
    </div>
  );
}
