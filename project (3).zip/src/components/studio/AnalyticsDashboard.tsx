"use client"

import * as React from "react"
import { TrendingUp, Users, Eye, Play, Share2 } from "lucide-react"
import { Area, AreaChart, CartesianGrid, XAxis } from "recharts"

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"

const chartData = [
  { week: "Week 1", youtube: 1200, tiktok: 2500 },
  { week: "Week 2", youtube: 2100, tiktok: 3800 },
  { week: "Week 3", youtube: 4500, tiktok: 8200 },
  { week: "Week 4", youtube: 9800, tiktok: 15600 },
]

const chartConfig = {
  youtube: {
    label: "YouTube",
    color: "hsl(var(--primary))",
  },
  tiktok: {
    label: "TikTok",
    color: "hsl(var(--accent))",
  },
} satisfies ChartConfig

export function AnalyticsDashboard() {
  return (
    <div className="p-6 md:p-12 max-w-6xl mx-auto space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col gap-2">
        <h2 className="text-3xl md:text-5xl font-headline font-black text-white tracking-tighter uppercase">
          Channel <span className="text-primary">Analytics</span>
        </h2>
        <p className="text-muted-foreground text-sm md:text-xl">
          Track your viral performance across platforms for the current month.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard title="Total Views" value="1.2M" change="+12%" icon={<Eye className="w-4 h-4" />} />
        <MetricCard title="New Followers" value="45.2K" change="+18%" icon={<Users className="w-4 h-4" />} />
        <MetricCard title="Avg. Retention" value="78%" change="+5%" icon={<Play className="w-4 h-4" />} />
        <MetricCard title="Shares" value="12.4K" change="+24%" icon={<Share2 className="w-4 h-4" />} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <Card className="bg-card/50 border-primary/20 backdrop-blur-xl overflow-hidden relative group">
          <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          <CardHeader className="relative z-10">
            <CardTitle className="text-xl font-headline font-bold text-primary uppercase tracking-tight">YouTube Growth</CardTitle>
            <CardDescription>Monthly subscriber and view progression</CardDescription>
          </CardHeader>
          <CardContent className="relative z-10">
            <ChartContainer config={chartConfig}>
              <AreaChart
                accessibilityLayer
                data={chartData}
                margin={{
                  left: 0,
                  right: 0,
                }}
              >
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis
                  dataKey="week"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }}
                />
                <ChartTooltip
                  cursor={false}
                  content={<ChartTooltipContent indicator="dot" />}
                />
                <Area
                  dataKey="youtube"
                  type="natural"
                  fill="var(--color-youtube)"
                  fillOpacity={0.2}
                  stroke="var(--color-youtube)"
                  strokeWidth={4}
                />
              </AreaChart>
            </ChartContainer>
          </CardContent>
          <CardFooter className="relative z-10 border-t border-white/5 pt-4">
            <div className="flex w-full items-start gap-2 text-xs">
              <div className="grid gap-1">
                <div className="flex items-center gap-2 font-black uppercase leading-none text-white tracking-widest">
                  Trending up by 5.2% this week <TrendingUp className="h-3 w-3 text-primary" />
                </div>
                <div className="flex items-center gap-2 leading-none text-muted-foreground font-bold">
                  Jan 01 - Jan 31, 2025
                </div>
              </div>
            </div>
          </CardFooter>
        </Card>

        <Card className="bg-card/50 border-accent/20 backdrop-blur-xl overflow-hidden relative group">
          <div className="absolute inset-0 bg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          <CardHeader className="relative z-10">
            <CardTitle className="text-xl font-headline font-bold text-accent uppercase tracking-tight">TikTok Growth</CardTitle>
            <CardDescription>Monthly follower and engagement progression</CardDescription>
          </CardHeader>
          <CardContent className="relative z-10">
            <ChartContainer config={chartConfig}>
              <AreaChart
                accessibilityLayer
                data={chartData}
                margin={{
                  left: 0,
                  right: 0,
                }}
              >
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis
                  dataKey="week"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }}
                />
                <ChartTooltip
                  cursor={false}
                  content={<ChartTooltipContent indicator="dot" />}
                />
                <Area
                  dataKey="tiktok"
                  type="natural"
                  fill="var(--color-accent)"
                  fillOpacity={0.2}
                  stroke="var(--color-accent)"
                  strokeWidth={4}
                />
              </AreaChart>
            </ChartContainer>
          </CardContent>
          <CardFooter className="relative z-10 border-t border-white/5 pt-4">
            <div className="flex w-full items-start gap-2 text-xs">
              <div className="grid gap-1">
                <div className="flex items-center gap-2 font-black uppercase leading-none text-white tracking-widest">
                  Trending up by 12.8% this week <TrendingUp className="h-3 w-3 text-accent" />
                </div>
                <div className="flex items-center gap-2 leading-none text-muted-foreground font-bold">
                  Jan 01 - Jan 31, 2025
                </div>
              </div>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

function MetricCard({ title, value, change, icon }: { title: string, value: string, change: string, icon: React.ReactNode }) {
  return (
    <Card className="bg-white/5 border-white/10 p-6 flex flex-col gap-2 group hover:border-primary/40 transition-all shadow-xl backdrop-blur-sm">
      <div className="flex items-center justify-between text-muted-foreground">
        <span className="text-[10px] font-black uppercase tracking-widest leading-none">{title}</span>
        <div className="text-primary group-hover:scale-110 transition-transform opacity-50">{icon}</div>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-3xl font-headline font-black text-white">{value}</span>
        <span className="text-[10px] font-bold text-green-400 bg-green-400/10 px-1.5 py-0.5 rounded">{change}</span>
      </div>
    </Card>
  )
}
