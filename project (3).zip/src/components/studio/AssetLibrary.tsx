"use client";

import React, { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Upload, 
  Search, 
  Grid2X2, 
  List, 
  Plus,
  MoreVertical
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { PlaceHolderImages } from '@/app/lib/placeholder-images';
import Image from 'next/image';

interface AssetLibraryProps {
  assets: any[];
  onAddAsset: (asset: any) => void;
  onAddToTimeline: (asset: any) => void;
}

export function AssetLibrary({ assets, onAddAsset, onAddToTimeline }: AssetLibraryProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onAddAsset({
        name: file.name,
        type: file.type.includes('image') ? 'image' : 'video',
        url: URL.createObjectURL(file),
        size: (file.size / (1024 * 1024)).toFixed(2) + ' MB'
      });
    }
  };

  const combinedAssets = [
    ...assets,
    ...(PlaceHolderImages || []).map(img => ({
      name: img.description,
      type: 'image',
      url: img.imageUrl,
      id: img.id,
      imageHint: img.imageHint
    }))
  ];

  return (
    <div className="p-8 h-full flex flex-col gap-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-4xl font-headline font-bold text-primary">Asset Library</h2>
          <p className="text-muted-foreground">Manage your media components and project files.</p>
        </div>
        <div className="flex gap-3">
          <input 
            type="file" 
            className="hidden" 
            ref={fileInputRef} 
            onChange={handleFileChange}
            accept="image/*,video/*"
          />
          <Button 
            onClick={handleUploadClick}
            className="bg-primary text-primary-foreground gap-2 font-bold"
          >
            <Upload className="w-4 h-4" />
            Upload Asset
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-4 bg-card/50 p-2 rounded-xl border border-border">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input 
            className="pl-10 bg-background/50 border-0" 
            placeholder="Search assets..." 
          />
        </div>
        <div className="flex border-l border-border pl-4 gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-primary">
            <Grid2X2 className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <List className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 overflow-y-auto pb-8">
        {combinedAssets.map((asset, index) => (
          <Card key={asset.id || index} className="group bg-card border-border overflow-hidden hover:border-primary/50 transition-all hover:shadow-lg hover:shadow-primary/10">
            <div className="relative aspect-video bg-muted overflow-hidden">
              <Image 
                src={asset.url} 
                alt={asset.name} 
                fill 
                className="object-cover transition-transform group-hover:scale-105"
                data-ai-hint={asset.imageHint || "media asset"}
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <Button 
                  size="sm" 
                  className="bg-primary text-primary-foreground h-8 px-3 rounded-full font-bold"
                  onClick={() => onAddToTimeline(asset)}
                >
                  <Plus className="w-3 h-3 mr-1" />
                  Add
                </Button>
                <Button size="icon" variant="secondary" className="h-8 w-8 rounded-full">
                  <MoreVertical className="w-3 h-3" />
                </Button>
              </div>
              <div className="absolute top-2 left-2 px-2 py-0.5 bg-black/60 rounded text-[10px] font-bold uppercase tracking-wider text-white">
                {asset.type}
              </div>
            </div>
            <CardContent className="p-3">
              <p className="text-sm font-medium truncate">{asset.name}</p>
              <p className="text-[10px] text-muted-foreground mt-1">{asset.size || '720p HD'}</p>
            </CardContent>
          </Card>
        ))}

        {combinedAssets.length === 0 && (
          <div className="col-span-full h-64 flex flex-col items-center justify-center text-center p-8 border-2 border-dashed border-border rounded-2xl">
            <div className="bg-muted p-4 rounded-full mb-4">
              <Upload className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-lg">No assets yet</h3>
            <p className="text-muted-foreground max-w-xs">Upload your clips and images to start creating your video project.</p>
            <Button variant="link" className="text-primary mt-2" onClick={handleUploadClick}>
              Upload your first asset
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
