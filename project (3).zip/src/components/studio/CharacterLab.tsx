
"use client";

import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  UserCircle, 
  Mic2, 
  Cpu, 
  Zap, 
  Upload, 
  Plus, 
  X, 
  Loader2, 
  Sparkles, 
  ShieldCheck,
  Activity,
  Box,
  Binary
} from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useAuth, useFirestore, useDoc, setDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import Image from 'next/image';
import { AuthModal } from '@/components/AuthModal';

/**
 * @fileOverview Character Lab - AI Avatar Creation Hub.
 * Optimized for high-output scrolling and neural diagnostics.
 */
export function CharacterLab() {
  const [characterImage, setCharacterImage] = useState<string | null>(null);
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [calibrationStep, setCalibrationStep] = useState(0);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  
  const auth = useAuth();
  const db = useFirestore();
  const user = auth?.currentUser;
  
  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);

  const steps = [
    "Analyzing Facial Geometry...",
    "Calibrating Neural Pathways...",
    "Syncing Phoneme Engine...",
    "Generating AI Anchor Nodes..."
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCharacterImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const startCalibration = () => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    if (!characterImage) {
      toast({ variant: "destructive", title: "Error", description: "Upload a character keyframe first." });
      return;
    }

    setIsCalibrating(true);
    setCalibrationStep(0);

    const interval = setInterval(() => {
      setCalibrationStep(prev => {
        if (prev >= steps.length - 1) {
          clearInterval(interval);
          finishCalibration();
          return prev;
        }
        return prev + 1;
      });
    }, 2000);
  };

  const finishCalibration = () => {
    setIsCalibrating(false);
    toast({
      title: "Neural Sync Complete",
      description: "Character profile is now active and ready for narration.",
    });

    if (db && user && characterImage) {
      const charId = `char_${Date.now()}`;
      const charRef = doc(db, 'users', user.uid, 'characters', charId);
      setDocumentNonBlocking(charRef, {
        id: charId,
        userId: user.uid,
        name: "Hypothetical AI Avatar",
        imageUrl: characterImage,
        voiceId: userProfile?.preferredVoice || 'voice-1',
        status: 'active',
        createdAt: new Date().toISOString()
      }, { merge: true });
    }
  };

  return (
    <div className="h-full flex flex-col bg-background relative overflow-y-auto custom-scrollbar pb-32">
      <div className="p-4 md:p-8 space-y-8 animate-in fade-in duration-500">
        {/* Background Neural Grid Animation Effect */}
        <div className="absolute inset-0 pointer-events-none opacity-5 overflow-hidden">
          <div className="absolute inset-0 grid grid-cols-12 grid-rows-12 gap-1 animate-pulse">
            {Array.from({length: 144}).map((_, i) => (
              <div key={i} className="border border-primary/20 rounded-sm" />
            ))}
          </div>
        </div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 shrink-0 relative z-10">
          <div className="flex flex-col">
            <h2 className="text-3xl md:text-5xl font-headline font-black text-primary uppercase tracking-tighter">Avatar Studio</h2>
            <div className="flex items-center gap-2 mt-1">
               <Badge variant="outline" className="bg-primary/10 border-primary/30 text-primary text-[8px] font-black uppercase tracking-widest">Neural Link Enabled</Badge>
               <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-tight">Vocal Anchor: {userProfile?.preferredVoice || "Standard AI Voice"}</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 relative z-10">
          <div className="lg:col-span-7 space-y-6">
            <Card className="bg-card/30 border-primary/20 backdrop-blur-xl h-fit flex flex-col overflow-hidden group">
              <div className="absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-primary/50 to-transparent animate-pulse" />
              <CardHeader className="border-b border-white/5 py-4">
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-3 text-sm uppercase font-black text-primary tracking-widest">
                    <UserCircle className="w-5 h-5" />
                    Neural Character Keyframe
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0 flex flex-col relative min-h-[400px]">
                <div 
                  className={`flex-1 flex flex-col items-center justify-center p-8 transition-all cursor-pointer ${!characterImage ? 'hover:bg-primary/5' : ''}`}
                  onClick={() => !isCalibrating && fileInputRef.current?.click()}
                >
                  <input type="file" className="hidden" ref={fileInputRef} onChange={handleFileChange} accept="image/*" />
                  
                  {characterImage ? (
                    <div className="relative w-full h-full flex items-center justify-center group/img">
                      <div className="relative aspect-square w-full max-w-sm rounded-3xl overflow-hidden border-2 border-primary/30 shadow-[0_0_50px_rgba(38,209,219,0.1)]">
                        <Image src={characterImage} alt="Character" fill className="object-cover" />
                        {isCalibrating && (
                          <div className="absolute inset-x-0 h-1 bg-primary shadow-[0_0_15px_#26D1DB] animate-scan z-20" />
                        )}
                      </div>
                      {!isCalibrating && (
                        <Button 
                          size="icon" 
                          variant="destructive" 
                          className="absolute top-4 right-4 h-10 w-10 opacity-0 group-hover/img:opacity-100 transition-opacity rounded-full shadow-xl"
                          onClick={(e) => { e.stopPropagation(); setCharacterImage(null); }}
                        >
                          <X className="w-5 h-5" />
                        </Button>
                      )}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-6 py-20 text-center">
                      <div className="w-20 h-20 rounded-full bg-primary/5 flex items-center justify-center border border-dashed border-primary/30 group-hover:scale-110 transition-transform">
                        <Upload className="w-6 h-6 text-primary/50" />
                      </div>
                      <div className="space-y-2">
                         <h3 className="text-xl font-headline font-bold text-white uppercase tracking-tight">Upload Narrative Avatar</h3>
                         <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest max-w-[240px]">High-fidelity JPG/PNG required</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-5 space-y-6">
            <Card className="bg-card/50 border-primary/20 backdrop-blur-md p-6 h-fit flex flex-col relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10 rotate-12">
                 <Binary className="w-32 h-32 text-primary" />
              </div>

              <div className="space-y-8 relative z-10">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-primary">
                    <Activity className="w-4 h-4" />
                    <span className="text-[10px] font-black uppercase tracking-widest">System Diagnostics</span>
                  </div>
                  <div className="space-y-3">
                     <div className="flex justify-between items-center bg-black/40 p-3 rounded-lg border border-white/5">
                        <span className="text-[9px] font-bold text-muted-foreground uppercase">Facial Resolution</span>
                        <span className="text-[10px] font-black text-white">4K Neural Net</span>
                     </div>
                     <div className="flex justify-between items-center bg-black/40 p-3 rounded-lg border border-white/5">
                        <span className="text-[9px] font-bold text-muted-foreground uppercase">Phoneme Syncing</span>
                        <span className="text-[10px] font-black text-primary">ENABLED</span>
                     </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-primary">
                    <Box className="w-4 h-4" />
                    <span className="text-[10px] font-black uppercase tracking-widest">Vocal Calibration</span>
                  </div>
                  <div className="bg-primary/5 rounded-2xl p-6 border border-primary/20 space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center border border-primary/30">
                         <Mic2 className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex flex-col gap-0.5">
                         <span className="text-[10px] font-black uppercase text-primary tracking-widest">Active Narrator</span>
                         <span className="text-sm font-bold text-white uppercase italic">{userProfile?.preferredVoice || "Standard AI Voice"}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-10 space-y-4 relative z-10">
                {isCalibrating && (
                  <div className="p-4 bg-primary/10 border border-primary/30 rounded-xl animate-in fade-in slide-in-from-top-2">
                     <div className="flex items-center gap-3">
                        <Loader2 className="w-4 h-4 animate-spin text-primary" />
                        <span className="text-[10px] font-black text-primary uppercase tracking-widest italic">{steps[calibrationStep]}</span>
                     </div>
                  </div>
                )}

                <Button 
                  onClick={startCalibration}
                  disabled={isCalibrating || !characterImage}
                  className="w-full h-16 bg-primary text-primary-foreground text-sm font-black uppercase tracking-[0.2em] shadow-xl shadow-primary/20 hover:scale-[1.02] transition-transform relative group overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                  {isCalibrating ? <Loader2 className="w-6 h-6 animate-spin" /> : <Cpu className="w-6 h-6 mr-3" />}
                  <span>{isCalibrating ? "GGA Syncing..." : "Sync Neural Character"}</span>
                </Button>

                <div className="flex items-center justify-center gap-2 text-[8px] font-bold text-primary/40 uppercase tracking-widest">
                  <ShieldCheck className="w-3 h-3" />
                  Hypothetical AI Core v4.2 Active
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
      
      <AuthModal isOpen={showAuthModal} onOpenChange={setShowAuthModal} />
      
      <style jsx global>{`
        @keyframes scan {
          0% { top: 0; }
          100% { top: 100%; }
        }
        .animate-scan {
          animation: scan 3s linear infinite;
        }
      `}</style>
    </div>
  );
}
