
"use client";

import React, { useState, useMemo } from 'react';
import { 
  History, 
  Search, 
  Pin, 
  Trash2, 
  MessageSquare, 
  Clock, 
  Loader2, 
  ChevronRight,
  PinOff,
  X
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useUser, useFirestore, useCollection, useMemoFirebase, updateDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase';
import { collection, query, orderBy, doc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

export function ChatHistory({ onNavigate, user }: { onNavigate?: (tab: string) => void, user?: any }) {
  const db = useFirestore();
  const { toast } = useToast();
  const [searchTerm, setSearchQuery] = useState('');

  const chatsQuery = useMemoFirebase(() => {
    if (!db || !user) return null;
    return query(
      collection(db, 'users', user.uid, 'chats'),
      orderBy('timestamp', 'desc')
    );
  }, [db, user]);

  const { data: chats, isLoading } = useCollection(chatsQuery);

  const togglePin = (chatId: string, currentPinned: boolean) => {
    if (!db || !user) return;
    const docRef = doc(db, 'users', user.uid, 'chats', chatId);
    updateDocumentNonBlocking(docRef, { isPinned: !currentPinned });
    toast({ title: !currentPinned ? "Chat Pinned" : "Chat Unpinned", description: "History updated node." });
  };

  const deleteChat = (chatId: string) => {
    if (!db || !user) return;
    const docRef = doc(db, 'users', user.uid, 'chats', chatId);
    deleteDocumentNonBlocking(docRef);
    toast({ title: "Chat Purged", description: "Discussion removed from cloud." });
  };

  const filteredChats = useMemo(() => {
    if (!chats) return [];
    return chats.filter(c => 
      c.message?.toLowerCase().includes(searchTerm.toLowerCase()) || 
      c.reply?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [chats, searchTerm]);

  const pinnedChats = filteredChats.filter(c => c.isPinned);
  const recentChats = filteredChats.filter(c => !c.isPinned);

  if (isLoading) return (
    <div className="flex flex-col items-center justify-center py-40 gap-4">
      <Loader2 className="w-12 h-12 animate-spin text-primary" />
      <p className="text-[10px] font-black uppercase tracking-[0.4em] text-primary">SYNCING HISTORY NODE...</p>
    </div>
  );

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-10 animate-in fade-in duration-500 pb-40 relative">
      <Button 
        variant="ghost" 
        size="icon" 
        className="absolute top-4 right-4 md:top-8 md:right-8 h-12 w-12 rounded-full bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white border border-white/5 z-[100]"
        onClick={() => onNavigate?.('home')}
      >
        <X className="w-6 h-6" />
      </Button>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex flex-col gap-1">
          <h2 className="text-4xl md:text-7xl font-headline font-black text-primary uppercase tracking-tighter leading-none">CHAT HISTORY</h2>
          <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest px-1">Permanent strategic vault.</p>
        </div>
        
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            value={searchTerm}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search discussions..." 
            className="pl-10 h-12 bg-card border-primary/20 rounded-xl uppercase text-[10px] font-bold tracking-widest"
          />
        </div>
      </div>

      {pinnedChats.length > 0 && (
        <section className="space-y-6">
          <div className="flex items-center gap-3">
             <Pin className="w-4 h-4 text-primary fill-primary" />
             <span className="text-[10px] font-black uppercase text-primary tracking-[0.4em]">Pinned Nodes</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             {pinnedChats.map(chat => (
               <ChatCard key={chat.id} chat={chat} onPin={togglePin} onDelete={deleteChat} />
             ))}
          </div>
        </section>
      )}

      <section className="space-y-6">
        <div className="flex items-center gap-3">
           <Clock className="w-4 h-4 text-muted-foreground" />
           <span className="text-[10px] font-black uppercase text-muted-foreground tracking-[0.4em]">Recent Discussions</span>
        </div>
        <div className="grid grid-cols-1 gap-4">
           {recentChats.map(chat => (
             <ChatCard key={chat.id} chat={chat} onPin={togglePin} onDelete={deleteChat} />
           ))}
        </div>

        {chats?.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-center gap-4 opacity-40">
             <div className="w-16 h-16 rounded-full border-2 border-dashed border-primary/30 flex items-center justify-center">
                <MessageSquare className="w-6 h-6 text-primary" />
             </div>
             <p className="text-[10px] font-black uppercase tracking-widest max-w-[240px]">No strategic history recorded yet. Start a discussion in the Home terminal.</p>
          </div>
        )}
      </section>
    </div>
  );
}

function ChatCard({ chat, onPin, onDelete }: { chat: any, onPin: (id: string, p: boolean) => void, onDelete: (id: string) => void }) {
  return (
    <Card className="bg-card/40 border-primary/20 hover:border-primary/50 transition-all rounded-[24px] overflow-hidden group">
      <CardContent className="p-6 flex flex-col gap-4">
         <div className="flex items-start justify-between gap-4">
            <div className="flex flex-col gap-1.5 flex-1 min-w-0">
               <span className="text-[8px] font-black text-primary uppercase tracking-widest">{new Date(chat.timestamp).toLocaleString()}</span>
               <h4 className="text-sm font-bold text-white leading-relaxed line-clamp-2 uppercase">"{chat.message}"</h4>
            </div>
            <div className="flex gap-1">
               <Button 
                variant="ghost" 
                size="icon" 
                className={`h-8 w-8 rounded-full ${chat.isPinned ? 'text-primary' : 'text-muted-foreground hover:text-primary'}`}
                onClick={() => onPin(chat.id, chat.isPinned)}
               >
                 {chat.isPinned ? <Pin className="w-4 h-4 fill-primary" /> : <PinOff className="w-4 h-4" />}
               </Button>
               <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 rounded-full text-muted-foreground hover:text-destructive"
                onClick={() => onDelete(chat.id)}
               >
                 <Trash2 className="w-4 h-4" />
               </Button>
            </div>
         </div>
         <div className="p-4 bg-primary/5 rounded-xl border border-white/5">
            <p className="text-[11px] text-muted-foreground leading-relaxed line-clamp-3 italic">
              {chat.reply}
            </p>
         </div>
      </CardContent>
    </Card>
  );
}
