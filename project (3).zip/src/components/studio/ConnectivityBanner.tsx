
'use client';

import React from 'react';
import { useOnlineStatus } from '@/hooks/use-online-status';
import { WifiOff, AlertTriangle } from 'lucide-react';

/**
 * Global banner that appears when the user loses internet connection.
 * Essential for preventing failed Firestore writes and AI generations.
 */
export function ConnectivityBanner() {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[200] bg-destructive text-destructive-foreground py-2 px-4 flex items-center justify-center gap-3 animate-in slide-in-from-top duration-300">
      <WifiOff className="w-5 h-5" />
      <span className="text-sm font-bold uppercase tracking-wider">
        You are offline. Please check your connection to continue creating.
      </span>
      <AlertTriangle className="w-4 h-4 opacity-50 hidden sm:block" />
    </div>
  );
}
