
"use client";

import React, { useMemo, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { 
  Coins, 
  Play, 
  Facebook, 
  Instagram, 
  Youtube, 
  Sparkles, 
  Loader2, 
  Zap,
  CheckCircle2
} from 'lucide-react';
import { useAuth, useFirestore, updateDocumentNonBlocking } from '@/firebase';
import { doc, increment } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

interface FreeCreditsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const TikTokIcon = () => (
  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.17-2.89-.6-4.13-1.47-.13 3.44-.3 6.88-.41 10.32-.15 2.51-1.39 5.02-3.69 6.27-2.3 1.25-5.32 1.16-7.51-.25-2.19-1.41-3.32-4.17-2.8-6.73.41-2.04 1.94-3.88 3.91-4.48.5-.15 1.02-.22 1.54-.23.01 1.4.01 2.8 0 4.2-.42.01-.84.09-1.24.23-1.07.36-1.84 1.49-1.74 2.62.1 1.13.99 2.11 2.1 2.33 1.1.22 2.29-.22 2.91-1.18.39-.59.45-1.31.45-2.01 0-4.73.01-9.46.01-14.19.1-.03.17-.06.26-.06z"/>
  </svg>
);

export function FreeCreditsDialog({ open, onOpenChange }: FreeCreditsDialogProps) {
  const { toast } = useToast();
  const auth = useAuth();
  const db = useFirestore();
  const user = auth?.currentUser;
  const [isWatching, setIsWatching] = useState(false);

  const handleWatchAds = () => {
    setIsWatching(true);
    // Simulate high-authority ad handshake
    setTimeout(() => {
      if (user && db) {
        const userRef = doc(db, 'users', user.uid);
        updateDocumentNonBlocking(userRef, {
          credits: increment(10),
          updatedAt: new Date().toISOString()
        });
        toast({
          title: "Credits Unlocked!",
          description: "10 Production Credits have been added to your node.",
        });
      }
      setIsWatching(false);
    }, 3000);
  };

  const handleSocialFollow = (platform: string) => {
    toast({
      title: "Syncing Social Link",
      description: `Follow verified for ${platform}. Sync complete.`,
    });
    // In production, trigger official social handshake
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px] bg-white border-gray-200 text-gray-900 shadow-2xl p-0 overflow-hidden">
        <div className="bg-orange-600 p-8 flex flex-col items-center gap-4 text-center">
          <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center border border-white/30 backdrop-blur-md shadow-2xl">
            <Coins className="w-8 h-8 text-white" />
          </div>
          <div className="space-y-1">
            <DialogTitle className="text-2xl font-headline font-black uppercase tracking-tighter text-white">
              Claim Free Power
            </DialogTitle>
            <DialogDescription className="text-[10px] font-bold uppercase text-orange-100 tracking-widest">
              Fuel your production node at zero cost.
            </DialogDescription>
          </div>
        </div>

        <div className="p-8 space-y-8">
          <div className="space-y-4">
            <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Visual Revenue Node</p>
            <Button 
              onClick={handleWatchAds}
              disabled={isWatching}
              className="w-full h-16 bg-orange-600 hover:bg-orange-700 text-white font-black uppercase text-sm tracking-[0.2em] rounded-2xl shadow-xl shadow-orange-600/20 gap-4"
            >
              {isWatching ? <Loader2 className="w-6 h-6 animate-spin" /> : <Play className="w-6 h-6" />}
              {isWatching ? "CALIBRATING AD..." : "WATCH ADS FOR 10 CREDITS"}
            </Button>
          </div>

          <div className="space-y-4">
            <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1 text-center">Social Synchronization</p>
            <div className="grid grid-cols-2 gap-4">
              <Button 
                variant="outline" 
                onClick={() => handleSocialFollow('Facebook')}
                className="h-14 border-gray-200 rounded-xl flex items-center gap-3 font-bold text-xs hover:bg-orange-50 hover:border-orange-200 transition-all text-gray-700"
              >
                <Facebook className="w-5 h-5 text-blue-600" /> Facebook
              </Button>
              <Button 
                variant="outline" 
                onClick={() => handleSocialFollow('Instagram')}
                className="h-14 border-gray-200 rounded-xl flex items-center gap-3 font-bold text-xs hover:bg-orange-50 hover:border-orange-200 transition-all text-gray-700"
              >
                <Instagram className="w-5 h-5 text-pink-600" /> Instagram
              </Button>
              <Button 
                variant="outline" 
                onClick={() => handleSocialFollow('YouTube')}
                className="h-14 border-gray-200 rounded-xl flex items-center gap-3 font-bold text-xs hover:bg-orange-50 hover:border-orange-200 transition-all text-gray-700"
              >
                <Youtube className="w-5 h-5 text-red-600" /> YouTube
              </Button>
              <Button 
                variant="outline" 
                onClick={() => handleSocialFollow('TikTok')}
                className="h-14 border-gray-200 rounded-xl flex items-center gap-3 font-bold text-xs hover:bg-orange-50 hover:border-orange-200 transition-all text-gray-700"
              >
                <TikTokIcon /> TikTok
              </Button>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 p-4 border-t border-gray-100 text-center">
           <p className="text-[8px] text-gray-400 uppercase font-black tracking-[0.5em] opacity-50">GEE GROUP PRODUCTION PROTOCOL v4.2</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
