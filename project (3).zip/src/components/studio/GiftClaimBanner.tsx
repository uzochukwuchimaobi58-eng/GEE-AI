
'use client';

import React, { useState, useEffect } from 'react';
import { 
  Gift, 
  Sparkles, 
  ExternalLink 
} from 'lucide-react';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useAuth, useFirestore, useDoc, updateDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { doc, increment } from 'firebase/firestore';

/**
 * @fileOverview A high-conversion gift claim system with advanced logic.
 * - Automatically hides after 10 seconds.
 * - Reappears on exit intent (mouse leaving viewport).
 * - Completely hidden for Paid Users (is_premium: true).
 * - Ultra-compact rectangular layout.
 */
export function GiftClaimBanner() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isBoxOpened, setIsBoxOpened] = useState(false);
  const [isVisible, setIsVisible] = useState(true);

  const auth = useAuth();
  const db = useFirestore();
  const user = auth?.currentUser;
  
  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);
  
  const isPremium = userProfile?.is_premium || false;

  // Auto-hide after 10 seconds
  useEffect(() => {
    const hideTimer = setTimeout(() => {
      setIsVisible(false);
    }, 10000);

    return () => clearTimeout(hideTimer);
  }, []);

  // Show on Exit Intent (Mouse moves to top of screen)
  useEffect(() => {
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !isPremium) {
        setIsVisible(true);
      }
    };

    document.addEventListener('mouseleave', handleMouseLeave);
    return () => document.removeEventListener('mouseleave', handleMouseLeave);
  }, [isPremium]);

  if (isPremium || !isVisible) return null;

  const handleClaim = () => {
    if (userRef) {
      updateDocumentNonBlocking(userRef, {
        credits: increment(5),
        updatedAt: new Date().toISOString()
      });
      setIsBoxOpened(true);
    }
  };

  const handleRedirect = () => {
    window.open("https://omg10.com/4/10429978", "_blank");
    setIsModalOpen(false);
  };

  return (
    <>
      <div className="fixed top-2 left-1/2 -translate-x-1/2 z-[100] px-4 pointer-events-none">
        <div 
          className="max-w-[180px] mx-auto bg-gradient-to-r from-red-600 to-red-500 rounded-full py-1 px-3 flex items-center justify-between cursor-pointer group hover:shadow-[0_0_15px_rgba(220,38,38,0.5)] transition-all animate-in slide-in-from-top duration-500 pointer-events-auto"
          onClick={() => setIsModalOpen(true)}
        >
          <div className="flex items-center gap-1.5">
            <div className="bg-white/20 p-0.5 rounded animate-bounce">
              <Gift className="w-3 h-3 text-white" />
            </div>
            <span className="text-[9px] font-black uppercase tracking-wider text-white">Gift Node Ready</span>
          </div>
          <div className="bg-white text-red-600 px-2 py-0.5 rounded-full font-black text-[8px] uppercase">Claim</div>
        </div>
      </div>

      <Dialog open={isModalOpen} onOpenChange={(open) => {
        setIsModalOpen(open);
        if (!open) setIsBoxOpened(false);
      }}>
        <DialogContent className="sm:max-w-[300px] bg-card border-red-500/30 p-0 overflow-hidden shadow-2xl">
          <DialogHeader className="sr-only">
            <DialogTitle>Production Reward Node</DialogTitle>
            <DialogDescription>Claim your free production credits to power your next viral video.</DialogDescription>
          </DialogHeader>
          <div className="p-8 flex flex-col items-center justify-center text-center space-y-6">
            {!isBoxOpened ? (
              <>
                <div className="relative group cursor-pointer" onClick={handleClaim}>
                  <div className="absolute -inset-4 bg-red-500/20 blur-xl rounded-full animate-pulse" />
                  <div className="w-28 h-20 bg-red-600 relative flex items-center justify-center shadow-2xl border-t-2 border-red-400 rounded-lg group-hover:scale-110 transition-transform">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3 h-full bg-amber-400" />
                    <div className="absolute top-1/2 left-0 -translate-y-1/2 w-full h-3 bg-amber-400" />
                    <Gift className="w-8 h-8 text-white relative z-10 drop-shadow-lg" />
                  </div>
                </div>
                <div className="space-y-1">
                  <h2 className="text-xl font-headline font-black text-white uppercase tracking-tighter">Open Reward!</h2>
                  <p className="text-[8px] text-muted-foreground font-bold uppercase tracking-widest">Click the box to unlock production power</p>
                </div>
              </>
            ) : (
              <div className="animate-in zoom-in-95 fade-in duration-500 space-y-6 w-full">
                <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mx-auto border-2 border-primary shadow-[0_0_20px_rgba(38,209,219,0.3)] relative">
                  <span className="text-3xl font-black text-primary">+5</span>
                  <Sparkles className="absolute -top-3 -right-3 text-primary animate-pulse" />
                </div>
                <div className="space-y-1">
                  <DialogTitle className="text-2xl font-headline font-black text-white uppercase tracking-tighter">Credits Unlocked!</DialogTitle>
                  <DialogDescription className="text-[10px] font-bold text-muted-foreground uppercase">You have received 5 production credits for your node.</DialogDescription>
                </div>
                <Button onClick={handleRedirect} className="w-full h-12 bg-primary text-primary-foreground font-black text-xs uppercase tracking-widest gap-2">
                  Access Bonus Node <ExternalLink className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
          <div className="bg-muted/30 p-2 border-t border-white/5 text-center">
            <p className="text-[7px] text-muted-foreground uppercase font-black tracking-[0.2em] opacity-40">GEE GROUP SECURE PROTOCOL</p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
