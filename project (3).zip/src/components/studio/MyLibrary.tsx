
"use client";

import React, { useMemo } from 'react';
import { 
  Library, 
  Film, 
  Clock, 
  Download, 
  Trash2, 
  Plus, 
  Loader2, 
  Cloud, 
  ShieldCheck,
  Search,
  LayoutGrid,
  List,
  Monitor
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useUser, useFirestore, useCollection, useMemoFirebase, deleteDocumentNonBlocking } from '@/firebase';
import { collection, query, orderBy, doc } from 'firebase/firestore';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';

/**
 * @fileOverview GEE AI Cloud Library - Permanent Archive for Renders.
 * Syncs all assets generated across Script Studio and Visual Engine.
 * Optimized for natural flow within parent scrolling containers.
 */
export function MyLibrary({ onSelectAsset }: { onSelectAsset?: (asset: any) => void }) {
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();

  const assetsQuery = useMemoFirebase(() => {
    if (!db || !user) return null;
    return query(
      collection(db, 'users', user.uid, 'assets'),
      orderBy('createdAt', 'desc')
    );
  }, [db, user]);

  const { data: assets, isLoading } = useCollection(assetsQuery);

  const handleDelete = (id: string) => {
    if (!db || !user) return;
    const docRef = doc(db, 'users', user.uid, 'assets', id);
    deleteDocumentNonBlocking(docRef);
    toast({ title: "Asset Purged", description: "Metadata removed from cloud vault." });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 h-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col gap-2">
          <h2 className="text-3xl md:text-5xl font-headline font-black text-primary uppercase tracking-tighter leading-none">MY LIBRARY</h2>
          <div className="flex items-center gap-3">
             <Badge variant="outline" className="bg-primary/10 border-primary/40 text-primary text-[8px] font-black uppercase tracking-widest px-3 py-1 rounded-full">
               Cloud Secured
             </Badge>
             <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">
               Permanent archive of your viral renders.
             </p>
          </div>
        </div>
        <div className="flex items-center gap-3 bg-card/50 p-1.5 rounded-2xl border border-primary/20 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input className="bg-transparent border-0 h-10 pl-9 text-[10px] font-bold uppercase" placeholder="Search archive..." />
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4 opacity-50">
           <Loader2 className="w-12 h-12 animate-spin text-primary" />
           <p className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Synchronizing Node...</p>
        </div>
      ) : assets && assets.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {assets.map((asset) => (
            <Card key={asset.id} className="bg-card/30 border-2 border-white/5 hover:border-primary/40 transition-all rounded-[32px] overflow-hidden group shadow-2xl">
              <div className="relative aspect-video bg-black/40 overflow-hidden">
                <Image 
                  src={asset.url} 
                  alt={asset.name} 
                  fill 
                  className="object-cover opacity-70 group-hover:scale-105 transition-transform" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                   <div className="flex gap-2">
                     <Button 
                      className="flex-1 bg-primary text-primary-foreground font-black uppercase text-[9px] tracking-widest h-10 rounded-xl"
                      onClick={() => onSelectAsset?.(asset)}
                     >
                       <Plus className="w-3.5 h-3.5 mr-2" /> Add to Timeline
                     </Button>
                     <Button 
                      variant="destructive" 
                      size="icon" 
                      className="h-10 w-10 rounded-xl"
                      onClick={() => handleDelete(asset.id)}
                     >
                       <Trash2 className="w-4 h-4" />
                     </Button>
                   </div>
                </div>
                <div className="absolute top-4 left-4 flex gap-2">
                  <Badge className="bg-black/60 backdrop-blur-md border-none text-[8px] font-black uppercase">{asset.aspectRatio || '16:9'}</Badge>
                  <Badge className="bg-primary/20 text-primary border-primary/30 text-[8px] font-black uppercase">{asset.durationSeconds}s</Badge>
                </div>
              </div>
              <CardContent className="p-6 space-y-3">
                <div className="flex flex-col gap-1">
                  <h3 className="text-xs font-black text-white uppercase truncate tracking-tight">{asset.name}</h3>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    <span className="text-[8px] font-bold uppercase tracking-widest">{new Date(asset.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                   <div className="flex items-center gap-2">
                     <Monitor className="w-3 h-3 text-primary/60" />
                     <span className="text-[8px] font-black uppercase text-primary/60 tracking-widest">720p HD Render</span>
                   </div>
                   <Cloud className="w-3.5 h-3.5 text-green-400 opacity-50" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
          <div className="w-24 h-24 rounded-full bg-primary/5 border-2 border-dashed border-primary/20 flex items-center justify-center">
            <Cloud className="w-10 h-10 text-primary/40" />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-headline font-black text-white uppercase tracking-tight">Archive Empty</h3>
            <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.2em] max-w-xs">Your production node has no recorded renders. Start creating in the Script Studio or Visual Engine to build your archive.</p>
          </div>
        </div>
      )}

      <div className="bg-primary/5 p-8 rounded-[40px] border border-primary/20 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl relative overflow-hidden mt-12">
        <div className="absolute top-0 right-0 p-8 opacity-5">
           <ShieldCheck className="w-32 h-32 text-primary" />
        </div>
        <div className="flex items-center gap-6 relative z-10">
           <div className="w-14 h-14 bg-primary/20 rounded-2xl flex items-center justify-center border border-primary/30">
              <Cloud className="text-primary w-7 h-7" />
           </div>
           <div>
              <h4 className="text-xl font-headline font-black text-white uppercase tracking-tight leading-none mb-1">Persistent Node Integrity</h4>
              <p className="text-[9px] text-muted-foreground uppercase font-bold tracking-widest">All metadata is encrypted and synchronized across the GEE AI distributed node network.</p>
           </div>
        </div>
        <Button variant="outline" className="relative z-10 border-primary/30 text-primary font-black uppercase text-[10px] tracking-widest h-12 px-8 rounded-2xl hover:bg-primary/5">
          Request Vault Audit
        </Button>
      </div>
    </div>
  );
}
