
"use client";

import React, { useState, useMemo } from 'react';
import { Check, Sparkles, Zap, Rocket, Shield, Youtube, ArrowRight, Mail, Coins, Info, Globe, Star, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useUser, useFirestore, updateDocumentNonBlocking } from '@/firebase';
import { AuthModal } from '@/components/AuthModal';
import { doc, increment } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

export function PricingSection({ onNavigate }: { onNavigate?: (tab: string) => void }) {
  const [isYearly, setIsYearly] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const { user } = useUser();
  const db = useFirestore();
  const { toast } = useToast();

  const userRef = useMemo(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);

  const getCredits = (base: number) => {
    return isYearly ? Math.floor(base * 1.2) : base; // 20% bonus for yearly
  };

  const getPrice = (monthly: number) => {
    return isYearly ? Math.floor(monthly * 0.8) : monthly; // 20% discount for yearly
  };

  const plans = [
    {
      name: "Starter",
      price: getPrice(14).toString(),
      description: "Essential tools for individual creators starting their automation journey.",
      features: [
        "400 Production Credits",
        "10 AI Script Generations", 
        "720p Draft Exports", 
        "Basic Keyword Research",
        "Standard Rendering Speed"
      ],
      icon: <Zap className="w-5 h-5 text-primary" />,
      buttonText: "Start Creating",
      variant: "outline" as const,
      isPaid: true,
      credits: getCredits(400)
    },
    {
      name: "Starter Pro",
      price: getPrice(29).toString(),
      description: "The professional choice for consistent viral growth.",
      features: [
        "1,000 Production Credits",
        "Unlimited AI Scripting", 
        "1080p Full HD Exports", 
        "AI Thumbnail Concept Lab",
        "Priority Rendering Queue",
        "H.V.B. Retention Strategy"
      ],
      icon: <Star className="w-5 h-5 text-amber-400" />,
      buttonText: "Get Starter Pro",
      variant: "default" as const,
      popular: true,
      isPaid: true,
      credits: getCredits(1000)
    },
    {
      name: "Growth",
      price: getPrice(79).toString(),
      description: "Advanced automation for high-output production nodes.",
      features: [
        "2,500 Production Credits", 
        "4K Ultra HD Exports", 
        "Advanced Channel Analytics",
        "1 Professional Niche Sync",
        "Premium AI Voice Tones",
        "Priority Support Node"
      ],
      icon: <Rocket className="w-5 h-5 text-primary" />,
      buttonText: "Scale My Channel",
      variant: "outline" as const,
      isPaid: true,
      credits: getCredits(2500)
    },
    {
      name: "Elite",
      price: getPrice(249).toString(),
      description: "The ultimate power suite for agencies and production houses.",
      features: [
        "10,000 Production Credits", 
        "Unlimited 4K Rendering", 
        "Full Channel Branding Pack",
        "GEE AI API Access",
        "Dedicated Success Manager",
        "White-label Project Links"
      ],
      icon: <Globe className="w-5 h-5 text-primary" />,
      buttonText: "Go Elite",
      variant: "outline" as const,
      isPaid: true,
      credits: getCredits(10000)
    }
  ];

  const handleUpgrade = (plan: any) => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }

    const paystackKey = "pk_test_7b5df25d94e883113a718f8af42db507e91f811a";

    // Dynamically load Paystack V2 script
    const script = document.createElement("script");
    script.src = "https://js.paystack.co/v2/inline.js";
    script.async = true;
    script.onload = () => {
      try {
        const paystack = new (window as any).PaystackPop();
        
        // --- NGN CONVERSION LOGIC ---
        // For Nigerian accounts, we use NGN. 1 USD approx 1600 NGN.
        // amount is in kobo (NGN cents).
        const exchangeRate = 1600; 
        const amountInNaira = Number(plan.price) * exchangeRate;
        const amountInKobo = Math.round(amountInNaira * 100);

        paystack.newTransaction({
          key: paystackKey,
          email: user.email || "guest@geeaistudio.com",
          amount: amountInKobo,
          currency: 'NGN', // Switched to NGN to support standard merchant nodes
          onSuccess: (transaction: any) => {
            console.log("Paystack Success:", transaction);
            if (userRef) {
              updateDocumentNonBlocking(userRef, {
                credits: increment(plan.credits),
                is_premium: true,
                plan: plan.name,
                updatedAt: new Date().toISOString()
              });
              toast({
                title: "Upgrade Successful",
                description: `Successfully added ${plan.credits.toLocaleString()} credits to your account.`,
              });
            }
          },
          onCancel: () => {
            toast({
              title: "Payment Cancelled",
              description: "The transaction was closed before completion.",
            });
          }
        });
      } catch (err) {
        console.error("Paystack initialization failed:", err);
        toast({
          variant: "destructive",
          title: "Payment Engine Error",
          description: "Could not initialize the payment gateway. Please try again.",
        });
      }
    };
    document.body.appendChild(script);
  };

  const handleEmailRedirect = () => {
    window.open("mailto:uzochukwuchimaobi58@gmail.com?subject=YouTube Channel Setup Service Inquiry&body=Hi GEE AI Team, I am interested in the $100 YouTube Channel Setup and Optimization service. Please guide me on the manual payment steps.", "_blank");
  };

  const handleContactSales = () => {
    window.open("mailto:uzochukwuchimaobi58@gmail.com?subject=Enterprise Sales Inquiry&body=Hi GEE AI Team, I am interested in discussing custom limits, team management, or dedicated API infrastructure for my organization.", "_blank");
  };

  return (
    <TooltipProvider>
      <div className="p-8 h-full flex flex-col gap-8 animate-in fade-in slide-in-from-bottom-4 duration-500 overflow-y-auto bg-background/50 custom-scrollbar pb-32 relative">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute top-4 right-4 md:top-8 md:right-8 h-12 w-12 rounded-full bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white border border-white/5 z-[100]"
          onClick={() => onNavigate?.('home')}
        >
          <X className="w-6 h-6" />
        </Button>

        <div className="text-center max-w-2xl mx-auto space-y-6">
          <div className="space-y-2">
            <h2 className="text-5xl font-headline font-black text-primary tracking-tighter uppercase">Production Tiers</h2>
            <p className="text-muted-foreground text-lg">
              Unlock the full power of GEE AI automation with our professional production plans.
            </p>
          </div>

          <div className="flex items-center justify-center gap-4 py-4">
            <Label htmlFor="billing-toggle" className={`text-sm font-medium ${!isYearly ? 'text-foreground' : 'text-muted-foreground'}`}>Monthly</Label>
            <Switch 
              id="billing-toggle" 
              checked={isYearly} 
              onCheckedChange={setIsYearly}
              className="data-[state=checked]:bg-primary"
            />
            <Label htmlFor="billing-toggle" className={`text-sm font-medium ${isYearly ? 'text-foreground' : 'text-muted-foreground'}`}>
              Yearly <span className="text-primary text-xs font-bold ml-1">(20% Discount + Bonus Credits)</span>
            </Label>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto w-full items-stretch">
          {plans.map((plan) => (
            <Card 
              key={plan.name} 
              className={`relative flex flex-col bg-card border-border transition-all hover:shadow-2xl duration-300 ${plan.popular ? 'border-primary ring-1 ring-primary shadow-primary/20 scale-105 z-10 bg-primary/[0.02]' : 'hover:border-primary/50'}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground font-black px-4 py-1 border-none uppercase tracking-tighter">Great Value</Badge>
                </div>
              )}
              
              <CardHeader className="space-y-4">
                <div className="flex items-center gap-2">
                  {plan.icon}
                  <CardTitle className="text-2xl font-headline font-black uppercase tracking-tighter">{plan.name}</CardTitle>
                </div>
                <div className="flex flex-col">
                  <div className="flex items-baseline gap-1">
                    <span className="text-5xl font-black">${plan.price}</span>
                    <span className="text-muted-foreground font-medium text-sm">/mo</span>
                  </div>
                  {isYearly && plan.isPaid && (
                    <span className="text-[10px] text-primary font-bold uppercase mt-1 tracking-widest">Billed annually</span>
                  )}
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <div className="flex items-center gap-1.5 bg-primary/10 px-3 py-1 rounded-full border border-primary/20">
                    <Coins className="w-4 h-4 text-primary" />
                    <span className={`font-black text-foreground uppercase tracking-widest ${plan.popular ? 'text-sm' : 'text-xs'}`}>
                      {plan.credits.toLocaleString()} Credits / mo
                    </span>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="w-3.5 h-3.5 text-muted-foreground cursor-help ml-1" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-[200px] text-[10px] p-3 uppercase font-bold tracking-wider">
                        <p>1 Credit = 1 Image Generation.</p>
                        <p className="mt-1">50 Credits = 1 Standard Video Render.</p>
                        <p className="mt-1">1000 Credits = 1 4K Ultra Render.</p>
                      </TooltipContent>
                    </Tooltip>
                  </div>
                </div>

                <CardDescription className="text-xs leading-relaxed min-h-[40px] font-medium">{plan.description}</CardDescription>
              </CardHeader>

              <CardContent className="flex-1 space-y-4">
                <div className="space-y-3">
                  {plan.features.map((feature) => (
                    <div key={feature} className="flex items-start gap-3 text-[11px] font-bold uppercase tracking-tight">
                      <Check className="w-4 h-4 shrink-0 mt-0.5 text-primary" />
                      <span className="text-foreground/90">{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>

              <CardFooter className="pt-6">
                <Button 
                  className={`w-full font-black uppercase tracking-widest h-12 text-xs transition-all ${plan.popular ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'hover:border-primary hover:text-primary'}`} 
                  variant={plan.variant}
                  onClick={() => handleUpgrade(plan)}
                >
                  {plan.buttonText}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="max-w-6xl mx-auto w-full mt-12 mb-12">
          <Card className="overflow-hidden border-2 border-primary/30 bg-gradient-to-br from-primary/5 via-card to-primary/5 shadow-[0_0_30px_rgba(255,215,0,0.1)]">
            <div className="grid grid-cols-1 lg:grid-cols-12">
              <div className="lg:col-span-8 p-8 md:p-12 space-y-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center border border-primary/30">
                    <Youtube className="w-7 h-7 text-primary" />
                  </div>
                  <div>
                    <Badge variant="outline" className="text-[10px] border-primary/40 text-primary uppercase tracking-widest font-bold mb-1">Specialized Service</Badge>
                    <h3 className="text-3xl font-headline font-black text-foreground uppercase tracking-tighter">YouTube Channel Setup & Optimization</h3>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-xs font-bold uppercase tracking-tight text-muted-foreground">Full Channel Picture & Logo Design</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-xs font-bold uppercase tracking-tight text-muted-foreground">High-Conversion Channel Description</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-xs font-bold uppercase tracking-tight text-muted-foreground">Optimized Channel Tags & SEO Keywords</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-xs font-bold uppercase tracking-tight text-muted-foreground">Strategic Niche Blueprint Access</p>
                  </div>
                </div>
              </div>
              
              <div className="lg:col-span-4 bg-primary/10 p-8 md:p-12 flex flex-col items-center justify-center text-center border-l border-primary/20">
                <div className="mb-6">
                  <span className="text-sm font-bold text-muted-foreground line-through opacity-50 block">$199.00</span>
                  <span className="text-6xl font-black text-foreground">$100</span>
                  <span className="text-xs font-black text-primary block mt-1 uppercase tracking-widest">Manual One-Time Payment</span>
                </div>
                <Button 
                  onClick={handleEmailRedirect}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-black h-14 text-sm gap-2 shadow-xl shadow-primary/20 uppercase tracking-widest"
                >
                  <Mail className="w-5 h-5" />
                  Buy Now
                  <ArrowRight className="w-5 h-5 ml-1" />
                </Button>
              </div>
            </div>
          </Card>
        </div>

        <div className="bg-primary/10 rounded-3xl p-8 max-w-4xl mx-auto w-full flex flex-col md:flex-row items-center justify-between gap-6 border border-primary/20 backdrop-blur-sm mb-12">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 bg-primary/20 rounded-2xl flex items-center justify-center border border-primary/20 shadow-inner">
              <Shield className="text-primary w-7 h-7" />
            </div>
            <div>
              <h3 className="font-black text-xl font-headline uppercase tracking-tighter">Enterprise Security</h3>
              <p className="text-sm text-muted-foreground max-w-md font-medium">Need custom limits, team management, or dedicated API infrastructure? Contact our sales team.</p>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="shrink-0 border-primary/30 hover:bg-primary hover:text-primary-foreground px-8 h-12 font-black uppercase tracking-widest transition-all"
            onClick={handleContactSales}
          >
            Contact Sales
          </Button>
        </div>
      </div>
      <AuthModal isOpen={isAuthModalOpen} onOpenChange={setIsAuthModalOpen} />
    </TooltipProvider>
  );
}
