"use client";

import React, { useState, useEffect } from 'react';
import { 
  X, 
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  Sun,
  Moon
} from 'lucide-react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

interface ProductionHubProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab?: string;
  onNavigate?: (tab: string) => void;
  onOpenSettings?: () => void;
}

export function ProductionHub({ isOpen, onClose, activeTab, onNavigate, onOpenSettings }: ProductionHubProps) {
  const router = useRouter();
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  useEffect(() => {
    const savedTheme = localStorage.getItem('gee_ai_theme') as 'dark' | 'light';
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle('light', savedTheme === 'light');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    localStorage.setItem('gee_ai_theme', newTheme);
    document.documentElement.classList.toggle('light', newTheme === 'light');
  };

  if (!isOpen) return null;

  const handleLink = (tab: string) => {
    if (onNavigate) {
      onNavigate(tab);
    } else {
      router.push(`/studio?tab=${tab}`);
    }
    onClose();
  };

  const HubTextItem = ({ label, tab, active, meta }: { label: string, tab: string, active?: boolean, meta?: string }) => (
    <button 
      onClick={() => handleLink(tab)}
      className={`group w-full py-4 text-left border-b border-border flex items-center justify-between transition-all hover:pl-4 ${active ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}
    >
      <div className="flex flex-col">
        <span className="text-[18px] font-bold uppercase tracking-widest leading-none">
          {label}
        </span>
        {meta && <span className="text-[8px] font-black tracking-[0.3em] text-primary/40 mt-2 uppercase">{meta}</span>}
      </div>
      <ArrowRight className={`w-5 h-5 opacity-0 group-hover:opacity-100 transition-all ${active ? 'opacity-100' : '-translate-x-4 group-hover:translate-x-0'}`} />
    </button>
  );

  const UtilityLink = ({ label, onClick, href }: { label: string, onClick?: () => void, href?: string }) => {
    const className = "text-[11px] font-black uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground transition-all text-left w-fit flex items-center gap-2 group/util";
    if (href) {
      return (
        <Link href={href} onClick={onClose} className={className}>
          <ChevronRight className="w-3 h-3 opacity-0 group-hover/util:opacity-100 transition-all -translate-x-2 group-hover/util:translate-x-0" />
          {label}
        </Link>
      );
    }
    return (
      <button onClick={() => { onClick?.(); onClose(); }} className={className}>
        <ChevronRight className="w-3 h-3 opacity-0 group-hover/util:opacity-100 transition-all -translate-x-2 group-hover/util:translate-x-0" />
        {label}
      </button>
    );
  };

  return (
    <div className="fixed inset-0 z-[300] bg-background animate-in fade-in duration-500 flex flex-col p-6 md:p-12 overflow-y-auto custom-scrollbar">
      <div className="absolute inset-0 wireframe-bg opacity-10 pointer-events-none" />
      
      <div className="max-w-2xl mx-auto w-full flex-1 flex flex-col gap-12 relative z-10">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-primary" />
            </div>
            <span className="text-[10px] font-black tracking-[0.4em] text-muted-foreground uppercase">Secure Node Terminal</span>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={toggleTheme}
              className="flex items-center gap-2 bg-muted p-1 rounded-full border border-border"
            >
              <div className={`p-2 rounded-full transition-all ${theme === 'light' ? 'bg-background text-primary shadow-sm' : 'text-muted-foreground'}`}>
                <Sun className="w-4 h-4" />
              </div>
              <div className={`p-2 rounded-full transition-all ${theme === 'dark' ? 'bg-background text-primary shadow-sm' : 'text-muted-foreground'}`}>
                <Moon className="w-4 h-4" />
              </div>
            </button>

            <button 
              onClick={onClose}
              className="w-14 h-14 bg-card rounded-full flex items-center justify-center border border-border hover:bg-muted transition-all text-foreground shadow-2xl group"
            >
              <X className="w-6 h-6 group-hover:rotate-90 transition-transform" />
            </button>
          </div>
        </header>

        <div className="flex-1 flex flex-col justify-center py-6">
          <div className="flex flex-col gap-2 mb-10">
            <div className="flex items-center gap-4">
              <div className="h-[2px] w-12 bg-primary/40" />
              <span className="text-[11px] font-black uppercase tracking-[0.5em] text-primary">Production Hub</span>
            </div>
            <h2 className="text-3xl font-headline font-black text-foreground uppercase tracking-tighter ml-16">Initialize Access</h2>
          </div>

          <div className="flex flex-col">
            <HubTextItem label="DASHBOARD HOME" tab="home" active={activeTab === 'home'} meta="Strategic Overview" />
            <HubTextItem label="SELECT NICHE" tab="discovery" active={activeTab === 'discovery'} meta="Niche Calibration" />
            <HubTextItem label="CREATE VIDEOS" tab="script" active={activeTab === 'script'} meta="H.V.B. Formula Engine" />
            <HubTextItem label="TEXT TO VIDEO" tab="text-to-video" active={activeTab === 'text-to-video'} meta="Cinematic Renders" />
            <button 
              onClick={() => { router.push('/'); onClose(); }}
              className="group w-full py-4 text-left border-b border-border flex items-center justify-between transition-all hover:pl-4 text-muted-foreground hover:text-foreground"
            >
              <div className="flex flex-col">
                <span className="text-[18px] font-bold uppercase tracking-widest leading-none">
                  BLOG HUB
                </span>
                <span className="text-[8px] font-black tracking-[0.3em] text-primary/40 mt-2 uppercase">Insights & Strategy</span>
              </div>
              <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all -translate-x-4 group-hover:translate-x-0" />
            </button>
            <HubTextItem label="IMAGE TO VIDEO" tab="image-to-video" active={activeTab === 'image-to-video'} meta="Neural Movement" />
            <HubTextItem label="PRO SUBSCRIPTION" tab="plans" active={activeTab === 'plans'} meta="Tier Selection" />
            <HubTextItem label="PROJECT VAULT" tab="video" active={activeTab === 'video'} meta="Cloud Archive" />
          </div>
        </div>

        <footer className="py-12 flex flex-col md:flex-row items-start md:items-end justify-between gap-10 border-t border-border">
          <div className="flex flex-col gap-6">
            <span className="text-[10px] font-black tracking-[0.4em] text-primary/60 uppercase mb-2">Management & Nodes</span>
            <div className="grid grid-cols-2 gap-x-12 gap-y-5">
              <UtilityLink label="SETTINGS" onClick={onOpenSettings} />
              <UtilityLink label="ABOUT GEE" href="/about" />
              <UtilityLink label="CONTACT US" href="/contact" />
              <UtilityLink label="PRIVACY POLICY" href="/privacy" />
              <UtilityLink label="HELP NODE" onClick={() => handleLink('support')} />
            </div>
          </div>
          
          <div className="flex flex-col items-end gap-2 opacity-30">
            <p className="text-[8px] font-black uppercase tracking-[0.6em] text-muted-foreground text-right">GEE GROUP PRODUCTION NODE v4.2</p>
            <div className="flex items-center gap-1">
              {[1,2,3,4,5,6].map(i => <div key={i} className="w-1 h-1 rounded-full bg-primary" />)}
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}