"use client";

import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Badge } from '@/components/ui/badge';
import { User, CreditCard, Sparkles, ShieldCheck, X } from 'lucide-react';
import { useAuth, useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';

interface ProfileDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ProfileDialog({ open, onOpenChange }: ProfileDialogProps) {
  const auth = useAuth();
  const db = useFirestore();
  const user = auth?.currentUser;
  
  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);

  const isPremium = userProfile?.is_premium || false;

  const handleClose = () => {
    onOpenChange(false);
    // Hard-reset handshake to ensure body interaction is restored
    setTimeout(() => {
      document.body.style.pointerEvents = 'auto';
      document.body.style.overflow = 'auto';
    }, 100);
  };

  return (
    <Dialog open={open} onOpenChange={(val) => { if(!val) handleClose(); else onOpenChange(true); }}>
      <DialogContent className="sm:max-w-[500px] bg-white border-gray-200 text-gray-900 shadow-2xl p-0 overflow-hidden">
        <div className="bg-orange-50 p-8 border-b border-orange-100 flex flex-col items-center gap-4 relative">
          <button 
            onClick={handleClose}
            className="absolute top-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center border border-orange-100 hover:bg-orange-100 transition-all text-orange-600 shadow-sm"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-white border-4 border-white shadow-xl flex items-center justify-center overflow-hidden">
              {user?.photoURL ? (
                <img src={user.photoURL} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <User className="w-12 h-12 text-orange-600" />
              )}
            </div>
            {isPremium && (
              <div className="absolute -top-1 -right-1 bg-amber-400 p-2 rounded-full shadow-lg border-2 border-white">
                <Sparkles className="w-4 h-4 text-black" />
              </div>
            )}
          </div>
          <div className="text-center">
            <DialogTitle className="text-2xl font-headline font-black uppercase tracking-tighter text-orange-600">
              {user?.displayName || "Creator Node"}
            </DialogTitle>
            <DialogDescription className="text-[10px] font-bold uppercase text-orange-900/60 tracking-widest mt-1">
              {user?.email}
            </DialogDescription>
          </div>
        </div>

        <div className="p-8 space-y-6">
          <Card className="bg-gray-50 border-gray-100 p-6 rounded-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center border border-gray-100 shadow-sm">
                  <CreditCard className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Active Plan</p>
                  <p className="text-sm font-bold text-gray-900 uppercase">{userProfile?.plan || "Trial"}</p>
                </div>
              </div>
              <Badge variant="outline" className="border-orange-200 text-orange-600 font-black text-[9px] uppercase px-3 py-1">
                {isPremium ? 'PRO STATUS' : 'LOCKED'}
              </Badge>
            </div>
            {!isPremium && (
              <p className="text-[10px] text-gray-500 font-medium leading-relaxed italic">
                Upgrade to a production tier to unlock 4K rendering and professional SEO tools.
              </p>
            )}
          </Card>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
               <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Created At</p>
               <p className="text-xs font-bold text-gray-700">{userProfile?.createdAt ? new Date(userProfile.createdAt).toLocaleDateString() : 'N/A'}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-xl border border-gray-100">
               <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Node Signature</p>
               <p className="text-[9px] font-mono text-gray-500 truncate">{user?.uid}</p>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 p-4 border-t border-gray-100 flex items-center justify-center gap-2">
           <ShieldCheck className="w-3 h-3 text-orange-600/40" />
           <p className="text-[8px] text-gray-400 uppercase font-black tracking-[0.5em]">GEE GROUP SECURE PROFILE</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}