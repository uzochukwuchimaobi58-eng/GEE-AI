
"use client";

import React, { useState, useMemo } from 'react';
import { generateVideoScript } from '@/ai/flows/generate-video-script-flow';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Sparkles, 
  FileText, 
  Loader2, 
  Wand2, 
  Copy, 
  Check, 
  Zap,
  Coins,
  ShieldCheck,
  Clapperboard,
  Clock,
  Monitor,
  Lock,
  Save,
  ArrowRight,
  X
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useUser, useFirestore, useDoc, setDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { useOnlineStatus } from '@/hooks/use-online-status';

const DURATIONS = [
  { label: '6 - 60 SECONDS', seconds: 60, baseCost: 60 },
  { label: '1 - 5 MINUTES', seconds: 300, baseCost: 300 },
  { label: '5 - 10 MINUTES', seconds: 600, baseCost: 1000 },
  { label: '10 - 40 MINUTES', seconds: 2400, baseCost: 4000 },
];

const QUALITIES = [
  { id: '720p', label: '720p Standard', multiplier: 1, minPlan: 'Trial' },
  { id: '1080p', label: '1080p Pro', multiplier: 5, minPlan: 'Starter' },
  { id: '2k', label: '2K Studio', multiplier: 10, minPlan: 'Growth' },
  { id: '4k', label: '4K Cinema', multiplier: 20, minPlan: 'Elite' },
];

export function ScriptWriter({ script, setScript, topic, setTopic, onVideoGenerated, onNavigate }: {
  script: string;
  setScript: (s: string) => void;
  topic: string;
  setTopic: (t: string) => void;
  onVideoGenerated?: (url: string) => void;
  onNavigate?: (tab: string) => void;
}) {
  const [tone, setTone] = useState('informative');
  const [platform, setPlatform] = useState<string>('YouTube');
  const [selectedDurationId, setSelectedDurationId] = useState('60');
  const [selectedQualityId, setSelectedQualityId] = useState('720p');
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [isRenderingVideo, setIsRenderingVideo] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const { toast } = useToast();
  const { user } = useUser();
  const isOnline = useOnlineStatus();
  const db = useFirestore();
  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);

  const currentPlan = userProfile?.plan || 'Trial';
  const credits = userProfile?.credits ?? 0;

  const selectedDuration = DURATIONS.find(d => d.seconds.toString() === selectedDurationId) || DURATIONS[0];
  const selectedQuality = QUALITIES.find(q => q.id === selectedQualityId) || QUALITIES[0];

  const currentCost = useMemo(() => {
    return Math.ceil(selectedDuration.baseCost * selectedQuality.multiplier);
  }, [selectedDuration, selectedQuality]);

  const isQualityLocked = (qualityPlan: string) => {
    const planPower: Record<string, number> = { 'Trial': 0, 'Starter': 1, 'Starter Pro': 1, 'Growth': 2, 'Elite': 3 };
    const userPower = planPower[currentPlan] || 0;
    const requiredPower = planPower[qualityPlan] || 0;
    return userPower < requiredPower;
  };

  const saveScriptToCloud = (scriptContent: string) => {
    if (!db || !user || !scriptContent) return;
    
    setIsSaving(true);
    const projectId = userProfile?.activeProjectId || `proj_${Date.now()}`;
    const scriptId = `script_${Date.now()}`;
    
    const projectRef = doc(db, 'users', user.uid, 'projects', projectId);
    setDocumentNonBlocking(projectRef, {
      id: projectId,
      userId: user.uid,
      name: topic || "Untitled Project",
      updatedAt: new Date().toISOString(),
      lastAccessedAt: new Date().toISOString()
    }, { merge: true });

    const scriptRef = doc(db, 'users', user.uid, 'projects', projectId, 'scripts', scriptId);
    setDocumentNonBlocking(scriptRef, {
      id: scriptId,
      projectId,
      title: `Draft: ${topic?.substring(0, 20)}...`,
      content: scriptContent,
      topicPrompt: topic,
      stylePrompt: tone,
      costCredits: 0, 
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }, { merge: true });

    setTimeout(() => {
      setIsSaving(false);
      toast({ title: "Securely Saved", description: "Your script blueprint is now in the cloud." });
    }, 500);
  };

  const handleGenerateScript = async () => {
    if (!topic || !platform) return;
    setIsGeneratingScript(true);
    try {
      const durationId = selectedDuration.seconds <= 60 ? 'short' : selectedDuration.seconds <= 300 ? 'medium' : 'long';
      const result = await generateVideoScript({ 
        topic, 
        tone, 
        platform: platform as any,
        durationId
      });
      setScript(result.script);
      saveScriptToCloud(result.script);
      toast({ title: "Strategic Script Ready!", description: "H.V.B. Formula applied." });
    } catch (error: any) {
      toast({ variant: "destructive", title: "Engine Busy", description: "Strategic node load high. Please retry." });
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const saveAssetToCloud = (videoUrl: string) => {
    if (!db || !user) return;
    const assetId = `asset_${Date.now()}`;
    const assetRef = doc(db, 'users', user.uid, 'assets', assetId);
    setDocumentNonBlocking(assetRef, {
      id: assetId,
      userId: user.uid,
      name: `Script Render: ${topic?.substring(0, 15) || 'Project'}...`,
      type: 'video',
      mimeType: 'video/mp4',
      url: videoUrl,
      sizeBytes: videoUrl.length,
      durationSeconds: selectedDuration.seconds,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }, { merge: true });
  };

  const handleCreateVideo = async () => {
    if (!isOnline) return toast({ variant: "destructive", title: "Offline", description: "Check connection." });
    if (!user) return toast({ variant: "destructive", title: "Sign In", description: "Authentication required." });
    if (credits < currentCost) return toast({ variant: "destructive", title: "Insufficient Power", description: `Required: ${currentCost}.` });
    if (!script) return toast({ variant: "destructive", title: "Script Required", description: "Draft a script first." });

    setIsRenderingVideo(true);
    try {
      const response = await fetch('/api/video/generate', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'x-gee-node-sig': `gee_active_node_${Date.now()}`
        },
        body: JSON.stringify({
          prompt: script,
          mode: 'text-to-video',
          userId: user.uid,
          aspectRatio: '16:9',
          quality: selectedQuality.id
        })
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Rendering failed');
      
      if (result?.videoUrl) {
        saveAssetToCloud(result.videoUrl);
        toast({ title: "Production Complete", description: "Video rendered. Sending to Export Studio..." });
        onVideoGenerated?.(result.videoUrl);
      }
    } catch (error: any) {
      toast({ variant: "destructive", title: "Render Error", description: error.message });
    } finally {
      setIsRenderingVideo(false);
    }
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 bg-background pb-32 relative">
      <Button 
        variant="ghost" 
        size="icon" 
        className="absolute top-4 right-4 md:top-8 md:right-8 h-12 w-12 rounded-full bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white border border-white/5 z-[100]"
        onClick={() => onNavigate?.('home')}
      >
        <X className="w-6 h-6" />
      </Button>

      <div className="flex flex-col gap-2">
        <h2 className="text-4xl md:text-8xl font-headline font-black text-primary uppercase tracking-tighter leading-none">CREATE VIDEO</h2>
        <p className="text-muted-foreground text-[10px] md:text-sm font-bold uppercase tracking-[0.2em] max-w-2xl">
          NODE STATUS: <span className="text-primary">SECURED</span>
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-2">
        <div className="lg:col-span-5 space-y-6">
          <Card className="bg-card/50 border-primary/20 shadow-2xl overflow-hidden rounded-[40px] border-2">
            <CardHeader className="pt-10 pb-2 px-8 flex flex-col items-center">
              <CardTitle className="flex items-center gap-3 text-sm font-headline font-black tracking-[0.3em] text-primary uppercase">
                <Wand2 className="w-5 h-5" />
                Strategist Config
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-10 p-8 md:p-10">
              <div className="space-y-4">
                <Label className="text-[10px] uppercase font-black tracking-[0.2em] text-white/70 block text-center">Video topic or script draft</Label>
                <Textarea 
                  id="topic" 
                  placeholder="Explain your vision..." 
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="bg-background/80 min-h-[320px] border-primary/10 focus:border-primary/50 transition-all resize-none text-base p-8 rounded-3xl font-body leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label className="text-[9px] uppercase font-black text-primary/70 tracking-widest flex items-center gap-2 px-1">Platform</Label>
                  <Select value={platform} onValueChange={setPlatform}>
                    <SelectTrigger className="bg-background/50 h-12 border-primary/10 rounded-2xl text-[10px] font-black uppercase tracking-widest"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="YouTube">YouTube</SelectItem>
                      <SelectItem value="TikTok">TikTok</SelectItem>
                      <SelectItem value="Instagram">Instagram</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-3">
                  <Label className="text-[9px] uppercase font-black text-primary/70 tracking-widest flex items-center gap-2 px-1">Tone</Label>
                  <Select value={tone} onValueChange={setTone}>
                    <SelectTrigger className="bg-background/50 h-12 border-primary/10 rounded-2xl text-[10px] font-black uppercase tracking-widest"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="informative">Informative</SelectItem>
                      <SelectItem value="humorous">Humorous</SelectItem>
                      <SelectItem value="motivational">Motivational</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button 
                onClick={handleGenerateScript} 
                className="w-full h-20 bg-primary text-primary-foreground text-sm font-black uppercase tracking-[0.3em] shadow-2xl shadow-primary/30 hover:scale-[1.02] transition-all rounded-3xl relative overflow-hidden group"
                disabled={isGeneratingScript || !topic}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                {isGeneratingScript ? <Loader2 className="w-6 h-6 animate-spin" /> : <Sparkles className="w-6 h-6 mr-3" />}
                {isGeneratingScript ? "CALIBRATING..." : "Draft Strategy"}
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7 flex flex-col gap-6">
          <Card className="bg-card/30 border-primary/20 min-h-[700px] flex flex-col overflow-hidden rounded-[40px] border-2 shadow-2xl">
            <CardHeader className="flex flex-row items-center justify-between border-b border-primary/10 py-6 px-10 bg-primary/5">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center border border-primary/30">
                  <FileText className="w-6 h-6 text-primary" />
                </div>
                <div className="flex flex-col">
                  <span className="font-black text-[12px] uppercase tracking-[0.3em] text-white">Manual Editing Node</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-1 p-0 flex flex-col bg-background/20">
              <Textarea 
                className="flex-1 w-full border-0 focus-visible:ring-0 bg-transparent resize-none p-10 text-xl leading-relaxed font-body placeholder:text-white/5 font-medium"
                placeholder="Strategically optimized script rendered here..."
                value={script}
                onChange={(e) => setScript(e.target.value)}
              />
            </CardContent>

            <div className="p-8 bg-primary/5 border-y border-primary/10 grid grid-cols-1 md:grid-cols-2 gap-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none"><Coins className="w-32 h-32 text-primary" /></div>
              
              <div className="space-y-4 relative z-[60]">
                <Label className="text-[10px] uppercase font-black text-primary/70 tracking-widest flex items-center gap-2 px-1">
                  <Clock className="w-3.5 h-3.5" /> Video Duration
                </Label>
                <Select value={selectedDurationId} onValueChange={setSelectedDurationId}>
                  <SelectTrigger className="w-full h-16 bg-background/50 border-primary/20 rounded-2xl px-6 font-black uppercase text-xs tracking-widest">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-primary/20 z-[100]">
                    {DURATIONS.map((dur) => (
                      <SelectItem key={dur.seconds} value={dur.seconds.toString()} className="h-14">
                        <div className="flex items-center justify-between w-full min-w-[240px]">
                          <span className="font-black text-[10px]">{dur.label}</span>
                          <Badge variant="outline" className="text-[9px] ml-4">{dur.baseCost} Base</Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-4 relative z-[60]">
                <Label className="text-[10px] uppercase font-black text-primary/70 tracking-widest flex items-center gap-2 px-1">
                  <Monitor className="w-3.5 h-3.5" /> Export Quality
                </Label>
                <Select value={selectedQualityId} onValueChange={setSelectedQualityId}>
                  <SelectTrigger className="w-full h-16 bg-background/50 border-primary/20 rounded-2xl px-6 font-black uppercase text-xs tracking-widest">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-primary/20 z-[100]">
                    {QUALITIES.map((q) => {
                      const locked = isQualityLocked(q.minPlan);
                      return (
                        <SelectItem key={q.id} value={q.id} disabled={locked} className="h-14">
                           <div className="flex items-center justify-between w-full min-w-[240px]">
                             <div className="flex items-center gap-2">
                               <span className="font-black text-[10px]">{q.label}</span>
                               {locked && <Lock className="w-3 h-3 text-muted-foreground" />}
                             </div>
                             <Badge variant="secondary" className="text-[9px] ml-4">x{q.multiplier} Power</Badge>
                           </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <CardFooter className="p-8 bg-primary/5 flex flex-col gap-6">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-3 text-[10px] font-black uppercase text-primary/60 tracking-[0.3em]">
                  <ShieldCheck className="w-4 h-4" /> SECURE RENDERING COST
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-5xl font-black text-white tracking-tighter">{currentCost.toLocaleString()}</span>
                  <span className="text-[9px] font-bold text-primary uppercase tracking-widest mt-1">Total Credits Required</span>
                </div>
              </div>
              <div className="flex gap-4">
                <Button 
                  variant="outline" 
                  className="h-24 px-8 border-primary/20 rounded-[32px] text-primary hover:bg-primary/10"
                  onClick={() => saveScriptToCloud(script)}
                  disabled={!script || isSaving}
                >
                  {isSaving ? <Loader2 className="w-6 h-6 animate-spin" /> : <Save className="w-6 h-6" />}
                </Button>
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground font-black h-24 rounded-[32px] gap-4 shadow-2xl transition-all uppercase tracking-[0.3em] group text-xl"
                  onClick={handleCreateVideo}
                  disabled={!script || isQualityLocked(selectedQuality.minPlan) || isRenderingVideo}
                >
                  {isRenderingVideo ? <Loader2 className="w-10 h-10 animate-spin" /> : <Clapperboard className="w-10 h-10 group-hover:scale-110 transition-transform" />}
                  {isQualityLocked(selectedQuality.minPlan) ? "UPGRADE TO UNLOCK" : isRenderingVideo ? "RENDERING..." : "CREATE VIDEOS"}
                </Button>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
