"use client";

import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Cpu, 
  Zap,
  Volume2,
  Coffee,
  Lock,
  ArrowUpRight,
  Mail,
  Copy,
  Library,
  BarChart3,
  Loader2,
  Settings,
  ShieldCheck,
  Globe,
  Info,
  X,
  MessageSquare,
  Users,
  LayoutGrid,
  ShoppingBag,
  CheckCircle2,
  Clapperboard
} from 'lucide-react';
import { useAuth, useFirestore, useDoc, updateDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MyLibrary } from './MyLibrary';
import { AnalyticsDashboard } from './AnalyticsDashboard';
import { Badge } from '@/components/ui/badge';

const VOICE_TONES = [
  { id: 'energetic', name: 'Energetic', icon: <Zap className="w-4 h-4" />, pitch: 1.2, rate: 1.2 },
  { id: 'professional', name: 'Professional', icon: <Volume2 className="w-4 h-4" />, pitch: 1.0, rate: 1.0 },
  { id: 'calm', name: 'Calm', icon: <Coffee className="w-4 h-4" />, pitch: 0.8, rate: 0.8 },
];

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialTab?: string;
}

export function SettingsDialog({ open, onOpenChange, initialTab = 'production' }: SettingsDialogProps) {
  const { toast } = useToast();
  const auth = useAuth();
  const db = useFirestore();
  const user = auth?.currentUser;
  
  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);
  
  const [hardwareAcceleration, setHardwareAcceleration] = useState(true);
  const [autoSave, setAutoSave] = useState(true);
  const [selectedTone, setSelectedTone] = useState('professional');
  const [activeTab, setActiveTab] = useState(initialTab);

  const isElite = userProfile?.plan === 'Elite';

  useEffect(() => {
    if (open) setActiveTab(initialTab);
  }, [open, initialTab]);

  const handleClose = () => {
    onOpenChange(false);
    setTimeout(() => {
      document.body.style.pointerEvents = 'auto';
      document.body.style.overflow = 'auto';
    }, 100);
  };

  const handleApply = () => {
    if (userRef) {
      updateDocumentNonBlocking(userRef, {
        preferredTone: selectedTone,
        hardwareAcceleration,
        autoSave,
        updatedAt: new Date().toISOString()
      });
      toast({ title: "Configuration Locked", description: "Node settings synchronized." });
    }
  };

  return (
    <Dialog open={open} onOpenChange={(val) => { if(!val) handleClose(); else onOpenChange(true); }}>
      <DialogContent className="sm:max-w-[1000px] w-[95vw] h-[85vh] bg-white border-gray-200 text-gray-900 shadow-2xl p-0 overflow-hidden flex flex-col">
        <DialogHeader className="sr-only">
          <DialogTitle>Management Hub Settings</DialogTitle>
          <DialogDescription>Configure production node settings and hardware calibration.</DialogDescription>
        </DialogHeader>

        <div className="bg-blue-600 p-6 flex items-center justify-between shrink-0 relative">
          <div className="flex flex-col">
            <h2 className="flex items-center gap-3 text-2xl font-headline font-black text-white uppercase tracking-tighter leading-none">
              <Settings className="w-6 h-6 text-blue-100" />
              Management Hub
            </h2>
            <p className="text-blue-100/60 uppercase text-[9px] font-black tracking-[0.2em] mt-1">GEE GROUP PRODUCTION NODE v4.2 SECURE</p>
          </div>
          <button 
            onClick={handleClose} 
            className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center border border-white/20 hover:bg-white/20 transition-all text-white shadow-xl group"
          >
            <X className="w-6 h-6 group-hover:rotate-90 transition-transform" />
          </button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <div className="px-6 border-b border-gray-100 bg-white shadow-sm z-10">
            <ScrollArea className="w-full" orientation="horizontal">
              <TabsList className="h-16 bg-transparent gap-8 p-0 w-max">
                <TabsTrigger value="production" className="data-[state=active]:text-blue-600 data-[state=active]:border-b-4 data-[state=active]:border-blue-600 rounded-none h-full font-black uppercase text-[10px] tracking-widest bg-transparent transition-all">Production</TabsTrigger>
                <TabsTrigger value="library" className="data-[state=active]:text-blue-600 data-[state=active]:border-b-4 data-[state=active]:border-blue-600 rounded-none h-full font-black uppercase text-[10px] tracking-widest bg-transparent transition-all">Cloud Vault</TabsTrigger>
                <TabsTrigger value="analytics" className="data-[state=active]:text-blue-600 data-[state=active]:border-b-4 data-[state=active]:border-blue-600 rounded-none h-full font-black uppercase text-[10px] tracking-widest bg-transparent transition-all">Growth Hub</TabsTrigger>
                <TabsTrigger value="products" className="data-[state=active]:text-blue-600 data-[state=active]:border-b-4 data-[state=active]:border-blue-600 rounded-none h-full font-black uppercase text-[10px] tracking-widest bg-transparent transition-all">Products</TabsTrigger>
                <TabsTrigger value="api" className="data-[state=active]:text-blue-600 data-[state=active]:border-b-4 data-[state=active]:border-blue-600 rounded-none h-full font-black uppercase text-[10px] tracking-widest bg-transparent transition-all">API Access</TabsTrigger>
                <TabsTrigger value="services" className="data-[state=active]:text-blue-600 data-[state=active]:border-b-4 data-[state=active]:border-blue-600 rounded-none h-full font-black uppercase text-[10px] tracking-widest bg-transparent transition-all">Services & Help</TabsTrigger>
              </TabsList>
            </ScrollArea>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar bg-gray-50/50">
            <div className="p-6 md:p-10 h-auto">
              
              <TabsContent value="production" className="m-0 space-y-8 h-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <Label className="text-[10px] font-black uppercase text-gray-500 tracking-widest px-1">Narration Calibration</Label>
                    <div className="space-y-3">
                      {VOICE_TONES.map((tone) => (
                        <button 
                          key={tone.id}
                          onClick={() => setSelectedTone(tone.id)}
                          className={`w-full p-6 rounded-2xl border-2 flex items-center justify-between transition-all ${selectedTone === tone.id ? 'bg-blue-50 border-blue-600 shadow-lg scale-[1.02]' : 'bg-white border-gray-100 hover:border-blue-200'}`}
                        >
                          <div className="flex items-center gap-4">
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${selectedTone === tone.id ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-400'}`}>{tone.icon}</div>
                            <div className="text-left">
                               <span className="text-sm font-black uppercase tracking-tight text-gray-900 block">{tone.name}</span>
                               <span className="text-[9px] text-gray-500 font-bold uppercase">Optimized Vocal Profile</span>
                            </div>
                          </div>
                          {selectedTone === tone.id && <CheckCircle2 className="w-5 h-5 text-blue-600" />}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-6">
                    <Label className="text-[10px] font-black uppercase text-gray-500 tracking-widest px-1">Hardware Handshake</Label>
                    <div className="p-8 bg-white rounded-[32px] border-2 border-gray-100 shadow-sm space-y-6">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-xs font-black uppercase text-gray-900">GPU Acceleration</p>
                          <p className="text-[9px] text-gray-500 uppercase font-bold italic">Bypass standard CPU rendering</p>
                        </div>
                        <Switch checked={hardwareAcceleration} onCheckedChange={setHardwareAcceleration} className="data-[state=checked]:bg-blue-600" />
                      </div>
                      <div className="h-px bg-gray-100 w-full" />
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-xs font-black uppercase text-gray-900">Vault Auto-Sync</p>
                          <p className="text-[9px] text-gray-500 uppercase font-bold italic">Continuous metadata backup</p>
                        </div>
                        <Switch checked={autoSave} onCheckedChange={setAutoSave} className="data-[state=checked]:bg-blue-600" />
                      </div>
                      <Button onClick={handleApply} className="w-full h-16 bg-blue-600 hover:bg-blue-700 text-white font-black uppercase text-[11px] tracking-[0.2em] rounded-2xl shadow-xl shadow-blue-600/20 mt-4">Lock Configuration</Button>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="library" className="m-0 h-auto">
                {activeTab === 'library' && <MyLibrary />}
              </TabsContent>

              <TabsContent value="analytics" className="m-0 h-auto">
                {activeTab === 'analytics' && <AnalyticsDashboard />}
              </TabsContent>

              <TabsContent value="products" className="m-0 space-y-8 h-auto">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <Card className="bg-white border-2 border-gray-100 p-8 rounded-[40px] space-y-6 group hover:border-blue-300 transition-all shadow-xl">
                      <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center border border-blue-100 group-hover:scale-110 transition-transform">
                        <ShoppingBag className="text-blue-600 w-8 h-8" />
                      </div>
                      <div className="space-y-2">
                        <h4 className="text-2xl font-headline font-black text-gray-900 uppercase leading-none">Digital Templates</h4>
                        <p className="text-[10px] text-gray-500 font-bold uppercase leading-relaxed">High-conversion thumbnail packs, script formulas, and niche blueprints.</p>
                      </div>
                      <Button variant="outline" className="w-full border-blue-200 text-blue-600 font-black uppercase text-[10px] h-14 rounded-2xl hover:bg-blue-50">Browse Marketplace</Button>
                    </Card>
                    <Card className="bg-blue-600 border-none p-8 rounded-[40px] space-y-6 group hover:shadow-2xl hover:shadow-blue-600/20 transition-all text-white">
                      <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center border border-white/30 backdrop-blur-md group-hover:scale-110 transition-transform">
                        <Zap className="text-white w-8 h-8" />
                      </div>
                      <div className="space-y-2">
                        <h4 className="text-2xl font-headline font-black uppercase leading-none">Elite Production Node</h4>
                        <p className="text-[10px] text-blue-100 font-bold uppercase leading-relaxed">Unlock 4K Cinema rendering and unlimited AI voiceover calibration.</p>
                      </div>
                      <Button className="w-full bg-white text-blue-600 font-black uppercase text-[10px] h-14 rounded-2xl hover:bg-blue-50">Upgrade Now</Button>
                    </Card>
                 </div>
              </TabsContent>

              <TabsContent value="api" className="m-0 h-auto">
                {!isElite ? (
                  <Card className="bg-white border-2 border-dashed border-gray-200 p-20 rounded-[60px] text-center space-y-8">
                    <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mx-auto border-2 border-gray-100 shadow-xl relative">
                      <Lock className="w-10 h-10 text-blue-600" />
                      <div className="absolute -top-2 -right-2 bg-blue-600 text-white p-2 rounded-full shadow-lg border-4 border-white"><ShieldCheck className="w-4 h-4" /></div>
                    </div>
                    <div className="space-y-3">
                      <h3 className="text-3xl font-headline font-black text-gray-900 uppercase tracking-tighter leading-none">API Access Restricted</h3>
                      <p className="text-sm text-gray-500 font-bold uppercase tracking-widest max-w-sm mx-auto leading-relaxed">Upgrade to an ELITE production node to initialize external API hooks and custom webhooks.</p>
                    </div>
                    <Button className="bg-blue-600 hover:bg-blue-700 text-white font-black uppercase text-[11px] tracking-[0.2em] h-16 px-12 rounded-full shadow-2xl">Activate Elite Terminal</Button>
                  </Card>
                ) : (
                  <Card className="bg-white border-2 border-gray-100 p-10 rounded-[40px] space-y-6">
                    <div className="flex flex-col gap-4">
                      <Label className="text-[10px] font-black uppercase text-gray-400 tracking-widest px-1">Active Production Key</Label>
                      <div className="p-6 bg-gray-50 border-2 border-gray-100 rounded-2xl font-mono text-xs text-gray-600 flex justify-between items-center shadow-inner">
                        <span className="truncate mr-4 font-bold">gee_pk_live_4920_73b1c_a11f2_node_alpha</span>
                        <Button variant="ghost" size="icon" className="h-10 w-10 text-blue-600" onClick={() => { navigator.clipboard.writeText('gee_pk_live_4920_73b1c_a11f2_node_alpha'); toast({ title: "Key Copied" }); }}>
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="services" className="m-0 space-y-10 h-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Card className="bg-white border-2 border-gray-100 p-10 rounded-[40px] space-y-6 group hover:border-blue-300 transition-all shadow-sm">
                    <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center border border-blue-100 group-hover:scale-110 transition-transform">
                      <Users className="text-blue-600 w-8 h-8" />
                    </div>
                    <div className="space-y-2">
                      <h4 className="text-2xl font-headline font-black text-gray-900 uppercase leading-none">Hire Our Team</h4>
                      <p className="text-[10px] text-gray-500 font-bold uppercase leading-relaxed">Custom AI development, web apps, and specialized software for your business.</p>
                    </div>
                    <Button onClick={() => window.open("mailto:uzochukwuchimaobi58@gmail.com")} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black uppercase text-[10px] h-14 rounded-2xl shadow-xl shadow-blue-600/20">Initialize Quote <ArrowUpRight className="w-5 h-5 ml-2" /></Button>
                  </Card>
                  <Card className="bg-white border-2 border-gray-100 p-10 rounded-[40px] space-y-6 group hover:border-blue-300 transition-all shadow-sm">
                    <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center border border-blue-100 group-hover:scale-110 transition-transform">
                      <MessageSquare className="text-blue-600 w-8 h-8" />
                    </div>
                    <div className="space-y-2">
                      <h4 className="text-2xl font-headline font-black text-gray-900 uppercase leading-none">Contact Support</h4>
                      <p className="text-[10px] text-gray-500 font-bold uppercase leading-relaxed">Direct handshake with GEE AI senior production strategists for assistance.</p>
                    </div>
                    <Button variant="outline" onClick={() => window.open("mailto:uzochukwuchimaobi58@gmail.com")} className="w-full border-2 border-blue-200 text-blue-600 font-black uppercase text-[10px] h-14 rounded-2xl hover:bg-blue-50 transition-all">Connect to Support</Button>
                  </Card>
                </div>
              </TabsContent>
            </div>
          </div>
        </Tabs>

        <div className="p-4 bg-white border-t border-gray-100 flex items-center justify-center shrink-0">
          <p className="text-[8px] text-gray-400 uppercase font-black tracking-[0.5em] opacity-40">GEE GROUP SECURE PRODUCTION ENVIRONMENT</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
