
"use client";

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Loader2, 
  Plus, 
  Mic, 
  Clapperboard,
  LayoutGrid,
  Zap,
  Sparkles,
  ArrowRight,
  User,
  Bot,
  Terminal,
  Copy,
  ImageIcon,
  Image as LucideImage,
  Coins,
  ShieldCheck,
  Download,
  X,
  FileUp,
  Camera,
  History,
  AudioWaveform,
  Cpu,
  Settings
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { appNavigate } from '@/ai/flows/app-navigator-flow';
import { generateChannelImage } from '@/ai/flows/generate-channel-image-flow';
import { useRouter } from 'next/navigation';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, useDoc, useMemoFirebase, updateDocumentNonBlocking, setDocumentNonBlocking } from '@/firebase';
import { doc, increment } from 'firebase/firestore';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  navigationTarget?: string;
  masterPrompt?: string;
  generatedImageUrl?: string;
  timestamp: Date;
}

const ACTION_NODES = [
  { label: "Create videos", query: "I want to create a video script", icon: Clapperboard, color: "text-blue-600" },
  { label: "Select niche", query: "Show me trending niches", icon: LayoutGrid, color: "text-blue-600" },
  { label: "Upgrade account", target: "plans", icon: Zap, color: "text-blue-600" },
  { label: "Create image/thumbnail", query: "I need a high-conversion thumbnail prompt", icon: ImageIcon, color: "text-blue-600" },
  { label: "Customize YouTube channel", target: "customize", icon: Settings, color: "text-blue-600" }
];

const COST_IMAGE = 10;
const COST_THUMBNAIL = 15;

export function TerminalChat({ onNavigate, user }: { onNavigate?: (tab: string) => void, user?: any }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isGeneratingVisual, setIsGeneratingVisual] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [showPlusMenu, setShowPlusMenu] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const router = useRouter();
  const { toast } = useToast();
  
  const db = useFirestore();
  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);

  // Derived state for Focus Mode
  const isTyping = input.trim().length > 0 || !!selectedFile;

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading, isGeneratingVisual, isTyping]);

  const handleSend = async (text?: string) => {
    const messageText = text || input;
    if (!messageText.trim() && !selectedFile) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: messageText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setSelectedFile(null);
    setShowPlusMenu(false);
    setIsLoading(true);

    try {
      const history = messages.slice(-5).map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        content: m.content
      }));

      const result = await appNavigate({ 
        message: messageText,
        userId: user?.uid,
        history: history as any
      });
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: result.reply,
        navigationTarget: result.navigationTarget,
        masterPrompt: result.reply.includes('PROMPT:') ? result.reply.split('PROMPT:')[1].trim() : undefined,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Chat Error:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "The production node is currently at capacity. Are you ready to turn your strategy into a video?",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const executeNavigation = (target: string) => {
    if (target === 'blog') {
      router.push('/');
      return;
    }
    if (onNavigate) {
      onNavigate(target);
    } else {
      router.push(`/studio?tab=${target}`);
    }
  };

  const startRecording = () => {
    if (typeof window !== 'undefined' && !('webkitSpeechRecognition' in window) && !('speechRecognition' in window)) {
      toast({ variant: "destructive", title: "Not Supported", description: "Voice recognition is not available in your browser." });
      return;
    }
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).speechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    recognition.onstart = () => setIsRecording(true);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(prev => prev + ' ' + transcript);
    };
    recognition.onerror = () => setIsRecording(false);
    recognition.onend = () => setIsRecording(false);
    recognition.start();
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedFile(reader.result as string);
        setShowPlusMenu(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreateVisual = async (messageId: string, prompt: string, type: 'image' | 'thumbnail') => {
    if (!user) return;
    const cost = type === 'image' ? COST_IMAGE : COST_THUMBNAIL;
    const credits = userProfile?.credits || 0;
    if (credits < cost) {
      toast({ variant: "destructive", title: "Insufficient Credits", description: `You need ${cost} credits for this render.` });
      return;
    }
    setIsGeneratingVisual(messageId);
    try {
      if (userRef) {
        updateDocumentNonBlocking(userRef, {
          credits: increment(-cost),
          updatedAt: new Date().toISOString()
        });
      }
      const result = await generateChannelImage({ prompt, type: type === 'thumbnail' ? 'pfp' : 'logo' });
      if (db && user) {
        const assetId = `chat_render_${Date.now()}`;
        const assetRef = doc(db, 'users', user.uid, 'assets', assetId);
        setDocumentNonBlocking(assetRef, {
          id: assetId,
          userId: user.uid,
          name: `Chat Render: ${type.toUpperCase()}`,
          type: 'image',
          mimeType: 'image/png',
          url: result.imageUrl,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }, { merge: true });
      }
      setMessages(prev => prev.map(m => m.id === messageId ? { ...m, generatedImageUrl: result.imageUrl } : m));
      toast({ title: "Render Complete", description: `${cost} credits deducted. Visual node added to archive.` });
    } catch (error) {
      toast({ variant: "destructive", title: "Production Error", description: "Visual node failed to initialize." });
    } finally {
      setIsGeneratingVisual(null);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Master Prompt Copied", description: "Prompt is ready for production engine consumption." });
  };

  const renderContent = (content: string) => {
    const parts = content.split('Are you ready to turn this into a cinematic video or script using GEE AI\'s production tools?');
    if (parts.length > 1) {
      return (
        <div className="flex flex-col gap-4">
          {parts[0]}
          <div className="mt-6 p-6 bg-blue-600/10 border border-blue-600/30 rounded-[32px] flex flex-col gap-4">
             <div className="flex items-center gap-3">
                <Sparkles className="w-4 h-4 text-blue-600" />
                <span className="text-[10px] font-black uppercase text-blue-600 tracking-widest">Production Pivot</span>
             </div>
             <p className="text-sm font-bold text-white leading-relaxed">Are you ready to turn this into a cinematic video or script using GEE AI's production tools?</p>
             <div className="flex flex-wrap gap-2">
                <Button onClick={() => executeNavigation('script')} className="bg-blue-600 hover:bg-blue-700 text-white font-black uppercase text-[9px] tracking-widest h-10 px-6 rounded-xl gap-2">
                  <Clapperboard className="w-3.5 h-3.5" /> Initialize Studio
                </Button>
                <Button variant="outline" onClick={() => executeNavigation('discovery')} className="border-blue-600/30 text-blue-600 font-black uppercase text-[9px] tracking-widest h-10 px-6 rounded-xl">
                  Niche Calibration
                </Button>
             </div>
          </div>
          {parts[1]}
        </div>
      );
    }
    return content.split('PROMPT:')[0];
  };

  return (
    <div className="flex flex-col w-full h-full bg-white relative animate-in fade-in duration-500 overflow-hidden">
      
      {/* SCROLL AREA CONTAINING WHITE TOP AND BLACK BOTTOM */}
      <div className="flex-1 overflow-y-auto custom-scrollbar scroll-smooth" ref={scrollRef}>
        
        {/* WHITE TOP SECTION - GREETING & ACTION PILLS (Disappears when typing) */}
        <div className={cn(
          "pt-10 pb-16 px-6 md:px-12 space-y-10 bg-white transition-all duration-500 transform origin-top overflow-hidden",
          isTyping ? "max-h-0 py-0 opacity-0 pointer-events-none scale-y-0" : "max-h-[2000px] opacity-100 scale-y-100"
        )}>
          <div className="max-w-2xl mx-auto space-y-2">
            <p className="text-lg md:text-xl font-medium text-slate-400 tracking-tight">
              Hi {user?.displayName?.split(' ')[0] || 'Creator'}
            </p>
            <h2 className="text-4xl md:text-7xl font-headline font-black text-blue-600 tracking-tighter leading-[0.9] uppercase">
              WHERE SHOULD <br /> WE START?
            </h2>
          </div>

          <div className="max-w-2xl mx-auto flex flex-col gap-3">
            {ACTION_NODES.map((node, i) => (
              <button 
                key={i} 
                onClick={() => node.target ? executeNavigation(node.target) : handleSend(node.query)}
                className="flex items-center gap-5 bg-muted/10 hover:bg-muted/20 transition-all px-8 py-5 rounded-full w-full border border-slate-100 text-left group"
              >
                <node.icon className={`w-5 h-5 shrink-0 ${node.color}`} />
                <span className="text-[14px] font-bold text-slate-700 uppercase tracking-tight">{node.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* STRATEGIC PRODUCTION TERMINAL (BLACK) */}
        <div className={cn(
          "bg-black min-h-screen relative flex flex-col shadow-[0_-20px_50px_rgba(0,0,0,0.3)] pb-60 transition-all duration-700",
          !isTyping ? "rounded-t-[48px]" : "rounded-t-none"
        )}>
          <div className="max-w-2xl mx-auto w-full px-6 pt-16 space-y-12">
            {messages.length === 0 && !isTyping && (
              <div className="py-20 text-center flex flex-col items-center gap-6 opacity-20">
                <div className="w-16 h-16 rounded-full border border-white/20 flex items-center justify-center">
                  <Terminal className="w-6 h-6 text-white" />
                </div>
                <p className="text-[10px] font-black uppercase tracking-[0.4em] text-white">Strategic History Empty</p>
              </div>
            )}
            
            {messages.map((m) => (
              <div key={m.id} className="flex gap-5 animate-in fade-in duration-500">
                <Avatar className={`w-10 h-10 shrink-0 border ${m.role === 'assistant' ? 'border-blue-600/40 bg-blue-600/10' : 'border-white/10 bg-slate-800'}`}>
                  {m.role === 'assistant' ? (
                    <AvatarFallback className="bg-transparent"><Bot className="w-6 h-6 text-blue-600" /></AvatarFallback>
                  ) : (
                    <>
                      <AvatarImage src={user?.photoURL} />
                      <AvatarFallback className="bg-transparent text-white text-xs font-bold">{user?.displayName?.charAt(0) || 'U'}</AvatarFallback>
                    </>
                  )}
                </Avatar>
                <div className="flex flex-col gap-2 flex-1 pt-1">
                  <div className="text-lg leading-relaxed text-white/90 font-body">
                    {renderContent(m.content)}
                    {m.masterPrompt && (
                      <div className="mt-8 space-y-6">
                        <div className="p-6 bg-white/5 border border-white/10 rounded-[32px] space-y-4">
                           <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <Terminal className="w-4 h-4 text-blue-600" />
                                <span className="text-[10px] font-black uppercase text-blue-600 tracking-widest">Master Prompt Node</span>
                              </div>
                              <Button variant="ghost" size="icon" className="h-9 w-9 text-blue-600 hover:bg-white/5" onClick={() => copyToClipboard(m.masterPrompt!)}><Copy className="w-4 h-4" /></Button>
                           </div>
                           <p className="text-sm font-mono text-white/60 italic leading-relaxed">"{m.masterPrompt}"</p>
                           <div className="pt-6 border-t border-white/5 flex flex-wrap gap-3">
                              <Button onClick={() => handleCreateVisual(m.id, m.masterPrompt!, 'image')} disabled={!!isGeneratingVisual || !!m.generatedImageUrl} className="bg-blue-600 hover:bg-blue-700 text-white font-black uppercase text-[9px] h-12 px-6 rounded-xl flex-1">
                                {isGeneratingVisual === m.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <LucideImage className="w-4 h-4 mr-2" />}
                                Image (10 Cr)
                              </Button>
                              <Button variant="outline" onClick={() => handleCreateVisual(m.id, m.masterPrompt!, 'thumbnail')} disabled={!!isGeneratingVisual || !!m.generatedImageUrl} className="border-blue-600/30 text-blue-600 font-black uppercase text-[9px] h-12 px-6 rounded-xl flex-1 hover:bg-blue-600/10">
                                {isGeneratingVisual === m.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4 mr-2" />}
                                Thumb (15 Cr)
                              </Button>
                           </div>
                        </div>
                        {m.generatedImageUrl && (
                          <div className="rounded-[40px] overflow-hidden border border-blue-600/20 shadow-2xl animate-in zoom-in-95 relative group/img">
                             <Image src={m.generatedImageUrl} alt="Render" width={800} height={800} className="w-full h-auto object-cover" />
                             <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center">
                                <Button className="bg-white text-black font-black uppercase text-[10px] px-8 h-12 rounded-xl gap-3 hover:bg-slate-100"><Download className="w-4 h-4" /> Download</Button>
                             </div>
                          </div>
                        )}
                      </div>
                    )}
                    {m.navigationTarget && (
                      <div className="mt-8 pt-8 border-t border-white/5">
                        <Button className="bg-blue-600 hover:bg-blue-700 text-white font-bold uppercase text-[11px] h-14 px-10 gap-3 rounded-xl shadow-lg shadow-blue-600/20" onClick={() => executeNavigation(m.navigationTarget!)}>
                          Launch {m.navigationTarget.toUpperCase()} <ArrowRight className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-5 animate-in fade-in duration-300">
                <Avatar className="w-10 h-10 bg-blue-600/10 border border-blue-600/20"><AvatarFallback className="bg-transparent"><Bot className="w-6 h-6 text-blue-600" /></AvatarFallback></Avatar>
                <div className="flex items-center gap-2 pt-5"><div className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-bounce" /><div className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-bounce delay-150" /><div className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-bounce delay-300" /></div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* FIXED COMMAND NODE - ANCHORED AT VIEWPORT BASE */}
      <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10 bg-gradient-to-t from-black via-black/95 to-transparent z-50">
        <div className="max-w-2xl mx-auto space-y-6">
          {selectedFile && (
            <div className="flex items-center gap-3 bg-slate-900 p-3 rounded-2xl w-fit border border-white/10 ml-4 animate-in slide-in-from-bottom-2 mb-4">
              <div className="relative w-12 h-12 rounded-xl overflow-hidden shadow-2xl"><Image src={selectedFile} alt="S" fill className="object-cover" /></div>
              <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full text-white hover:bg-white/10" onClick={() => setSelectedFile(null)}><X className="w-4 h-4" /></Button>
            </div>
          )}
          
          <div className="bg-muted/30 hover:bg-muted/40 border border-white/5 focus-within:bg-muted/40 p-6 rounded-[32px] shadow-2xl transition-all flex flex-col gap-5 relative z-50">
            <div className="flex flex-col gap-3 px-3">
               <Label className="text-[13px] font-medium text-muted-foreground/60 px-1">Ask GEE AI</Label>
               <textarea 
                ref={textareaRef} 
                value={input} 
                onChange={(e) => setInput(e.target.value)} 
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }} 
                className="bg-transparent border-0 focus:ring-0 text-2xl font-medium text-white placeholder:text-slate-700 resize-none min-h-[44px] max-h-[200px] outline-none font-body scroll-smooth" 
                placeholder="Describe your vision..."
                disabled={isLoading} 
                rows={1} 
               />
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-white/5 px-2">
              <div className="flex items-center gap-6">
                <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileSelect} accept="image/*" />
                <button type="button" className={`transition-all ${showPlusMenu ? 'text-blue-600 rotate-45' : 'text-slate-500 hover:text-white'}`} onClick={() => setShowPlusMenu(!showPlusMenu)}><Plus className="w-6 h-6" /></button>
                <button type="button" className="text-slate-500 hover:text-white transition-colors" onClick={() => executeNavigation('history')}><History className="w-6 h-6" /></button>
              </div>
              <div className="flex items-center gap-5">
                <div className="flex items-center gap-2.5 bg-black/60 px-4 py-2 rounded-full border border-white/5 text-[9px] font-black text-slate-400 uppercase tracking-widest"><Cpu className="w-4 h-4 text-blue-600" /> Node 3.1</div>
                <button type="button" className={`transition-all ${isRecording ? 'text-red-500 animate-pulse' : 'text-slate-500 hover:text-white'}`} onClick={startRecording}><Mic className="w-6 h-6" /></button>
                <button type="button" className="text-slate-500 hover:text-white transition-colors"><AudioWaveform className="w-6 h-6" /></button>
                {input.trim() && (
                  <button 
                    onClick={() => handleSend()} 
                    className="ml-2 bg-blue-600 text-white p-3 rounded-full shadow-[0_0_20px_rgba(0,102,255,0.4)] hover:scale-105 transition-all"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center gap-8 px-6">
             <div 
              className="flex items-center gap-3 bg-white/5 px-6 py-3 rounded-full border border-white/5 cursor-pointer hover:bg-white/10 transition-all group" 
              onClick={() => executeNavigation('plans')}
             >
                <div className="p-1 rounded-full bg-blue-600/20 group-hover:bg-blue-600 transition-colors"><Coins className="w-3.5 h-3.5 text-blue-600 group-hover:text-white" /></div>
                <span className="text-[11px] font-black uppercase text-slate-500 tracking-widest">{(userProfile?.credits || 0).toLocaleString()} Credits</span>
             </div>
             <div className="flex flex-col items-center gap-1 opacity-20 hover:opacity-40 transition-opacity">
                <p className="text-[8px] font-black text-white uppercase tracking-[0.3em]">GEE AI CAN MAKE MISTAKES</p>
                <p className="text-[8px] font-black text-white uppercase tracking-[0.3em]">PLEASE CHECK IMPORTANT INFORMATION</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
