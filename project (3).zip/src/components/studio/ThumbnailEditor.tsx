
"use client";

import React, { useState, useEffect } from 'react';
import { suggestThumbnailConcepts } from '@/ai/flows/suggest-thumbnail-concepts-flow';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Type, 
  Square, 
  Circle as CircleIcon, 
  Image as ImageIcon, 
  Sparkles, 
  Download,
  Trash2,
  MousePointer2,
  Settings,
  Lightbulb,
  Palette,
  Loader2,
  Plus
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PlaceHolderImages } from '@/app/lib/placeholder-images';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';

interface ThumbnailEditorProps {
  videoScript?: string;
}

export function ThumbnailEditor({ videoScript }: ThumbnailEditorProps) {
  const { toast } = useToast();
  const [elements, setElements] = useState<any[]>([
    { id: 1, type: 'text', content: 'GEE AI', x: 5, y: 5, color: '#26D1DB', size: 32, isLogo: true }
  ]);
  const [concepts, setConcepts] = useState<string[]>([]);
  const [isGeneratingConcepts, setIsGeneratingConcepts] = useState(false);
  const [background, setBackground] = useState(PlaceHolderImages?.[3]?.imageUrl || '');

  // Automatically suggest concepts when the script is generated
  useEffect(() => {
    if (videoScript && videoScript.length > 50 && concepts.length === 0) {
      handleSuggestConcepts();
    }
  }, [videoScript]);

  const handleSuggestConcepts = async () => {
    if (!videoScript) return;
    setIsGeneratingConcepts(true);
    try {
      const result = await suggestThumbnailConcepts({ videoScript });
      setConcepts(result.concepts);
      toast({
        title: "AI Concepts Ready",
        description: "New thumbnail ideas have been generated based on your script.",
      });
    } catch (error: any) {
      const errorStr = String(error);
      const isRateLimit = errorStr.includes('429') || 
                          errorStr.includes('quota') || 
                          errorStr.includes('exhausted') ||
                          errorStr.includes('RESOURCE_EXHAUSTED');
      
      toast({
        variant: "destructive",
        title: isRateLimit ? "GEE AI is Busy" : "Concept generation failed",
        description: isRateLimit 
          ? "We've hit the temporary rate limit. Please wait a few seconds and try again." 
          : "There was an error generating design concepts.",
      });
    } finally {
      setIsGeneratingConcepts(false);
    }
  };

  const addText = (content: string = 'New Text') => {
    setElements([...elements, { 
      id: Date.now(), 
      type: 'text', 
      content: content, 
      x: 30, 
      y: 40, 
      color: '#ffffff', 
      size: 48 
    }]);
  };

  const removeElement = (id: number) => {
    // Don't remove the GEE AI logo/text if it's marked as logo
    const element = elements.find(el => el.id === id);
    if (element?.isLogo) return;
    setElements(elements.filter(el => el.id !== id));
  };

  const applyConcept = (concept: string) => {
    addText(concept);
    toast({
      title: "Concept Applied",
      description: "Added text layer based on AI suggestion.",
    });
  };

  return (
    <div className="p-8 h-full flex flex-col gap-8 animate-in fade-in duration-500 overflow-y-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-4xl font-headline font-bold text-primary">Thumbnail Editor</h2>
          <p className="text-muted-foreground">AI concepts are automatically generated from your script.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2" onClick={handleSuggestConcepts} disabled={!videoScript || isGeneratingConcepts}>
            {isGeneratingConcepts ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lightbulb className="w-4 h-4 text-secondary" />}
            Refresh Ideas
          </Button>
          <Button className="bg-primary text-primary-foreground gap-2 font-bold">
            <Download className="w-4 h-4" />
            Export Image
          </Button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 xl:grid-cols-4 gap-8">
        <div className="xl:col-span-1 space-y-6">
          <Card className="bg-card/50 border-border">
            <CardHeader className="py-4 border-b border-border">
              <CardTitle className="text-sm uppercase tracking-widest text-muted-foreground">Design Elements</CardTitle>
            </CardHeader>
            <CardContent className="p-4 grid grid-cols-2 gap-3">
              <Button variant="outline" className="h-16 flex-col gap-1 border-border/50 hover:bg-primary/10 hover:text-primary transition-all" onClick={() => addText()}>
                <Type className="w-5 h-5" />
                <span className="text-[10px] font-bold uppercase">Add Text</span>
              </Button>
              <Button variant="outline" className="h-16 flex-col gap-1 border-border/50 hover:bg-primary/10 hover:text-primary transition-all">
                <Palette className="w-5 h-5" />
                <span className="text-[10px] font-bold uppercase">Branding</span>
              </Button>
              <Button variant="outline" className="h-16 flex-col gap-1 border-border/50 hover:bg-primary/10 hover:text-primary transition-all">
                <ImageIcon className="w-5 h-5" />
                <span className="text-[10px] font-bold uppercase">Upload</span>
              </Button>
              <Button variant="outline" className="h-16 flex-col gap-1 border-border/50 hover:bg-primary/10 hover:text-primary transition-all">
                <Sparkles className="w-5 h-5" />
                <span className="text-[10px] font-bold uppercase">Stickers</span>
              </Button>
            </CardContent>
          </Card>

          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-primary flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              AI Design Concepts
            </h3>
            {isGeneratingConcepts ? (
              <div className="p-8 flex flex-col items-center justify-center bg-card/30 rounded-xl border border-dashed border-border">
                <Loader2 className="w-6 h-6 animate-spin text-primary mb-2" />
                <p className="text-[10px] text-muted-foreground uppercase font-bold">Analyzing Script...</p>
              </div>
            ) : concepts.length > 0 ? (
              <div className="space-y-2">
                {concepts.map((concept, i) => (
                  <Card 
                    key={i} 
                    className="group cursor-pointer bg-card/50 border-border hover:border-primary/50 transition-all"
                    onClick={() => applyConcept(concept)}
                  >
                    <CardContent className="p-3 flex items-center justify-between gap-3">
                      <p className="text-xs leading-relaxed line-clamp-2">{concept}</p>
                      <Plus className="w-3 h-3 text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center bg-card/30 rounded-xl border border-dashed border-border">
                <p className="text-xs text-muted-foreground">Generate a video script first to see AI concepts here.</p>
              </div>
            )}
          </div>
        </div>

        <div className="xl:col-span-3 flex flex-col gap-6">
          <div className="relative aspect-video w-full bg-black rounded-2xl shadow-2xl overflow-hidden border-2 border-primary/20 canvas-area group">
            {background && (
              <Image 
                src={background} 
                alt="Thumbnail BG" 
                fill 
                className="object-cover opacity-70"
                data-ai-hint="thumbnail background"
              />
            )}
            
            <div className="absolute inset-0 p-12">
              {elements.map((el) => (
                <div 
                  key={el.id}
                  className="absolute cursor-move select-none group/item"
                  style={{ left: `${el.x}%`, top: `${el.y}%` }}
                >
                  <div 
                    style={{ color: el.color, fontSize: `${el.size}px`, fontWeight: 'bold' }}
                    className={`font-headline drop-shadow-[0_4px_4px_rgba(0,0,0,0.8)] ${el.isLogo ? 'tracking-tighter italic border-l-4 border-primary pl-3' : ''}`}
                  >
                    {el.content}
                  </div>
                  {!el.isLogo && (
                    <div className="absolute -top-10 left-0 hidden group-hover/item:flex items-center gap-1 bg-card border border-border p-1 rounded-md shadow-lg scale-90 origin-bottom-left">
                      <Button size="icon" variant="ghost" className="h-6 w-6"><Settings className="w-3 h-3" /></Button>
                      <Button size="icon" variant="ghost" className="h-6 w-6 text-destructive" onClick={() => removeElement(el.id)}><Trash2 className="w-3 h-3" /></Button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="absolute bottom-6 right-6 flex gap-2">
              <div className="flex items-center gap-2 bg-black/60 px-3 py-1.5 rounded-full border border-white/10 backdrop-blur-sm text-[10px] font-bold uppercase tracking-wider text-white/80">
                <MousePointer2 className="w-3 h-3" />
                Select Tool
              </div>
            </div>
          </div>

          <Card className="bg-card/50 border-border">
            <CardContent className="p-4 flex flex-wrap items-center gap-8">
              <div className="space-y-2">
                <Label className="text-xs uppercase tracking-tighter text-muted-foreground">Background Scene</Label>
                <div className="flex gap-2">
                  {(PlaceHolderImages || []).slice(0, 4).map((img, i) => (
                    <button 
                      key={i} 
                      className={`w-12 h-8 rounded border-2 transition-all overflow-hidden ${background === img.imageUrl ? 'border-primary' : 'border-transparent'}`}
                      onClick={() => setBackground(img.imageUrl)}
                    >
                      <Image src={img.imageUrl} alt="Preset" width={48} height={32} className="object-cover" data-ai-hint="background preset" />
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="space-y-2 flex-1 min-w-[200px]">
                <Label className="text-xs uppercase tracking-tighter text-muted-foreground">Layer Content</Label>
                <Input 
                  placeholder="Select a layer to edit content..." 
                  className="bg-background/50 h-9" 
                  value={elements.find(el => !el.isLogo)?.content || ''}
                  onChange={(e) => {
                    const newEls = [...elements];
                    const activeIndex = newEls.findIndex(el => !el.isLogo);
                    if (activeIndex !== -1) {
                      newEls[activeIndex].content = e.target.value;
                      setElements(newEls);
                    }
                  }}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-xs uppercase tracking-tighter text-muted-foreground">Primary Accent</Label>
                <div className="flex gap-2">
                  {['#26D1DB', '#80E0B9', '#FFFFFF', '#FFD700', '#FF4D4D'].map((color) => (
                    <button 
                      key={color} 
                      className="w-6 h-6 rounded-full border border-white/20 transition-transform hover:scale-125"
                      style={{ backgroundColor: color }}
                      onClick={() => {
                        const newEls = [...elements];
                        const activeIndex = newEls.findIndex(el => !el.isLogo);
                        if (activeIndex !== -1) {
                          newEls[activeIndex].color = color;
                          setElements(newEls);
                        }
                      }}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
