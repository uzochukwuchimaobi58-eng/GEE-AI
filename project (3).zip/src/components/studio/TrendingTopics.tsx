
"use client";

import React, { useState, useEffect, useRef } from 'react';
import { getTrendingNiches } from '@/ai/flows/get-trending-niches-flow';
import { unlockBranding } from '@/ai/flows/unlock-branding-flow';
import { generateChannelImage } from '@/ai/flows/generate-channel-image-flow';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  Loader2, 
  Sparkles, 
  Search, 
  Coins,
  Trophy,
  Rocket,
  ArrowRight,
  Palette,
  Copy,
  Zap,
  User,
  CheckCircle2,
  RefreshCcw,
  Lock,
  Globe,
  ChevronRight,
  BarChart3,
  AlertCircle,
  Calendar,
  MousePointer2,
  FastForward,
  MapPin,
  Flame,
  ArrowUpRight,
  Activity,
  Target,
  X,
  TrendingDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { 
  useAuth, 
  useFirestore, 
  useDoc,
  useMemoFirebase 
} from '@/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useOnlineStatus } from '@/hooks/use-online-status';
import Image from 'next/image';
import { AdSensePlaceholder } from '@/components/AdSensePlaceholder';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const BRANDING_COST = 200;

const COUNTRIES = [
  { id: 'us', name: 'United States', cpm: 'High' },
  { id: 'uk', name: 'United Kingdom', cpm: 'High' },
  { id: 'ca', name: 'Canada', cpm: 'High' },
  { id: 'au', name: 'Australia', cpm: 'High' },
  { id: 'de', name: 'Germany', cpm: 'High' },
  { id: 'fr', name: 'France', cpm: 'High' },
  { id: 'nl', name: 'Netherlands', cpm: 'High' },
  { id: 'no', name: 'Norway', cpm: 'High' },
  { id: 'jp', name: 'Japan', cpm: 'High' },
  { id: 'ae', name: 'United Arab Emirates', cpm: 'High' },
  { id: 'sg', name: 'Singapore', cpm: 'High' },
  { id: 'ng', name: 'Nigeria', cpm: 'Medium/Low' },
  { id: 'za', name: 'South Africa', cpm: 'Medium' },
  { id: 'in', name: 'India', cpm: 'Medium/Low' },
  { id: 'br', name: 'Brazil', cpm: 'Medium/Low' },
  { id: 'mx', name: 'Mexico', cpm: 'Medium' },
  { id: 'kr', name: 'South Korea', cpm: 'High' },
  { id: 'es', name: 'Spain', cpm: 'Medium' },
  { id: 'it', name: 'Italy', cpm: 'Medium' },
  { id: 'tr', name: 'Turkey', cpm: 'Low' },
  { id: 'global', name: 'Global English', cpm: 'Variable' }
];

export function TrendingTopics({ 
  onSelectTrend, 
  onNavigate 
}: { 
  onSelectTrend: (topic: string) => void; 
  onNavigate?: (tab: string) => void;
}) {
  const [niches, setNiches] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [timeRange] = useState<'today' | 'week' | 'month'>('week');
  const [showTopUp, setShowTopUp] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const [selectedNiche, setSelectedNiche] = useState<any | null>(null);
  const [selectedCountry, setSelectedCountry] = useState('us');
  
  const [branding, setBranding] = useState<any | null>(null);
  const [activeWizardTab, setActiveWizardTab] = useState<'identity' | 'analysis'>('identity');
  const [isBrandingLoading, setIsBrandingLoading] = useState(false);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [pfpUrl, setPfpUrl] = useState<string | null>(null);
  const [isLogoLoading, setIsLogoLoading] = useState(false);
  const [isPfpLoading, setIsPfpLoading] = useState(false);

  const brandingCardRef = useRef<HTMLDivElement>(null);
  const [isPaid, setIsPaid] = useState(false);

  const { toast } = useToast();
  const isOnline = useOnlineStatus();
  const auth = useAuth();
  const db = useFirestore();
  const user = auth?.currentUser;

  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);

  const credits = userProfile?.credits ?? 0;
  const isPremium = userProfile?.is_premium || false;

  const fetchNiches = async () => {
    setIsLoading(true);
    try {
      const result = await getTrendingNiches({ timeRange });
      if (result?.niches && result.niches.length > 0) {
        setNiches(result.niches);
      } else {
        throw new Error('Empty niche result');
      }
    } catch (e: any) {
      console.error('Niche fetch failed:', e);
      toast({ variant: "destructive", title: "Sync Node Alert", description: "Strategic data retrieval lagging. Please try again." });
    } finally {
      setIsLoading(false);
    }
  };

  const scrollToBranding = () => {
    if (brandingCardRef.current) {
      brandingCardRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleSelectNiche = async (niche: any) => {
    setSelectedNiche(niche);
    setIsPaid(false); 
    setBranding(null);
    setLogoUrl(null);
    setPfpUrl(null);
    setActiveWizardTab('identity');

    if (db && user) {
      const uRef = doc(db, 'users', user.uid);
      updateDoc(uRef, {
        selectedNiche: niche.name,
        updatedAt: new Date().toISOString()
      }).catch(() => {});
      
      toast({
        title: "Niche Selected!",
        description: `Ready to start creating your ${niche.name} videos? Configure your targeting node.`,
      });

      setTimeout(scrollToBranding, 300);
    } else {
      setShowTopUp(true);
    }
  };

  const handleUnlockBranding = async () => {
    if (!user) {
      setShowTopUp(true);
      return;
    }

    if (credits < BRANDING_COST) {
      toast({
        variant: "destructive",
        title: "Insufficient Credits",
        description: `You need ${BRANDING_COST} credits to unlock professional branding tools.`,
      });
      return;
    }

    setIsBrandingLoading(true);
    try {
      const countryData = COUNTRIES.find(c => c.id === selectedCountry);
      const result = await unlockBranding({
        userId: user.uid,
        nicheName: selectedNiche.name,
        nicheDescription: `${selectedNiche.description} Target Country: ${countryData?.name}. Strategic Mode: ALL-NICHE SYNC.`
      });
      
      setBranding(result);
      setIsPaid(true);
      toast({
        title: "Branding Unlocked!",
        description: `${BRANDING_COST} credits deducted. Localized analysis node is now live.`,
      });
    } catch (e: any) {
      toast({
        variant: "destructive",
        title: "Unlock Failed",
        description: e.message || "The branding engine is currently busy.",
      });
    } finally {
      setIsBrandingLoading(false);
    }
  };

  const handleSkipBranding = () => {
    if (selectedNiche) {
      onSelectTrend(selectedNiche.name);
      onNavigate?.('script');
      toast({ title: "Setup Skipped", description: "Moving directly to Script Studio." });
    }
  };

  const handleGenerateImage = async (type: 'logo' | 'pfp') => {
    if (!branding || !user || !isPaid) return;
    if (type === 'logo') setIsLogoLoading(true);
    else setIsPfpLoading(true);
    try {
      const prompt = type === 'logo' ? branding.logoPrompt : branding.pfpPrompt;
      const result = await generateChannelImage({ prompt, type });
      if (type === 'logo') setLogoUrl(result.imageUrl);
      else setPfpUrl(result.imageUrl);
    } catch (e) {
      toast({ variant: "destructive", title: "Render Failed", description: "Engine busy." });
    } finally {
      if (type === 'logo') setIsLogoLoading(false);
      else setIsPfpLoading(false);
    }
  };

  useEffect(() => {
    fetchNiches();
  }, []);

  const filteredNiches = niches.filter(n => 
    n.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    n.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const activeCountry = COUNTRIES.find(c => c.id === selectedCountry) || COUNTRIES[0];

  return (
    <div className="p-4 md:p-8 space-y-8 animate-in fade-in duration-500 bg-transparent pb-32 relative">
      <Button 
        variant="ghost" 
        size="icon" 
        className="absolute top-4 right-4 md:top-8 md:right-8 h-12 w-12 rounded-full bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white border border-white/5 z-[100]"
        onClick={() => onNavigate?.('home')}
      >
        <X className="w-6 h-6" />
      </Button>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl md:text-8xl font-headline font-black text-primary uppercase tracking-tighter leading-none">MARKET HUB</h2>
          <p className="text-muted-foreground text-[10px] md:text-sm font-bold uppercase tracking-[0.2em] mt-2">
            SCANNING 200+ PROFITABLE NODES: <span className="text-primary italic">ACTIVE</span>
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative w-48 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search Niches..." 
              className="pl-10 h-10 bg-card/50 border-primary/20 rounded-xl text-[10px] font-black uppercase tracking-widest"
            />
          </div>
          <Button variant="ghost" size="sm" onClick={fetchNiches} className="gap-2 h-10 border border-primary/10 rounded-xl hover:bg-primary/5">
            <RefreshCcw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
          <div className="flex items-center gap-3 bg-primary/10 px-4 py-2 rounded-xl border border-primary/20 shadow-inner">
            <Coins className="w-5 h-5 text-primary" />
            <span className="text-xl font-headline font-black text-foreground">{user ? credits.toLocaleString() : "0"}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-8 space-y-10">
          
          {/* STRATEGIC CATEGORIES SECTION */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {isLoading && niches.length === 0 ? Array.from({length: 12}).map((_, i) => (
              <Card key={`skeleton-niche-${i}`} className="h-44 animate-pulse bg-card/50 flex flex-col items-center justify-center border-2 border-dashed border-primary/10 rounded-[32px]">
                <Loader2 className="w-10 h-10 animate-spin text-primary/40 mb-4" />
                <p className="text-[11px] uppercase font-black text-primary/40 tracking-widest text-center px-4">Calibrating Data Node...</p>
              </Card>
            )) : 
            filteredNiches.map((n, i) => (
              <Card 
                key={`niche-${n.name}-${i}`} 
                className={`border-2 rounded-[32px] transition-all cursor-pointer relative overflow-hidden group shadow-xl ${selectedNiche?.name === n.name ? 'border-primary bg-primary/5 ring-4 ring-primary/10' : 'border-border hover:border-primary/40 bg-card/30'}`} 
                onClick={() => handleSelectNiche(n)}
              >
                <div className="absolute top-0 right-0 p-3 flex flex-col items-end gap-2">
                  {selectedNiche?.name === n.name && (
                    <div className="bg-primary text-primary-foreground rounded-full p-1.5 shadow-lg animate-in slide-in-from-top-2">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                  )}
                  <Badge className={`font-black text-[8px] tracking-widest border-none px-2 ${n.type === 'breakout' ? 'bg-red-500' : n.type === 'rising' ? 'bg-amber-500' : 'bg-primary'}`}>
                    {n.type?.toUpperCase() || 'TRENDING'}
                  </Badge>
                </div>

                <CardContent className="p-8 space-y-4">
                  <div className="space-y-1">
                    <span className="font-black text-xl text-foreground leading-none uppercase tracking-tighter block truncate pr-8">{n.name}</span>
                    <p className="text-[10px] text-primary/60 font-black uppercase tracking-widest">{n.risingScore}</p>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed font-medium min-h-[32px]">{n.description}</p>
                  <div className="flex items-center justify-between pt-6 border-t border-white/5">
                    <div className="flex items-center gap-3">
                       <div className="flex flex-col">
                          <span className="text-[8px] font-bold text-muted-foreground uppercase leading-none mb-1">Profitability</span>
                          <span className="text-[10px] font-black uppercase text-green-400 tracking-widest">{n.profitability}</span>
                       </div>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                       <ArrowRight className="w-4 h-4 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {!isPremium && <AdSensePlaceholder />}
        </div>

        <div className="lg:col-span-4 lg:sticky lg:top-8 h-fit space-y-6" ref={brandingCardRef}>
          <Card className="bg-primary/5 border border-primary/20 rounded-[32px] p-6 group hover:bg-primary/10 transition-all shadow-xl">
             <div className="flex flex-col gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center border border-primary/30">
                    <Target className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase text-primary tracking-widest leading-none mb-1">SEO Node</p>
                    <h4 className="text-sm font-headline font-black text-foreground uppercase tracking-tight">SEO Discover</h4>
                  </div>
                </div>
                <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-tight">Use professional SEO tools to find low-competition keywords.</p>
                <a 
                  href="https://mangools.com/?aff=69f5dbd86aee08568a6347ba" 
                  target="_blank"
                  className="w-full h-12 bg-background/50 border border-primary/20 rounded-xl flex items-center justify-center gap-3 text-[10px] font-black uppercase tracking-widest text-primary hover:bg-primary hover:text-primary-foreground transition-all"
                >
                  Launch Explorer <ArrowUpRight className="w-4 h-4" />
                </a>
             </div>
          </Card>

          <Card className="bg-card border-2 border-primary/40 ring-1 ring-primary/20 shadow-[0_0_50px_rgba(38,209,219,0.1)] overflow-hidden rounded-[40px] flex flex-col min-h-[600px]">
            <div className="h-2 bg-primary shadow-[0_0_15px_#26D1DB]" />
            <CardHeader className="pb-6 pt-10 px-8">
              <div className="flex flex-col gap-6">
                <CardTitle className="text-primary flex items-center gap-3 font-headline uppercase text-sm font-black tracking-[0.2em]">
                  {selectedNiche ? (isPaid ? <Palette className="w-6 h-6" /> : <Lock className="w-6 h-6" />) : <Rocket className="w-6 h-6" />}
                  {selectedNiche ? (isPaid ? 'CUSTOMIZATION HUB' : 'STEP 2: CHANNEL SETUP') : 'STEP 1: CHOOSE NICHE'}
                </CardTitle>
                
                {isPaid && branding && (
                  <div className="flex bg-muted/50 p-1.5 rounded-2xl border border-primary/10">
                    <button 
                      className={`flex-1 flex items-center justify-center gap-3 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${activeWizardTab === 'identity' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:text-foreground'}`}
                      onClick={() => setActiveWizardTab('identity')}
                    >
                      <User className="w-4 h-4" /> Identity
                    </button>
                    <button 
                      className={`flex-1 flex items-center justify-center gap-3 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${activeWizardTab === 'analysis' ? 'bg-primary text-primary-foreground shadow-lg' : 'text-muted-foreground hover:text-foreground'}`}
                      onClick={() => setActiveWizardTab('analysis')}
                    >
                      <BarChart3 className="w-4 h-4" /> Analysis
                    </button>
                  </div>
                )}
              </div>
            </CardHeader>

            <CardContent className="space-y-8 px-8 pb-12 flex-1 flex flex-col">
              {!selectedNiche ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6 py-10 opacity-40">
                  <div className="w-20 h-20 rounded-full border-2 border-dashed border-primary/30 flex items-center justify-center">
                     <MousePointer2 className="w-8 h-8 text-primary" />
                  </div>
                  <div className="space-y-2">
                     <p className="text-sm font-black uppercase tracking-widest text-primary leading-tight">INITIALIZE SETUP</p>
                     <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest max-w-[240px]">SELECT A PROFITABLE NICHE FROM THE LEFT TO BEGIN TARGETING.</p>
                  </div>
                </div>
              ) : !isPaid ? (
                <div className="bg-primary/5 rounded-[32px] p-8 border border-primary/20 space-y-8 flex-1 flex flex-col animate-in zoom-in-95 duration-500">
                  <div className="space-y-6">
                     <h4 className="text-xl font-headline font-black text-foreground uppercase tracking-tighter italic border-l-4 border-primary pl-4">
                       Targeting Node for: <span className="text-primary">{selectedNiche.name}</span>
                     </h4>

                     <div className="space-y-3">
                       <label className="text-[10px] font-black uppercase text-primary/70 tracking-widest flex items-center gap-2">
                         <MapPin className="w-3.5 h-3.5" /> SELECT TARGETING NODE (COUNTRY)
                       </label>
                       <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                         <SelectTrigger className="w-full h-14 bg-background/50 border-primary/20 rounded-xl px-4 font-black uppercase text-[10px] tracking-widest text-foreground">
                           <SelectValue />
                         </SelectTrigger>
                         <SelectContent className="bg-card border-primary/20 max-h-80">
                            {COUNTRIES.map(c => (
                              <SelectItem key={c.id} value={c.id} className="text-[10px] font-black uppercase">
                                <div className="flex justify-between items-center w-full min-w-[240px]">
                                  <span>{c.name}</span>
                                  <Badge variant="secondary" className="text-[8px] opacity-70 ml-4">{c.cpm} CPM</Badge>
                                </div>
                              </SelectItem>
                            ))}
                         </SelectContent>
                       </Select>
                     </div>

                     <div className="p-4 bg-background/40 rounded-2xl border border-white/5 space-y-3">
                        <div className="flex items-center gap-3">
                           <Activity className="w-4 h-4 text-primary" />
                           <span className="text-[10px] font-black uppercase tracking-widest text-foreground/80">Regional Estimates</span>
                        </div>
                        <div className="flex justify-between items-center">
                           <span className="text-[9px] font-bold text-muted-foreground uppercase">Expected Yield</span>
                           <span className={`text-[10px] font-black uppercase ${activeCountry.cpm === 'High' ? 'text-green-400' : 'text-primary'}`}>{activeCountry.cpm} CPM</span>
                        </div>
                     </div>
                  </div>

                  <div className="text-center pt-8 mt-auto">
                    <div className="flex items-baseline gap-2 justify-center mb-6">
                      <span className="text-6xl font-headline font-black text-foreground tracking-tighter">{BRANDING_COST}</span>
                      <span className="text-xs text-primary font-black uppercase tracking-widest">Credits</span>
                    </div>
                    <div className="space-y-3">
                      <Button 
                        onClick={handleUnlockBranding} 
                        disabled={isBrandingLoading} 
                        className="w-full h-16 bg-primary text-primary-foreground font-black text-sm uppercase tracking-[0.2em] rounded-2xl shadow-2xl shadow-primary/30 group overflow-hidden relative"
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                        {isBrandingLoading ? <Loader2 className="w-6 h-6 animate-spin mr-3" /> : <Zap className="w-6 h-6 mr-3" />}
                        {isBrandingLoading ? "CALIBRATING NODE..." : "BUY NICHE & UNLOCK"}
                      </Button>
                      <Button 
                        variant="ghost" 
                        className="w-full h-10 font-black uppercase text-[10px] tracking-widest text-muted-foreground hover:text-foreground"
                        onClick={handleSkipBranding}
                      >
                        <FastForward className="w-3 h-3 mr-2" /> Skip Setup
                      </Button>
                    </div>
                  </div>
                </div>
              ) : isBrandingLoading ? (
                <div className="flex-1 flex flex-col items-center justify-center gap-6 py-20 text-center">
                  <div className="relative">
                     <Loader2 className="w-16 h-16 animate-spin text-primary" />
                     <Sparkles className="absolute -top-2 -right-2 text-primary animate-pulse" />
                  </div>
                  <div className="space-y-2">
                     <p className="text-sm font-black uppercase text-primary tracking-[0.3em] animate-pulse">GENERATING BRANDING...</p>
                     <p className="text-[9px] text-muted-foreground uppercase font-bold">SYNCHRONIZING WITH REGIONAL NODE: {activeCountry.name}</p>
                  </div>
                </div>
              ) : branding && activeWizardTab === 'identity' ? (
                <div className="space-y-8 animate-in fade-in duration-500 flex-1">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="aspect-square rounded-[24px] bg-muted/30 border-2 border-dashed border-primary/20 flex items-center justify-center relative overflow-hidden group">
                      {logoUrl ? <Image src={logoUrl} alt="Logo" fill className="object-cover" /> : isLogoLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                        <div className="text-center p-2 flex flex-col items-center gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleGenerateImage('logo')} className="w-12 h-12 bg-primary/10 rounded-full hover:bg-primary/20"><Palette className="w-6 h-6 text-primary" /></Button>
                          <p className="text-[8px] font-black uppercase tracking-widest opacity-50">Render Logo</p>
                        </div>
                      )}
                    </div>
                    <div className="aspect-square rounded-full bg-muted/30 border-2 border-dashed border-primary/20 flex items-center justify-center relative overflow-hidden">
                      {pfpUrl ? <Image src={pfpUrl} alt="PFP" fill className="object-cover" /> : isPfpLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : (
                         <div className="text-center p-2 flex flex-col items-center gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleGenerateImage('pfp')} className="w-12 h-12 bg-primary/10 rounded-full hover:bg-primary/20"><User className="w-6 h-6 text-primary" /></Button>
                          <p className="text-[8px] font-black uppercase tracking-widest opacity-50">Render PFP</p>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div className="p-5 bg-primary/10 border border-primary/30 rounded-2xl flex justify-between items-center shadow-inner">
                      <span className="font-black text-xl text-foreground uppercase tracking-tighter">{branding.channelName}</span>
                      <Button variant="ghost" size="icon" className="h-10 w-10 text-primary hover:bg-primary/10" onClick={() => { navigator.clipboard.writeText(branding.channelName); toast({ title: "Name Copied" }); }}><Copy className="w-5 h-5" /></Button>
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] uppercase font-black text-primary/70 tracking-widest leading-none px-1">AI CHANNEL BLUEPRINT</label>
                      <div className="bg-muted/30 p-5 rounded-2xl max-h-40 overflow-y-auto leading-relaxed border border-white/5 shadow-inner">
                         <p className="text-[11px] text-muted-foreground font-medium">{branding.channelBio}</p>
                      </div>
                    </div>
                  </div>

                  <Button 
                    className="w-full h-16 bg-primary text-primary-foreground font-black text-sm gap-4 uppercase tracking-[0.2em] rounded-2xl shadow-xl shadow-primary/20 mt-auto" 
                    onClick={() => { onSelectTrend(selectedNiche.name); onNavigate?.('script'); }}
                  >
                    INITIALIZE SCRIPT STUDIO <ArrowRight className="w-6 h-6" />
                  </Button>
                </div>
              ) : branding && activeWizardTab === 'analysis' ? (
                <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
                  <div className="bg-primary/10 p-6 rounded-[32px] border border-primary/20 space-y-4 shadow-inner">
                    <div className="flex flex-col gap-1 border-b border-white/5 pb-4">
                       <div className="flex items-center justify-between">
                         <span className="text-[11px] font-black uppercase text-primary/70 tracking-widest">Regional Node</span>
                         <span className="text-[11px] font-black text-foreground uppercase">{activeCountry.name}</span>
                       </div>
                       <div className="flex items-center justify-between mt-2">
                         <span className="text-[11px] font-black uppercase text-primary/70 tracking-widest">Revenue Status</span>
                         <Badge className={`font-black text-[10px] uppercase ${activeCountry.cpm === 'High' ? 'bg-green-400 text-black' : 'bg-primary text-black'}`}>{activeCountry.cpm} CPM</Badge>
                       </div>
                    </div>
                    <div className="flex items-center justify-between border-b border-white/5 pb-4">
                       <span className="text-[11px] font-black uppercase text-primary/70 tracking-widest">Competition</span>
                       <span className="text-xl font-headline font-black text-foreground">{branding.analysis.competitionScore}/100</span>
                    </div>
                    <div className="flex items-center justify-between">
                       <span className="text-[11px] font-black uppercase text-primary/70 tracking-widest">Barrier to Entry</span>
                       <span className="text-xl font-headline font-black text-foreground uppercase tracking-tighter">{branding.analysis.difficulty}</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase text-primary/70 tracking-widest flex items-center gap-3 px-1">
                      <AlertCircle className="w-4 h-4" /> Strategic Forecast
                    </label>
                    <div className="p-5 bg-muted/50 rounded-[24px] border border-white/5 shadow-inner relative overflow-hidden">
                      <div className="absolute top-0 right-0 p-2 opacity-5"><TrendingUp className="w-12 h-12 text-primary" /></div>
                      <p className="text-xs text-foreground/90 leading-relaxed font-bold italic italic-primary">"{branding.analysis.growthForecast}"</p>
                    </div>
                  </div>

                  <div className={`p-5 rounded-2xl flex gap-4 ${activeCountry.cpm === 'High' ? 'bg-amber-400/10 border border-amber-400/20' : 'bg-primary/10 border border-primary/20'}`}>
                     <Zap className={`w-6 h-6 shrink-0 ${activeCountry.cpm === 'High' ? 'text-amber-400' : 'text-primary'}`} />
                     <p className={`text-[10px] font-bold leading-tight uppercase tracking-tight ${activeCountry.cpm === 'High' ? 'text-amber-400' : 'text-primary'}`}>
                       {activeCountry.cpm === 'High' 
                        ? 'MAXIMUM REVENUE DETECTED. WE RECOMMEND 4K CINEMA RENDERING TO DOMINATE THIS HIGH-CPM REGION.' 
                        : 'VOLUME STRATEGY RECOMMENDED. USE THE "SHORT" TIER TO CAPTURE VIRAL MOMENTUM IN THIS REGION.'}
                     </p>
                  </div>
                </div>
              ) : null}
            </CardContent>
            <div className="p-6 text-center mt-auto flex flex-col items-center justify-center gap-3">
              <p className="text-[8px] text-muted-foreground uppercase font-black tracking-[0.5em] opacity-40">GEE GROUP PRODUCTION NODE v4.2</p>
            </div>
          </Card>
        </div>
      </div>

      <Dialog open={showTopUp} onOpenChange={setShowTopUp}>
        <DialogContent className="bg-card border-2 border-primary/20 rounded-[40px] max-w-[360px] p-0 overflow-hidden shadow-2xl">
          <div className="bg-primary/10 p-8 flex flex-col items-center gap-4 border-b border-primary/10">
            <Lock className="w-12 h-12 text-primary" />
            <DialogTitle className="font-headline font-black text-foreground uppercase text-2xl tracking-tighter">Sign In Required</DialogTitle>
          </div>
          <div className="p-8 space-y-6">
            <p className="text-xs text-muted-foreground text-center uppercase font-black leading-relaxed tracking-widest">Join the GEE AI community to unlock professional branding tools and receive your 70 FREE credits instantly.</p>
            <Button className="w-full h-14 font-black uppercase tracking-[0.2em] bg-primary text-primary-foreground shadow-xl shadow-primary/20 rounded-2xl" onClick={() => window.location.reload()}>Initialize Connection</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
