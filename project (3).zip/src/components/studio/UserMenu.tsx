"use client";

import React, { useState } from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  User, 
  Coins, 
  LogOut,
  ChevronDown,
  Settings,
  Gift,
  HelpCircle,
  Mail,
  Library,
  BarChart3,
  Cpu,
  ShoppingBag
} from 'lucide-react';
import { useAuth, useFirestore, useDoc, useUser, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import { ProfileDialog } from './ProfileDialog';
import { SettingsDialog } from './SettingsDialog';
import { FreeCreditsDialog } from './FreeCreditsDialog';

export function UserMenu({ onNavigate }: { onNavigate: (tab: string) => void }) {
  const { user } = useUser();
  const auth = useAuth();
  const db = useFirestore();
  const router = useRouter();
  
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isFreeCreditsOpen, setIsFreeCreditsOpen] = useState(false);
  const [initialSettingsTab, setInitialSettingsTab] = useState('production');

  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      router.push('/');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const openSettingsAt = (tab: string) => {
    setInitialSettingsTab(tab);
    setTimeout(() => setIsSettingsOpen(true), 50);
  };

  return (
    <div className="flex items-center gap-2">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex items-center gap-2 p-1 hover:bg-white/5 rounded-full transition-all border border-transparent hover:border-primary/20 outline-none">
            <div className="w-10 h-10 rounded-full bg-slate-800 border border-primary/30 flex items-center justify-center text-white font-black text-sm shadow-xl uppercase overflow-hidden">
              {user?.photoURL ? <img src={user.photoURL} alt="P" className="w-full h-full object-cover" /> : (user?.displayName?.charAt(0) || 'U')}
            </div>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-72 p-2 bg-white border border-gray-200 shadow-2xl rounded-2xl animate-in fade-in zoom-in-95 duration-200 z-[200]">
          <div className="px-4 py-4 flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center border border-blue-100">
              <Coins className="w-6 h-6 text-blue-600" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-black text-gray-900 leading-none">
                {userProfile?.credits?.toLocaleString() || 0} credits
              </span>
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Available Balance</span>
            </div>
          </div>
          
          <DropdownMenuSeparator className="bg-gray-100 mx-2 mb-2" />
          
          <DropdownMenuItem 
            className="flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer hover:bg-gray-50 focus:bg-gray-50 transition-colors"
            onClick={() => setIsProfileOpen(true)}
          >
            <User className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-bold text-gray-700">Profile & Subscription</span>
          </DropdownMenuItem>

          <DropdownMenuItem 
            className="flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer hover:bg-gray-50 focus:bg-gray-50 transition-colors"
            onClick={() => openSettingsAt('library')}
          >
            <Library className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-bold text-gray-700">Cloud Library</span>
          </DropdownMenuItem>

          <DropdownMenuItem 
            className="flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer hover:bg-gray-50 focus:bg-gray-50 transition-colors"
            onClick={() => openSettingsAt('analytics')}
          >
            <BarChart3 className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-bold text-gray-700">Analytics</span>
          </DropdownMenuItem>

          <DropdownMenuItem 
            className="flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer hover:bg-gray-50 focus:bg-gray-50 transition-colors"
            onClick={() => openSettingsAt('products')}
          >
            <ShoppingBag className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-bold text-gray-700">Digital Products</span>
          </DropdownMenuItem>

          <DropdownMenuItem 
            className="flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer hover:bg-gray-50 focus:bg-gray-50 transition-colors"
            onClick={() => openSettingsAt('api')}
          >
            <Cpu className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-bold text-gray-700">API Access</span>
          </DropdownMenuItem>

          <DropdownMenuItem 
            className="flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer hover:bg-gray-50 focus:bg-gray-50 transition-colors"
            onClick={() => openSettingsAt('production')}
          >
            <Settings className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-bold text-gray-700">Settings</span>
          </DropdownMenuItem>

          <DropdownMenuItem 
            className="flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer hover:bg-blue-50 focus:bg-blue-50 transition-colors group"
            onClick={() => setIsFreeCreditsOpen(true)}
          >
            <Gift className="w-5 h-5 text-blue-600 group-hover:animate-bounce" />
            <span className="text-sm font-bold text-blue-600">Claim Free Power</span>
          </DropdownMenuItem>

          <DropdownMenuSeparator className="bg-gray-100 mx-2 my-1" />

          <DropdownMenuItem 
            className="flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer hover:bg-gray-50 focus:bg-gray-50 transition-colors"
            onClick={() => router.push('/about')}
          >
            <HelpCircle className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-bold text-gray-700">Mission Hub</span>
          </DropdownMenuItem>

          <DropdownMenuItem 
            className="flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer hover:bg-gray-50 focus:bg-gray-50 transition-colors"
            onClick={() => window.open("mailto:uzochukwuchimaobi58@gmail.com")}
          >
            <Mail className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-bold text-gray-700">Direct Support</span>
          </DropdownMenuItem>

          <DropdownMenuSeparator className="bg-gray-100 mx-2 my-1" />

          <DropdownMenuItem 
            className="flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer hover:bg-red-50 focus:bg-red-50 group transition-colors"
            onClick={handleSignOut}
          >
            <LogOut className="w-5 h-5 text-gray-400 group-hover:text-red-600" />
            <span className="text-sm font-bold text-gray-700 group-hover:text-red-600">Log out Node</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <ProfileDialog open={isProfileOpen} onOpenChange={setIsProfileOpen} />
      <SettingsDialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen} initialTab={initialSettingsTab} />
      <FreeCreditsDialog open={isFreeCreditsOpen} onOpenChange={setIsFreeCreditsOpen} />
    </div>
  );
}