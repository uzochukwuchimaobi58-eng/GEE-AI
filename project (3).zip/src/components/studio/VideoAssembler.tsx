
"use client";

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Trash2,
  Clock,
  Maximize2,
  Download,
  Mic2,
  Type,
  ChevronRight,
  Sparkles,
  Check,
  Film,
  FileText,
  Tags,
  ImageIcon,
  Copy,
  ChevronDown,
  ChevronUp,
  UserCircle,
  Plus,
  Loader2,
  Zap,
  ShieldCheck,
  Activity,
  User as UserIcon,
  Upload,
  Volume2,
  Coffee,
  Save,
  Monitor,
  Tv,
  Smartphone,
  Square,
  RectangleVertical,
  Settings,
  Lightbulb,
  Palette,
  X
} from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useAuth, useDoc, useFirestore, useCollection, setDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { doc, collection } from 'firebase/firestore';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';
import { suggestThumbnailConcepts } from '@/ai/flows/suggest-thumbnail-concepts-flow';

interface VideoAssemblerProps {
  timeline: any[];
  setTimeline: React.Dispatch<React.SetStateAction<any[]>>;
  script?: string;
  topic?: string;
  onNavigate?: (tab: string) => void;
}

const VOICE_TONES = [
  { id: 'energetic', name: 'Energetic', icon: <Zap className="w-4 h-4" />, pitch: 1.2, rate: 1.2, desc: 'Viral / Fast' },
  { id: 'professional', name: 'Professional', icon: <Volume2 className="w-4 h-4" />, pitch: 1.0, rate: 1.0, desc: 'Steady / Sage' },
  { id: 'calm', name: 'Calm', icon: <Coffee className="w-4 h-4" />, pitch: 0.8, rate: 0.8, desc: 'Docu / Relaxed' },
];

const CAPTION_STYLES = [
  { id: 'tiktok', name: 'TikTok Viral', preview: 'https://picsum.photos/seed/cap1/300/100' },
  { id: 'cinematic', name: 'Cinematic Subs', preview: 'https://picsum.photos/seed/cap2/300/100' },
  { id: 'bold', name: 'Bold Minimal', preview: 'https://picsum.photos/seed/cap3/300/100' },
];

export function VideoAssembler({ timeline, setTimeline, script, topic, onNavigate }: VideoAssemblerProps) {
  const { toast } = useToast();
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('seo');
  const [selectedCharacterId, setSelectedCharacterId] = useState<string | null>(null);
  
  // SEO STATE
  const [seoTitle, setSeoTitle] = useState('');
  const [seoDesc, setSeoDesc] = useState('');
  const [seoTags, setSeoTags] = useState('');
  
  // FINAL CONFIG
  const [activeTone, setActiveTone] = useState(VOICE_TONES[1].id);
  const [activeCaption, setActiveCaption] = useState(CAPTION_STYLES[0].id);
  const [activeRatio, setActiveRatio] = useState('16:9');

  // THUMBNAIL STATE
  const [thumbnailConcepts, setThumbnailConcepts] = useState<string[]>([]);
  const [isGeneratingThumbnail, setIsGeneratingThumbnail] = useState(false);

  const auth = useAuth();
  const db = useFirestore();
  const user = auth?.currentUser;
  
  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);

  const charactersQuery = useMemoFirebase(() => {
    if (!db || !user) return null;
    return collection(db, 'users', user.uid, 'characters');
  }, [db, user]);
  const { data: characters } = useCollection(charactersQuery);

  useEffect(() => {
    if (topic) setSeoTitle(`How to Master ${topic} in 2025`);
    if (script) setSeoDesc(script.substring(0, 500) + "...");
    setSeoTags(`${topic || 'video'}, ai, automation, growth, viral, strategy, success, 2025`);
  }, [topic, script]);

  const removeFromTimeline = (id: number) => {
    setTimeline(timeline.filter(item => item.timelineId !== id));
  };

  const totalDuration = timeline.length * 30; // ENFORCED 30s Segments

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= totalDuration) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, totalDuration]);

  const activeClip = timeline[Math.floor(currentTime / 30)] || timeline[0];

  const handleSuggestThumbnails = async () => {
    if (!script && !topic) return;
    setIsGeneratingThumbnail(true);
    try {
      const result = await suggestThumbnailConcepts({ videoScript: script, videoTopic: topic });
      setThumbnailConcepts(result.concepts);
      toast({ title: "Concepts Calibrated", description: "Strategic thumbnail nodes are now active." });
    } catch (e) {
      toast({ variant: "destructive", title: "Engine Busy", description: "Retrying concept handshake..." });
    } finally {
      setIsGeneratingThumbnail(false);
    }
  };

  const handleExport = () => {
    setIsExporting(true);
    toast({ title: "Finalizing Render", description: "Applying H.V.B. Formula, " + activeTone.toUpperCase() + " narration, and " + activeRatio + " calibration..." });
    
    // Simulate Download to Phone
    setTimeout(() => {
      setIsExporting(false);
      toast({
        title: "Export Successful",
        description: "Your production is secured and ready for phone download.",
      });
      // In a real app, this would trigger a download link of the stitched video
    }, 4000);
  };

  return (
    <div className="h-full grid grid-cols-1 lg:grid-cols-12 animate-in fade-in duration-500 overflow-hidden bg-background relative">
      <Button 
        variant="ghost" 
        size="icon" 
        className="absolute top-4 right-4 h-10 w-10 rounded-full bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white border border-white/5 z-[100]"
        onClick={() => onNavigate?.('home')}
      >
        <X className="w-5 h-5" />
      </Button>

      <div className="lg:col-span-7 flex flex-col border-r border-primary/10 overflow-hidden">
        <div className="flex-1 bg-black/60 flex items-center justify-center p-8 relative">
          <div className="relative aspect-video w-full max-w-4xl bg-black rounded-[40px] shadow-2xl overflow-hidden border-2 border-primary/30 group">
            {timeline.length > 0 ? (
              activeClip?.url.startsWith('data:video') ? (
                <video src={activeClip.url} className="w-full h-full object-cover" autoPlay={isPlaying} loop muted />
              ) : (
                <Image src={activeClip?.url} alt="Preview" fill className="object-cover opacity-80" />
              )
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-6 opacity-40">
                <div className="w-24 h-24 rounded-full border-4 border-dashed border-primary/30 flex items-center justify-center">
                  <Play className="w-10 h-10 text-primary" />
                </div>
                <p className="text-xs font-black uppercase tracking-[0.3em]">SECURE CANVAS EMPTY</p>
              </div>
            )}
            
            {selectedCharacterId && (
               <div className="absolute bottom-6 right-6 w-32 h-32 rounded-full border-2 border-primary/60 overflow-hidden shadow-[0_0_50px_rgba(38,209,219,0.4)] bg-background/80 backdrop-blur-md animate-in zoom-in-90">
                 {characters?.find(c => c.id === selectedCharacterId) && (
                   <Image 
                     src={characters.find(c => c.id === selectedCharacterId)!.imageUrl} 
                     alt="Avatar" 
                     fill 
                     className="object-cover" 
                   />
                 )}
               </div>
            )}

            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-8">
               <div className="flex items-center gap-4">
                  <Button variant="outline" size="icon" className="h-12 w-12 rounded-full bg-primary text-primary-foreground border-none" onClick={() => setIsPlaying(!isPlaying)}>
                    {isPlaying ? <Pause /> : <Play />}
                  </Button>
                  <Slider className="flex-1" value={[currentTime]} max={totalDuration || 100} onValueChange={([v]) => setCurrentTime(val => v)} />
               </div>
            </div>
          </div>
        </div>

        <div className="h-[240px] bg-card/50 backdrop-blur-xl border-t border-primary/20 flex flex-col shrink-0">
          <div className="flex items-center justify-between px-8 py-3 bg-primary/5">
             <div className="flex items-center gap-4">
                <Clock className="w-4 h-4 text-primary" />
                <span className="text-xl font-headline font-black text-white tracking-tighter">
                  {Math.floor(currentTime / 60).toString().padStart(2, '0')}:{(currentTime % 60).toString().padStart(2, '0')}
                </span>
             </div>
             <div className="flex items-center gap-4">
                <Badge variant="outline" className="text-[10px] font-black uppercase border-primary/30 text-primary tracking-widest px-4 py-1 rounded-full">
                  Locked 30s Segments
                </Badge>
             </div>
          </div>
          <div className="flex-1 overflow-x-auto p-6 flex gap-4 custom-scrollbar">
            {timeline.map((clip) => (
              <div key={clip.timelineId} className="relative h-full w-44 shrink-0 rounded-2xl overflow-hidden border-2 border-transparent hover:border-primary transition-all group shadow-xl">
                <Image src={clip.url} alt="Clip" fill className="object-cover" />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center">
                  <Button size="icon" variant="destructive" className="h-10 w-10 rounded-full" onClick={() => removeFromTimeline(clip.timelineId)}><Trash2 className="w-5 h-5" /></Button>
                </div>
                {activeClip?.timelineId === clip.timelineId && <div className="absolute top-0 left-0 w-full h-1.5 bg-primary shadow-[0_0_15px_#26D1DB] z-20" />}
              </div>
            ))}
            <button 
              className="h-full w-44 shrink-0 border-2 border-dashed border-primary/10 rounded-2xl flex flex-col items-center justify-center gap-2 hover:bg-primary/5 transition-all text-muted-foreground hover:text-primary"
              onClick={() => toast({ title: "Action Required", description: "Use Visual Engine to generate more segments." })}
            >
              <Plus className="w-6 h-6" />
              <span className="text-[9px] font-black uppercase tracking-widest">Add Segment</span>
            </button>
          </div>
        </div>
      </div>

      <div className="lg:col-span-5 bg-card flex flex-col overflow-hidden border-l border-primary/10 relative">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid grid-cols-4 bg-primary/5 rounded-none border-b border-primary/10 p-0 h-16 shrink-0">
            <TabsTrigger value="seo" className="rounded-none h-full font-black uppercase text-[8px] tracking-widest data-[state=active]:bg-primary/10 border-r border-primary/10">SEO HUB</TabsTrigger>
            <TabsTrigger value="voice" className="rounded-none h-full font-black uppercase text-[8px] tracking-widest data-[state=active]:bg-primary/10 border-r border-primary/10">VOICE</TabsTrigger>
            <TabsTrigger value="style" className="rounded-none h-full font-black uppercase text-[8px] tracking-widest data-[state=active]:bg-primary/10 border-r border-primary/10">STYLE</TabsTrigger>
            <TabsTrigger value="thumb" className="rounded-none h-full font-black uppercase text-[8px] tracking-widest data-[state=active]:bg-primary/10">THUMB</TabsTrigger>
          </TabsList>

          <ScrollArea className="flex-1">
            <div className="p-8 space-y-10 pb-32">
              
              <TabsContent value="seo" className="m-0 space-y-8 animate-in fade-in duration-300">
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/70">Viral Title Node</Label>
                    <Input value={seoTitle} onChange={(e) => setSeoTitle(e.target.value)} className="bg-background/50 border-primary/10 h-14 rounded-xl font-bold uppercase text-xs" />
                  </div>
                  <div className="space-y-3">
                    <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/70">Long-Form Strategic Description</Label>
                    <Textarea value={seoDesc} onChange={(e) => setSeoDesc(e.target.value)} className="bg-background/50 border-primary/10 min-h-[160px] rounded-2xl text-xs leading-relaxed" />
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/70">SEO Tags (1,000 Text Node)</Label>
                      <span className={`text-[9px] font-black ${seoTags.length > 1000 ? 'text-destructive' : 'text-primary/40'}`}>{seoTags.length}/1000</span>
                    </div>
                    <Textarea value={seoTags} onChange={(e) => setSeoTags(e.target.value)} className="bg-background/50 border-primary/10 min-h-[120px] rounded-2xl text-[10px] font-mono tracking-tighter" />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="voice" className="m-0 space-y-8 animate-in fade-in duration-300">
                <div className="space-y-6">
                  <div className="p-4 bg-primary/5 rounded-2xl border border-primary/20 flex gap-4">
                     <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center shrink-0 border border-primary/30"><Mic2 className="w-5 h-5 text-primary" /></div>
                     <p className="text-[10px] font-bold text-muted-foreground uppercase leading-relaxed">Select a high-authority narration tone for your 30s segments.</p>
                  </div>
                  <div className="grid grid-cols-1 gap-3">
                    {VOICE_TONES.map((tone) => (
                      <div 
                        key={tone.id} 
                        onClick={() => setActiveTone(tone.id)}
                        className={`p-5 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between group ${activeTone === tone.id ? 'border-primary bg-primary/10 shadow-lg' : 'border-white/5 bg-background/40 hover:border-primary/30'}`}
                      >
                         <div className="flex items-center gap-4">
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${activeTone === tone.id ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground group-hover:text-primary'}`}>{tone.icon}</div>
                            <div className="flex flex-col">
                               <span className="font-black text-sm uppercase tracking-tight">{tone.name}</span>
                               <span className="text-[9px] font-bold text-muted-foreground uppercase">{tone.desc}</span>
                            </div>
                         </div>
                         {activeTone === tone.id && <Check className="w-5 h-5 text-primary" />}
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="style" className="m-0 space-y-10 animate-in fade-in duration-300">
                <div className="space-y-6">
                  <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/70">Caption Aesthetic</Label>
                  <div className="grid grid-cols-1 gap-4">
                    {CAPTION_STYLES.map((cap) => (
                      <div 
                        key={cap.id}
                        onClick={() => setActiveCaption(cap.id)}
                        className={`relative aspect-[21/7] rounded-2xl overflow-hidden cursor-pointer border-2 transition-all ${activeCaption === cap.id ? 'border-primary ring-4 ring-primary/10' : 'border-white/5 opacity-60 hover:opacity-100'}`}
                      >
                        <Image src={cap.preview} alt={cap.name} fill className="object-cover opacity-40" />
                        <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                           <span className={`font-black uppercase tracking-tighter italic ${activeCaption === cap.id ? 'text-primary text-lg' : 'text-white text-sm'}`}>{cap.name}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-6 pt-6 border-t border-white/5">
                   <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/70">Confirm Final Format</Label>
                   <div className="flex gap-2 flex-wrap">
                      {[
                        { id: '16:9', icon: <Tv /> },
                        { id: '9:16', icon: <Smartphone /> },
                        { id: '1:1', icon: <Square /> },
                        { id: '4:5', icon: <RectangleVertical /> }
                      ].map(r => (
                        <button 
                          key={r.id}
                          onClick={() => setActiveRatio(r.id)}
                          className={`flex-1 h-12 flex items-center justify-center gap-2 rounded-xl border-2 transition-all font-black text-[10px] ${activeRatio === r.id ? 'bg-primary text-primary-foreground border-primary shadow-lg' : 'bg-background/40 border-white/5 text-muted-foreground'}`}
                        >
                          {React.cloneElement(r.icon as React.ReactElement, { className: 'w-3.5 h-3.5' })} {r.id}
                        </button>
                      ))}
                   </div>
                </div>
              </TabsContent>

              <TabsContent value="thumb" className="m-0 space-y-8 animate-in fade-in duration-300">
                <div className="space-y-6">
                   <div className="aspect-video bg-muted/30 border-2 border-dashed border-primary/20 rounded-[32px] flex flex-col items-center justify-center p-8 text-center group cursor-pointer hover:bg-primary/5 transition-all" onClick={handleSuggestThumbnails}>
                      {thumbnailConcepts.length > 0 ? (
                        <div className="relative w-full h-full rounded-2xl overflow-hidden">
                          <Image src="https://picsum.photos/seed/thumb-preview/800/450" alt="Thumbnail" fill className="object-cover opacity-60" />
                          <div className="absolute inset-0 flex items-center justify-center p-4">
                             <p className="text-white font-headline font-black text-xl uppercase tracking-tight italic drop-shadow-lg">{thumbnailConcepts[0]}</p>
                          </div>
                        </div>
                      ) : isGeneratingThumbnail ? (
                        <div className="flex flex-col items-center gap-4">
                           <Loader2 className="w-10 h-10 animate-spin text-primary" />
                           <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary">Calibrating...</span>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center gap-4">
                           <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center"><Lightbulb className="w-6 h-6 text-primary" /></div>
                           <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary">Initialize Thumbnail Node</span>
                        </div>
                      )}
                   </div>
                   
                   <div className="space-y-3">
                      <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/70">Strategic Concepts</Label>
                      {thumbnailConcepts.map((c, i) => (
                        <div key={i} className="p-4 bg-background/50 border border-white/5 rounded-xl text-[10px] font-bold uppercase tracking-tight leading-relaxed flex items-center justify-between">
                           <span>{c}</span>
                           <Button variant="ghost" size="icon" className="h-6 w-6 text-primary"><Copy className="w-3 h-3" /></Button>
                        </div>
                      ))}
                   </div>
                </div>
              </TabsContent>

            </div>
          </ScrollArea>

          <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-card via-card to-transparent border-t border-primary/10 backdrop-blur-xl">
             <Button 
              onClick={handleExport} 
              disabled={isExporting || timeline.length === 0}
              className="w-full h-20 bg-primary text-primary-foreground font-black uppercase tracking-[0.2em] rounded-[24px] text-lg shadow-2xl group relative overflow-hidden"
             >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                {isExporting ? <Loader2 className="w-8 h-8 animate-spin" /> : <Download className="w-8 h-8 mr-4 group-hover:scale-110 transition-transform" />}
                {isExporting ? "RENDERING..." : "EXPORT TO PHONE"}
             </Button>
          </div>
        </Tabs>
      </div>
    </div>
  );
}
