
'use client';

import React from 'react';
import { Sparkles, X, Rocket, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth, useFirestore, useDoc, updateDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';

/**
 * @fileOverview Welcome Trial Banner for new creators.
 * Designed to drive "Seven Day Trial" conversions.
 */
export function WelcomeTrialBanner() {
  const auth = useAuth();
  const db = useFirestore();
  const user = auth?.currentUser;
  
  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);

  const isVisible = userProfile && !userProfile.is_premium && !userProfile.welcomeBannerDismissed;

  const handleDismiss = () => {
    if (userRef) {
      updateDocumentNonBlocking(userRef, {
        welcomeBannerDismissed: true
      });
    }
  };

  if (!isVisible) return null;

  return (
    <div className="relative overflow-hidden bg-primary/10 border-b border-primary/20 animate-in slide-in-from-top duration-700">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-primary/5 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4 text-center md:text-left">
          <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center border border-primary/30 shadow-[0_0_15px_rgba(38,209,219,0.2)] shrink-0">
             <Sparkles className="text-primary w-5 h-5 animate-pulse" />
          </div>
          <div className="space-y-0.5">
            <h3 className="text-sm font-headline font-black text-white uppercase tracking-tight leading-none">
              Welcome Creator! <span className="text-primary italic">Node Secured.</span>
            </h3>
            <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">
              Upgrade now to <span className="text-primary">start your seven days trial</span> and unlock 1080p production.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <Button 
            className="flex-1 md:flex-none bg-primary text-primary-foreground font-black uppercase text-[10px] tracking-widest h-9 px-6 shadow-lg shadow-primary/20 gap-2 group"
            onClick={() => window.location.href = '#plans'}
          >
            <Rocket className="w-3.5 h-3.5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            Claim Trial
            <ChevronRight className="w-3.5 h-3.5" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 text-muted-foreground hover:text-white"
            onClick={handleDismiss}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-primary to-transparent opacity-20" />
    </div>
  );
}
