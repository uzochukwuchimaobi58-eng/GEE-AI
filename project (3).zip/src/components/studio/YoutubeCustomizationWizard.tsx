
"use client";

import React, { useState } from 'react';
import { 
  Settings, 
  LayoutGrid, 
  Cpu, 
  Loader2, 
  ArrowRight, 
  CheckCircle2, 
  Sparkles, 
  Zap, 
  ShieldCheck,
  AlertCircle,
  Copy,
  Info,
  X,
  Lock,
  Coins
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, useDoc, useMemoFirebase, updateDocumentNonBlocking } from '@/firebase';
import { doc, collection, addDoc, increment } from 'firebase/firestore';
import { generateChannelBranding } from '@/ai/flows/generate-channel-branding-flow';
import { Badge } from '@/components/ui/badge';

const AUTOMATED_SETUP_COST = 100;

export function YoutubeCustomizationWizard({ onNavigate, user }: { onNavigate: (tab: string) => void, user: any }) {
  const [step, setStep] = useState<'choice' | 'warning' | 'input' | 'processing' | 'result'>('choice');
  const [channelName, setChannelName] = useState('');
  const [channelNiche, setChannelNiche] = useState('');
  const [seoResult, setSeoResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const { toast } = useToast();
  const db = useFirestore();
  const userRef = useMemoFirebase(() => (db && user ? doc(db, 'users', user.uid) : null), [db, user]);
  const { data: userProfile } = useDoc(userRef);

  const credits = userProfile?.credits ?? 0;

  const handleStartWizard = () => {
    if (credits < AUTOMATED_SETUP_COST) {
      setStep('warning');
    } else {
      setStep('input');
    }
  };

  const handleAutomatedSetup = async () => {
    if (!channelName || !channelNiche || !user) return;
    
    setIsLoading(true);
    setStep('processing');
    
    try {
      // Deduct Credits first
      if (userRef) {
        updateDocumentNonBlocking(userRef, {
          credits: increment(-AUTOMATED_SETUP_COST),
          updatedAt: new Date().toISOString()
        });
      }

      // Reusing the branding flow but with strategic instructions for SEO density
      const result = await generateChannelBranding({
        nicheName: channelNiche,
        nicheDescription: `Channel Name: ${channelName}. Optimization: High-Density SEO (1000 chars description). Target: GEE AI Automated Node.`
      });

      // Final processing to ensure 1000 char density simulated/enhanced
      const longDescription = result.channelBio.padEnd(1000, ` ${result.channelBio} `).substring(0, 1000);
      
      const finalSeo = {
        seoName: result.channelName,
        seoDescription: longDescription,
        seoTags: result.channelTags,
        seoLogoPrompt: result.logoPrompt,
        seoBannerPrompt: `A cinematic channel banner for ${result.channelName} in the ${channelNiche} niche, professional layout, 4K render, high authority.`
      };

      setSeoResult(finalSeo);

      if (db && user) {
        const uRef = doc(db, 'users', user.uid);
        updateDocumentNonBlocking(uRef, {
          ...finalSeo,
          updatedAt: new Date().toISOString()
        });

        // Save to chat history for home dashboard
        const chatRef = collection(db, 'users', user.uid, 'chats');
        await addDoc(chatRef, {
          message: `Automated Setup: ${channelName} (${channelNiche})`,
          reply: `YouTube Optimization Handshake Complete. SEO Name: ${finalSeo.seoName}. Description locked at 1000 characters. Tags and visual prompts archived in User Profile. ${AUTOMATED_SETUP_COST} credits used.`,
          timestamp: new Date().toISOString(),
          isPinned: true
        });
      }

      setStep('result');
      toast({ title: "Strategic Setup Complete", description: `${AUTOMATED_SETUP_COST} credits deducted. Metadata synced.` });

    } catch (error) {
      toast({ variant: "destructive", title: "Setup Error", description: "Neural node failed to synchronize." });
      setStep('input');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-4 md:p-12 max-w-4xl mx-auto space-y-10 animate-in fade-in duration-500 pb-40 relative">
      <Button 
        variant="ghost" 
        size="icon" 
        className="absolute top-4 right-4 md:top-8 md:right-8 h-12 w-12 rounded-full bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white border border-white/5 z-[100]"
        onClick={() => onNavigate('home')}
      >
        <X className="w-6 h-6" />
      </Button>

      <div className="flex flex-col items-center text-center gap-2">
        <h2 className="text-4xl md:text-7xl font-headline font-black text-primary uppercase tracking-tighter leading-none">CHANNEL CUSTOMIZER</h2>
        <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Targeting node: <span className="text-primary">STRATEGIC CONFIG</span></p>
      </div>

      <Card className="bg-card/40 border-primary/20 rounded-[48px] overflow-hidden border-2 shadow-2xl relative">
        <div className="absolute top-0 right-0 p-8 opacity-5">
           <Settings className="w-40 h-40 text-primary" />
        </div>
        
        <CardContent className="p-10 md:p-16 relative z-10">
          {step === 'choice' && (
            <div className="max-w-md mx-auto space-y-12 py-10">
              <div className="flex flex-col gap-10">
                <button 
                  onClick={() => onNavigate('discovery')}
                  className="text-left group flex flex-col gap-2 hover:pl-2 transition-all outline-none"
                >
                  <div className="flex items-center gap-4">
                    <h3 className="text-4xl font-headline font-black uppercase text-white tracking-tighter group-hover:text-primary transition-colors leading-none">1. Select Niche</h3>
                    <div className="h-[2px] flex-1 bg-white/5 group-hover:bg-primary/20 transition-colors" />
                  </div>
                  <p className="text-[11px] text-muted-foreground font-bold uppercase tracking-[0.2em] leading-relaxed max-w-xs">Launch the Market Hub and browse 200+ high-CPM trending niches.</p>
                </button>

                <button 
                  onClick={handleStartWizard}
                  className="text-left group flex flex-col gap-2 hover:pl-2 transition-all outline-none"
                >
                  <div className="flex items-center gap-4">
                    <h3 className="text-4xl font-headline font-black uppercase text-white tracking-tighter group-hover:text-primary transition-colors leading-none">2. Automated Setup</h3>
                    <Badge className="bg-primary/10 text-primary border-primary/20 text-[9px] font-black uppercase tracking-tighter px-2 h-6">{AUTOMATED_SETUP_COST} CREDITS</Badge>
                  </div>
                  <p className="text-[11px] text-muted-foreground font-bold uppercase tracking-[0.2em] leading-relaxed max-w-xs">AI generates 1,000 char SEO description and visual prompts instantly.</p>
                </button>
              </div>
              
              <div className="pt-10 flex items-center justify-center gap-2 opacity-30">
                 <ShieldCheck className="w-3 h-3 text-primary" />
                 <span className="text-[8px] font-black uppercase tracking-[0.5em] text-muted-foreground">Select a production path to continue</span>
              </div>
            </div>
          )}

          {step === 'warning' && (
            <div className="py-10 flex flex-col items-center text-center space-y-8 animate-in zoom-in-95 duration-500">
               <div className="w-24 h-24 rounded-full bg-amber-500/20 flex items-center justify-center border-2 border-amber-500/40 shadow-[0_0_30px_rgba(245,158,11,0.2)]">
                  <Lock className="w-10 h-10 text-amber-500" />
               </div>
               <div className="space-y-3">
                  <h3 className="text-3xl font-headline font-black uppercase text-white tracking-tighter">Insufficient Power</h3>
                  <p className="text-sm text-muted-foreground font-bold uppercase tracking-widest max-w-sm">
                    YOU NEED <span className="text-amber-500">{AUTOMATED_SETUP_COST} CREDITS</span> TO INITIALIZE THE AUTOMATED CHANNEL SETUP.
                  </p>
               </div>
               <div className="flex flex-col w-full gap-4 pt-4">
                  <Button 
                    onClick={() => onNavigate('plans')}
                    className="h-16 bg-amber-500 hover:bg-amber-600 text-black font-black uppercase tracking-widest rounded-2xl shadow-xl shadow-amber-500/20"
                  >
                    Upgrade Node Status
                  </Button>
                  <Button 
                    variant="ghost"
                    onClick={() => setStep('choice')}
                    className="h-12 font-black uppercase tracking-widest text-muted-foreground hover:text-white"
                  >
                    Skip & Go Back
                  </Button>
               </div>
            </div>
          )}

          {step === 'input' && (
            <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
               <div className="flex items-center gap-4 mb-10">
                  <button onClick={() => setStep('choice')} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-all">
                    <Zap className="w-5 h-5 text-primary rotate-180" />
                  </button>
                  <div className="flex flex-col">
                    <h3 className="text-2xl font-headline font-black uppercase tracking-tight leading-none">Handshake: <span className="text-primary">Configuration</span></h3>
                    <p className="text-[9px] font-black text-primary/60 uppercase tracking-widest mt-1">Cost: {AUTOMATED_SETUP_COST} Credits</p>
                  </div>
               </div>

               <div className="space-y-6">
                 <div className="space-y-3">
                   <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/70 px-1">What is your channel name?</Label>
                   <Input 
                    value={channelName} 
                    onChange={(e) => setChannelName(e.target.value)} 
                    placeholder="e.g. Veritasium Tech" 
                    className="h-16 bg-background/50 border-primary/20 rounded-2xl px-6 text-lg font-bold uppercase tracking-widest"
                   />
                 </div>
                 <div className="space-y-3">
                   <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/70 px-1">What is your channel niche?</Label>
                   <Input 
                    value={channelNiche} 
                    onChange={(e) => setChannelNiche(e.target.value)} 
                    placeholder="e.g. AI SaaS Reviews" 
                    className="h-16 bg-background/50 border-primary/20 rounded-2xl px-6 text-lg font-bold uppercase tracking-widest"
                   />
                 </div>
               </div>

               <Button 
                onClick={handleAutomatedSetup}
                disabled={!channelName || !channelNiche}
                className="w-full h-20 bg-primary text-primary-foreground font-black text-sm uppercase tracking-[0.3em] rounded-3xl mt-10 shadow-2xl shadow-primary/30 group"
               >
                 Initialize Strategic Sync <ArrowRight className="w-5 h-5 ml-4 group-hover:translate-x-2 transition-transform" />
               </Button>
            </div>
          )}

          {step === 'processing' && (
            <div className="py-20 flex flex-col items-center justify-center gap-8 text-center animate-in zoom-in-95 duration-700">
               <div className="relative">
                  <Loader2 className="w-20 h-20 animate-spin text-primary opacity-50" />
                  <Sparkles className="absolute inset-0 m-auto w-8 h-8 text-primary animate-pulse" />
               </div>
               <div className="space-y-3">
                  <h3 className="text-3xl font-headline font-black uppercase text-primary animate-pulse tracking-tighter">Calibrating Node...</h3>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">Generating 1,000 char SEO description and metadata.</p>
               </div>
            </div>
          )}

          {step === 'result' && seoResult && (
            <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
               <div className="p-8 bg-green-500/10 border-2 border-green-500/30 rounded-[32px] flex items-center gap-6">
                  <div className="w-16 h-16 rounded-2xl bg-green-500/20 flex items-center justify-center shrink-0">
                     <CheckCircle2 className="w-10 h-10 text-green-400" />
                  </div>
                  <div className="space-y-1">
                     <h3 className="text-2xl font-headline font-black uppercase text-white leading-none">Setup Successful</h3>
                     <p className="text-[10px] text-green-400 font-black uppercase tracking-widest">METADATA ENCRYPTED & SAVED TO PROFILE</p>
                  </div>
               </div>

               <div className="bg-primary/5 p-8 rounded-[40px] border border-primary/20 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-10"><Info className="w-20 h-20 text-primary" /></div>
                  <div className="flex gap-4">
                     <AlertCircle className="w-6 h-6 text-primary shrink-0" />
                     <div className="space-y-2">
                        <h4 className="text-sm font-black uppercase tracking-widest text-white">Creator Mandate</h4>
                        <p className="text-xs text-muted-foreground font-bold uppercase leading-relaxed tracking-tight italic">
                          "BEING CONSISTENT IS THE KEY AND STAY ACTIVE TO MAINTAIN NODE AUTHORITY AND ALGORITHMIC SYNC."
                        </p>
                     </div>
                  </div>
               </div>

               <div className="grid grid-cols-1 gap-6">
                  <div className="p-6 bg-background/50 rounded-3xl border border-white/5 space-y-4">
                     <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase text-primary/70 tracking-widest">SEO Name</span>
                        <Button variant="ghost" size="icon" onClick={() => { navigator.clipboard.writeText(seoResult.seoName); toast({title: "Copied"}); }}><Copy className="w-4 h-4 text-primary" /></Button>
                     </div>
                     <p className="text-xl font-bold uppercase tracking-tight text-white">{seoResult.seoName}</p>
                  </div>

                  <div className="p-6 bg-background/50 rounded-3xl border border-white/5 space-y-4">
                     <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase text-primary/70 tracking-widest">SEO Description (1,000 Chars)</span>
                        <Button variant="ghost" size="icon" onClick={() => { navigator.clipboard.writeText(seoResult.seoDescription); toast({title: "Copied"}); }}><Copy className="w-4 h-4 text-primary" /></Button>
                     </div>
                     <div className="max-h-40 overflow-y-auto bg-black/40 p-4 rounded-xl border border-white/5">
                        <p className="text-[10px] font-mono leading-relaxed text-muted-foreground">{seoResult.seoDescription}</p>
                     </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="p-6 bg-background/50 rounded-3xl border border-white/5 space-y-3">
                       <span className="text-[10px] font-black uppercase text-primary/70 tracking-widest">SEO Logo Prompt</span>
                       <p className="text-[9px] text-muted-foreground italic leading-relaxed">"{seoResult.seoLogoPrompt}"</p>
                    </div>
                    <div className="p-6 bg-background/50 rounded-3xl border border-white/5 space-y-3">
                       <span className="text-[10px] font-black uppercase text-primary/70 tracking-widest">SEO Banner Prompt</span>
                       <p className="text-[9px] text-muted-foreground italic leading-relaxed">"{seoResult.seoBannerPrompt}"</p>
                    </div>
                  </div>
               </div>

               <Button 
                onClick={() => onNavigate('script')}
                className="w-full h-16 bg-primary text-primary-foreground font-black text-xs uppercase tracking-[0.4em] rounded-2xl shadow-xl shadow-primary/20"
               >
                 ENTER SCRIPT STUDIO <ArrowRight className="w-5 h-5 ml-4" />
               </Button>
            </div>
          )}
        </CardContent>

        <div className="p-6 text-center flex flex-col items-center justify-center gap-3 mt-auto">
           <ShieldCheck className="w-4 h-4 text-primary/30" />
           <p className="text-[8px] text-muted-foreground uppercase font-black tracking-[0.5em] opacity-40">GEE GROUP PRODUCTION NODE v4.2</p>
        </div>
      </Card>
    </div>
  );
}
