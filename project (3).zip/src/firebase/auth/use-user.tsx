
'use client';

import { useFirebase } from '../provider';

/**
 * @fileOverview Streamlined User Hook.
 * Logic is centralized in FirebaseProvider for faster initial render and reduced Firestore overhead.
 */
export function useUser() {
  const { user, isUserLoading, userError } = useFirebase();
  return { user, loading: isUserLoading, error: userError };
}
