export const firebaseConfig = {
  "projectId": "studio-2111736339-73b1c",
  "appId": "1:453562609376:web:ade49d900cad0d908c6a85",
  "apiKey": "AIzaSyDJGzOaoUU1sTJ_1ZABvJpUU8jhICV1cC0",
  "authDomain": "studio-2111736339-73b1c.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "453562609376"
};
