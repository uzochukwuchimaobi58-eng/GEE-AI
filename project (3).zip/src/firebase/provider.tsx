
'use client';

import React, { DependencyList, createContext, useContext, ReactNode, useMemo, useState, useEffect } from 'react';
import { FirebaseApp } from 'firebase/app';
import { Firestore, doc, getDoc, setDoc } from 'firebase/firestore';
import { Auth, User, onAuthStateChanged } from 'firebase/auth';
import { FirebaseErrorListener } from '@/components/FirebaseErrorListener'
import { setDocumentNonBlocking } from './non-blocking-updates';

interface FirebaseProviderProps {
  children: ReactNode;
  firebaseApp: FirebaseApp;
  firestore: Firestore;
  auth: Auth;
}

interface UserAuthState {
  user: User | null;
  isUserLoading: boolean;
  userError: Error | null;
}

export interface FirebaseContextState {
  areServicesAvailable: boolean;
  firebaseApp: FirebaseApp | null;
  firestore: Firestore | null;
  auth: Auth | null;
  user: User | null;
  isUserLoading: boolean;
  userError: Error | null;
}

export interface FirebaseServicesAndUser {
  firebaseApp: FirebaseApp;
  firestore: Firestore;
  auth: Auth;
  user: User | null;
  isUserLoading: boolean;
  userError: Error | null;
}

export interface UserHookResult {
  user: User | null;
  isUserLoading: boolean;
  userError: Error | null;
}

export const FirebaseContext = createContext<FirebaseContextState | undefined>(undefined);

export const FirebaseProvider: React.FC<FirebaseProviderProps> = ({
  children,
  firebaseApp,
  firestore,
  auth,
}) => {
  const [userAuthState, setUserAuthState] = useState<UserAuthState>({
    user: null,
    isUserLoading: true, 
    userError: null,
  });

  useEffect(() => {
    if (!auth) {
      setUserAuthState({ user: null, isUserLoading: false, userError: new Error("Auth service not provided.") });
      return;
    }

    const unsubscribe = onAuthStateChanged(
      auth,
      async (firebaseUser) => {
        // Immediate UI Update for Auth State to unblock the UI
        setUserAuthState(prev => ({ ...prev, user: firebaseUser, isUserLoading: false }));

        if (firebaseUser && firestore) {
          // Defer profile sync to avoid blocking the main thread during login
          setTimeout(async () => {
            try {
              let deviceId = typeof window !== 'undefined' ? localStorage.getItem('gee_ai_node_sig') : null;
              if (!deviceId && typeof window !== 'undefined') {
                deviceId = `sig_${Math.random().toString(36).substring(2)}${Date.now()}`;
                localStorage.setItem('gee_ai_node_sig', deviceId);
              }

              const userRef = doc(firestore, 'users', firebaseUser.uid);
              const sessionKey = `gee_session_init_${firebaseUser.uid}`;
              const hasSessionInit = typeof window !== 'undefined' ? sessionStorage.getItem(sessionKey) : null;

              if (!hasSessionInit) {
                const userSnap = await getDoc(userRef);
                const updatePayload: any = {
                  lastLoginAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString(),
                  deviceSignature: deviceId,
                };

                if (!userSnap.exists()) {
                  updatePayload.id = firebaseUser.uid;
                  updatePayload.email = firebaseUser.email;
                  updatePayload.displayName = firebaseUser.displayName || 'New Creator';
                  updatePayload.credits = 70;
                  updatePayload.is_premium = false;
                  updatePayload.plan = 'Trial';
                  updatePayload.welcomeBannerDismissed = false;
                  updatePayload.createdAt = new Date().toISOString();
                }

                // Use non-blocking update to prevent "hanging" on network latency
                setDocumentNonBlocking(userRef, updatePayload, { merge: true });
                if (typeof window !== 'undefined') sessionStorage.setItem(sessionKey, 'true');
              }
            } catch (err) {
              console.error("Firebase Initialization Error:", err);
            }
          }, 500);
        }
      },
      (error) => {
        console.error("FirebaseProvider: onAuthStateChanged error:", error);
        setUserAuthState({ user: null, isUserLoading: false, userError: error });
      }
    );
    return () => unsubscribe();
  }, [auth, firestore]);

  const contextValue = useMemo((): FirebaseContextState => {
    const servicesAvailable = !!(firebaseApp && firestore && auth);
    return {
      areServicesAvailable: servicesAvailable,
      firebaseApp: servicesAvailable ? firebaseApp : null,
      firestore: servicesAvailable ? firestore : null,
      auth: servicesAvailable ? auth : null,
      user: userAuthState.user,
      isUserLoading: userAuthState.isUserLoading,
      userError: userAuthState.userError,
    };
  }, [firebaseApp, firestore, auth, userAuthState]);

  return (
    <FirebaseContext.Provider value={contextValue}>
      <FirebaseErrorListener />
      {children}
    </FirebaseContext.Provider>
  );
};

export const useFirebase = (): FirebaseServicesAndUser => {
  const context = useContext(FirebaseContext);
  if (context === undefined) throw new Error('useFirebase must be used within a FirebaseProvider.');
  if (!context.areServicesAvailable || !context.firebaseApp || !context.firestore || !context.auth) {
    throw new Error('Firebase core services not available.');
  }
  return {
    firebaseApp: context.firebaseApp,
    firestore: context.firestore,
    auth: context.auth,
    user: context.user,
    isUserLoading: context.isUserLoading,
    userError: context.userError,
  };
};

export const useAuth = (): Auth => useFirebase().auth;
export const useFirestore = (): Firestore => useFirebase().firestore;
export const useFirebaseApp = (): FirebaseApp => useFirebase().firebaseApp;

type MemoFirebase <T> = T & {__memo?: boolean};

export function useMemoFirebase<T>(factory: () => T, deps: DependencyList): T | (MemoFirebase<T>) {
  const memoized = useMemo(factory, deps);
  if(typeof memoized !== 'object' || memoized === null) return memoized;
  (memoized as MemoFirebase<T>).__memo = true;
  return memoized;
}

export const useUser = (): UserHookResult => {
  const { user, isUserLoading, userError } = useFirebase();
  return { user, isUserLoading, userError };
};
