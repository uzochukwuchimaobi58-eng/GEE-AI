'use client';

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAnalytics, isSupported, logEvent, type Analytics } from 'firebase/analytics';
import { firebaseConfig } from '@/firebase/config';

/**
 * @fileOverview Client-side Firebase initialization hub.
 * Optimized for Next.js with safe Google Analytics lazy-loading and strategic event tracking.
 * Synced with master config to resolve API Key validation errors.
 */

// Singleton pattern for Firebase App initialization
// Uses the imported firebaseConfig to ensure valid credentials
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

/**
 * Safely retrieves the Firebase Analytics instance.
 * 
 * Logic:
 * 1. Checks for 'window' to ensure client-side execution (No SSR errors).
 * 2. Uses 'isSupported()' to verify browser capability/permissions.
 * 3. Initializes Analytics only if both checks pass.
 * 
 * @returns A promise resolving to the Analytics instance or null if unavailable.
 */
export const getSafeAnalytics = async (): Promise<Analytics | null> => {
  if (typeof window !== 'undefined') {
    try {
      const supported = await isSupported();
      if (supported) {
        return getAnalytics(app);
      }
    } catch (error) {
      console.warn("GEE AI NODE: Firebase Analytics not supported in this environment.", error);
    }
  }
  return null;
};

/**
 * Strategic Tracking: Logs when a user initializes a video generation request.
 */
export const trackVideoGenerationStarted = async (promptText: string, aspectRatio: string) => {
  const analytics = await getSafeAnalytics();
  if (analytics) {
    logEvent(analytics, 'video_generation_started', {
      prompt_preview: promptText.substring(0, 100),
      aspect_ratio: aspectRatio,
      timestamp: new Date().toISOString()
    });
  }
};

/**
 * Basic Revenue Tracking: Logs a simple ad impression message.
 */
export const trackAdImpressionLogged = async (placementType: string) => {
  const analytics = await getSafeAnalytics();
  if (analytics) {
    logEvent(analytics, 'ad_impression_logged', {
      placement_type: placementType,
      node_id: 'studio_v4_2'
    });
  }
};

/**
 * High-Precision Revenue Tracking: Logs detailed ad impression data to GA4.
 * Parameters like 'value' and 'currency' are automatically aggregated in the 'Total Revenue' chart.
 * 
 * @param data - The ad performance metadata.
 */
export const trackAdImpressionDetailed = async (data: {
  ad_platform: string;
  ad_source: string;
  ad_format: string;
  ad_unit_name: string;
  value: number;
  currency: string;
}) => {
  const analytics = await getSafeAnalytics();
  if (analytics) {
    // 'ad_impression' is a standard GA4 event name used for revenue calculation
    logEvent(analytics, 'ad_impression', {
      ...data,
      timestamp: new Date().toISOString(),
      studio_version: 'v4.2_secure'
    });
  }
};

export { app };
